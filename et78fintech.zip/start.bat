@echo off
echo Starting ET Alpha...
echo.
echo Frontend will open at: http://localhost:5173
echo.

start "ET Alpha Frontend" cmd /k "cd frontend && npm run dev"
timeout /t 3 /nobreak > nul
start "ET Alpha Backend" cmd /k "cd backend && uvicorn api.main:app --reload --port 8000"

echo Both servers starting...
echo Open http://localhost:5173 in your browser
pause
