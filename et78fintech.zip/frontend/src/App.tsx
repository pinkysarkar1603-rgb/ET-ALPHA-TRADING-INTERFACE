import { useEffect, useState } from 'react'
import { PanelGroup, Panel, PanelResizeHandle } from 'react-resizable-panels'
import { motion, AnimatePresence } from 'framer-motion'
import { useStore } from '@/store'
import Sidebar from '@/components/shared/Sidebar'
import TopBar from '@/components/shared/TopBar'
import LiveTicker from '@/components/shared/LiveTicker'
import AgentStatusBar from '@/components/shared/AgentStatusBar'
import RadarPage from '@/pages/RadarPage'
import XRayPage from '@/pages/XRayPage'
import PlannerPage from '@/pages/PlannerPage'
import MentorPage from '@/pages/MentorPage'
import SidekickPage from '@/pages/SidekickPage'
import VideoPage from '@/pages/VideoPage'
import ImpactPage from '@/pages/ImpactPage'
import MarketsPage from '@/pages/MarketsPage'
import BharatPage from '@/pages/BharatPage'
import DataPage from '@/pages/DataPage'
import ToolsPage from '@/pages/ToolsPage'
import AgentModePage from '@/pages/AgentModePage'
import GuardianPage from '@/pages/GuardianPage'
import AuthPage from '@/pages/AuthPage'
import ScreenAnnotator from '@/components/shared/ScreenAnnotator'
import CopilotPanel from '@/components/copilot/CopilotPanel'
import OverlapAlert from '@/components/shared/OverlapAlert'
import WeeklyDigestToast from '@/components/shared/WeeklyDigestToast'
import { useBackgroundAgents } from '@/hooks/useBackgroundAgents'
import { fetchLivePortfolio, fetchLiveFunds, fetchRadarSignals, NSE_TICKERS } from '@/lib/api'

// ─── Auth helpers ─────────────────────────────────────────────────────────────
function getStoredAuth() {
  const token    = localStorage.getItem('et_token')
  const username = localStorage.getItem('et_username')
  const userId   = localStorage.getItem('et_user_id')
  return token && username && userId ? { token, username, userId: parseInt(userId) } : null
}

async function verifyToken(token: string): Promise<boolean> {
  try {
    const res = await fetch('/api/auth/me', { headers: { Authorization: `Bearer ${token}` } })
    return res.ok
  } catch { return false }
}

async function saveUserData(token: string, key: string, value: any) {
  try {
    await fetch('/api/auth/data/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ key, value })
    })
  } catch {}
}

async function loadUserData(token: string): Promise<Record<string, any>> {
  try {
    const res = await fetch('/api/auth/data', { headers: { Authorization: `Bearer ${token}` } })
    if (res.ok) { const d = await res.json(); return d.data ?? {} }
  } catch {}
  return {}
}

export default function App() {
  const { activeTab, sidebarOpen, setSignals, setPortfolio, setWeeklyDigestReady,
          setAgentStatus, addNotification, addAuditEntry, updateAuditEntry,
          priceAlerts, addPriceAlert } = useStore()

  const [auth, setAuth]       = useState<{ token:string; username:string; userId:number } | null>(null)
  const [authChecked, setAuthChecked] = useState(false)

  // Check stored auth on mount
  useEffect(() => {
    const stored = getStoredAuth()
    if (stored) {
      verifyToken(stored.token).then(valid => {
        if (valid) setAuth(stored)
        else { localStorage.clear(); }
        setAuthChecked(true)
      })
    } else {
      setAuthChecked(true)
    }
  }, [])

  const handleLogin = (token: string, username: string, userId: number) => {
    setAuth({ token, username, userId })
  }

  const handleLogout = () => {
    localStorage.clear()
    setAuth(null)
  }

  // Show loading while checking auth
  if (!authChecked) return (
    <div className="min-h-screen bg-surface-900 flex items-center justify-center">
      <div className="text-center space-y-3">
        <div className="w-10 h-10 bg-brand-500 rounded-xl flex items-center justify-center mx-auto">
          <span className="text-surface-900 font-black text-lg">E</span>
        </div>
        <p className="text-gray-500 text-sm animate-pulse">Loading ET Alpha...</p>
      </div>
    </div>
  )

  // Show auth page if not logged in
  if (!auth) return <AuthPage onLogin={handleLogin} />

  // Main app
  return <MainApp auth={auth} onLogout={handleLogout} />
}

function MainApp({ auth, onLogout }: { auth: any; onLogout: () => void }) {
  const { activeTab, sidebarOpen, setSignals, setPortfolio, setWeeklyDigestReady,
          setAgentStatus, addNotification, addAuditEntry, updateAuditEntry } = useStore()
  useBackgroundAgents()

  useEffect(() => {
    bootWithAuth()
  }, [])

  async function bootWithAuth() {
    // Load saved user data first
    const saved = await loadUserData(auth.token)
    if (saved.portfolio) {
      setPortfolio(saved.portfolio)
    }

    // Then fetch fresh data
    boot(auth.token)
  }

  async function boot(token: string) {
    const a1 = 'a1'
    addAuditEntry({ agentName:'Portfolio Agent', step:'Fetch live NSE prices', input:'5 NSE holdings', output:'', status:'running' })
    setAgentStatus('portfolio','running','Fetching live NSE prices...')
    try {
      const t0 = Date.now()
      const [holdings, funds] = await Promise.all([fetchLivePortfolio(), fetchLiveFunds()])
      const tv  = holdings.reduce((s,h) => s+h.currentValue, 0)
      const ti  = holdings.reduce((s,h) => s+h.avgCost*h.qty, 0)
      const mfV = funds.reduce((s,f) => s+f.currentValue, 0)
      const mfI = funds.reduce((s,f) => s+f.invested, 0)

      let healthScore = 72
      try {
        const hRes = await fetch('/api/portfolio/health-score?emergency_months=2&term_cover_cr=1&equity_pct=70&debt_ratio=0.1&section80c_used=120000')
        if (hRes.ok) { const hd = await hRes.json(); healthScore = hd.overall ?? 72 }
      } catch {}

      const portfolioData = { holdings, funds, totalValue:tv+mfV, totalInvested:ti+mfI,
        overallPnl:tv-ti, overallPnlPct:+((tv-ti)/ti*100).toFixed(2),
        overallXirr:18.4, healthScore, loaded:true }
      setPortfolio(portfolioData)

      // Save to database
      await saveUserData(token, 'portfolio', portfolioData)

      updateAuditEntry(a1, { status:'done', output:`${holdings.length} stocks + ${funds.length} funds`, durationMs:Date.now()-t0 })
      setAgentStatus('portfolio','done',`${holdings.length} holdings loaded`)
      addNotification({ type:'agent', title:'Portfolio loaded', body:`Live prices + MFAPI NAVs loaded` })
    } catch(e:any) {
      updateAuditEntry(a1, { status:'error', output:e.message })
      setAgentStatus('portfolio','error','Fallback data')
    }

    const a2 = 'a2'
    addAuditEntry({ agentName:'Radar Agent', step:'Scan NSE market data', input:`${NSE_TICKERS.length} symbols`, output:'', status:'running' })
    setAgentStatus('radar','running','Scanning NSE...')
    try {
      const t0 = Date.now()
      const a3 = 'a3'
      addAuditEntry({ agentName:'Radar Agent', step:'Signal synthesis and ranking', input:'Live market feed', output:'', status:'running' })
      setAgentStatus('radar','thinking','Running real indicator engine...')
      const { signals } = await fetchRadarSignals({ limit: 8 })
      if (signals.length > 0) {
        setSignals(signals)
        updateAuditEntry(a2, { status:'done', output:`${signals.length} live signals`, durationMs:Date.now()-t0 })
        updateAuditEntry(a3, { status:'done', output:`${signals.length} signals` })
        setAgentStatus('radar','done',`${signals.length} signals`)
        addNotification({ type:'signal', title:`${signals.length} signals`, body:`Groq found actionable signals` })
      } else {
        updateAuditEntry(a2, { status:'done', output:'Quotes loaded' })
        setAgentStatus('radar','idle','Monitoring')
      }
    } catch(e:any) { updateAuditEntry(a2, { status:'error', output:e.message }); setAgentStatus('radar','error','Failed') }

    // Overlap agent
    setTimeout(async () => {
      addAuditEntry({ agentName:'Overlap Agent', step:'Backend overlap analysis', input:'4 funds', output:'', status:'running' })
      setAgentStatus('overlap','running','Analysing correlations...')
      try {
        const funds = useStore.getState().portfolio.funds
        const res = await fetch('/api/portfolio/analyze-overlap', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ funds: funds.map(f => ({ name:f.name, category:f.category, amc:f.amc })) })
        })
        if (res.ok) {
          const data = await res.json()
          const cnt  = funds.filter(f => (f.overlapPct??0) > 60).length
          addAuditEntry({ agentName:'Overlap Agent', step:'Analysis complete', input:'', output:`${cnt} overlap pairs`, status:'done' })
          setAgentStatus('overlap','done',`${cnt} overlap pairs`)
          addNotification({ type:'overlap', title:'Fund overlap detected', body:`${cnt} fund pairs with >60% overlap` })
        }
      } catch {
        setAgentStatus('overlap','done','Offline mode')
      }
    }, 1000)

    setTimeout(() => {
      const hs = useStore.getState().portfolio.healthScore
      addAuditEntry({ agentName:'Portfolio Agent', step:'Health score computed', input:'6 dimensions', output:`Score: ${hs}/100`, status:'done' })
    }, 4000)

    setTimeout(() => setWeeklyDigestReady(true), 6000)
  }

  const PAGES: Record<string,JSX.Element> = {
    radar:    <RadarPage />,
    xray:     <XRayPage />,
    planner:  <PlannerPage />,
    mentor:   <MentorPage />,
    sidekick: <SidekickPage />,
    video:    <VideoPage />,
    impact:   <ImpactPage />,
    markets:  <MarketsPage />,
    bharat:   <BharatPage />,
    data:     <DataPage />,
    tools:    <ToolsPage />,
    agent:    <AgentModePage />,
    guardian: <GuardianPage />,
  }

  return (
    <div className="h-screen flex flex-col bg-surface-900 overflow-hidden">
      <LiveTicker /><TopBar auth={auth} onLogout={onLogout} /><AgentStatusBar />
      <div className="flex-1 overflow-hidden">
        <PanelGroup direction="horizontal" className="h-full">
          {sidebarOpen && (
            <><Panel defaultSize={13} minSize={10} maxSize={20} id="sidebar"><Sidebar /></Panel>
            <PanelResizeHandle className="w-1 bg-surface-500/30 hover:bg-brand-500/40 transition-colors cursor-col-resize" /></>
          )}
          <Panel id="main" className="overflow-hidden">
            <PanelGroup direction="horizontal" className="h-full">
              <Panel id="content" defaultSize={65} minSize={40}>
                <div className="h-full overflow-y-auto bg-surface-900 p-4">
                  <AnimatePresence mode="wait">
                    <motion.div key={activeTab} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:0.18}} className="h-full">
                      {PAGES[activeTab] ?? <RadarPage />}
                    </motion.div>
                  </AnimatePresence>
                </div>
              </Panel>
              <PanelResizeHandle className="w-1 bg-surface-500/30 hover:bg-brand-500/40 transition-colors cursor-col-resize" />
              <Panel id="copilot" defaultSize={35} minSize={24} maxSize={55}><CopilotPanel /></Panel>
            </PanelGroup>
          </Panel>
        </PanelGroup>
      </div>
      <OverlapAlert /><WeeklyDigestToast /><ScreenAnnotator />
    </div>
  )
}
