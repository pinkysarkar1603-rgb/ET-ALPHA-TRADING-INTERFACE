import axios from 'axios'

// ─── FALLBACK SEED PRICES (used instantly while live data loads) ──────────────
export const SEED_PRICES: Record<string, { price: number; chgPct: number }> = {
  '^NSEI':         { price: 22500,  chgPct: 0.0  },
  '^BSESN':        { price: 74000,  chgPct: 0.0  },
  '^NSEBANK':      { price: 48200,  chgPct: 0.0  },
  'RELIANCE.NS':   { price: 2890,   chgPct: 0.0  },
  'TCS.NS':        { price: 3980,   chgPct: 0.0  },
  'INFY.NS':       { price: 1780,   chgPct: 0.0  },
  'HDFCBANK.NS':   { price: 1640,   chgPct: 0.0  },
  'ICICIBANK.NS':  { price: 1240,   chgPct: 0.0  },
  'TATAMOTORS.NS': { price: 890,    chgPct: 0.0  },
  'WIPRO.NS':      { price: 490,    chgPct: 0.0  },
  'ZOMATO.NS':     { price: 220,    chgPct: 0.0  },
  'BAJFINANCE.NS': { price: 7100,   chgPct: 0.0  },
  'ADANIPORTS.NS': { price: 1320,   chgPct: 0.0  },
  'HINDUNILVR.NS': { price: 2450,   chgPct: 0.0  },
  'MARUTI.NS':     { price: 12200,  chgPct: 0.0  },
  'AXISBANK.NS':   { price: 1120,   chgPct: 0.0  },
  'SUNPHARMA.NS':  { price: 1680,   chgPct: 0.0  },
  'LTIM.NS':       { price: 5200,   chgPct: 0.0  },
}

export interface LiveQuote {
  sym: string; price: number; chg: number; chgPct: number
  prev: number; volume: number; high: number; low: number; open: number
}

// ─── Fetch via Vite proxy (bypasses CORS) ─────────────────────────────────────
export async function fetchLiveQuote(yfSym: string): Promise<LiveQuote | null> {
  // Try proxy route first
  const urls = [
    `/yf/v8/finance/chart/${yfSym}?interval=1d&range=2d`,
    `/yf2/v8/finance/chart/${yfSym}?interval=1d&range=2d`,
  ]

  for (const url of urls) {
    try {
      const res  = await axios.get(url, { timeout: 6000 })
      const meta = res.data?.chart?.result?.[0]?.meta
      if (!meta || !meta.regularMarketPrice) continue
      const price  = meta.regularMarketPrice
      const prev   = meta.previousClose ?? meta.chartPreviousClose ?? price
      const chg    = +(price - prev).toFixed(2)
      const chgPct = prev > 0 ? +((chg / prev) * 100).toFixed(2) : 0
      return {
        sym: yfSym, price, chg, chgPct, prev,
        volume: meta.regularMarketVolume ?? 0,
        high:   meta.regularMarketDayHigh ?? price,
        low:    meta.regularMarketDayLow  ?? price,
        open:   meta.regularMarketOpen    ?? price,
      }
    } catch { continue }
  }

  // Fallback: return seed price so UI never shows blank
  const seed = SEED_PRICES[yfSym]
  if (seed) {
    return {
      sym: yfSym, price: seed.price, chg: 0, chgPct: seed.chgPct,
      prev: seed.price, volume: 0, high: seed.price, low: seed.price, open: seed.price,
    }
  }
  return null
}

export async function fetchMultipleQuotes(symbols: string[]): Promise<Record<string, LiveQuote>> {
  const out: Record<string, LiveQuote> = {}

  // First: instantly populate with seed prices so UI shows immediately
  for (const sym of symbols) {
    const seed = SEED_PRICES[sym]
    if (seed) out[sym] = { sym, price: seed.price, chg: 0, chgPct: seed.chgPct, prev: seed.price, volume: 0, high: seed.price, low: seed.price, open: seed.price }
  }

  // Then: fetch real prices in parallel batches (updates over seed)
  for (let i = 0; i < symbols.length; i += 5) {
    const batch = symbols.slice(i, i + 5)
    const results = await Promise.allSettled(batch.map(s => fetchLiveQuote(s)))
    results.forEach((r, idx) => {
      if (r.status === 'fulfilled' && r.value && r.value.volume > 0) {
        // Only overwrite seed if we got a real live quote (volume > 0)
        out[batch[idx]] = r.value
      }
    })
    if (i + 5 < symbols.length) await new Promise(r => setTimeout(r, 200))
  }
  return out
}
