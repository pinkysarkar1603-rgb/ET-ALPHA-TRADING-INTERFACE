import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Video, Play, Square, Download, Loader2, Mic, RefreshCw, Sparkles, TrendingUp, TrendingDown } from 'lucide-react'
import { useStore } from '@/store'
import { groqChat, cn, NSE_TICKERS } from '@/lib/api'
import { fetchMultipleQuotes } from '@/lib/marketData'

interface VideoScene {
  title: string
  subtitle: string
  value: string
  change: string
  sentiment: 'bullish' | 'bearish' | 'neutral'
  duration: number // seconds
  script: string
}

function AnimatedChart({ data, color }: { data: number[]; color: string }) {
  const max = Math.max(...data); const min = Math.min(...data)
  const range = max - min || 1
  const w = 280; const h = 80
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / range) * (h - 10) - 5}`)
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <polyline fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" points={pts.join(' ')} />
      <polyline
        fill={`${color}20`}
        stroke="none"
        points={`0,${h} ${pts.join(' ')} ${w},${h}`}
      />
    </svg>
  )
}

function SceneRenderer({ scene, active }: { scene: VideoScene; active: boolean }) {
  const priceData = Array.from({ length: 20 }, (_, i) => {
    const base = 100
    const trend = scene.sentiment === 'bullish' ? i * 0.8 : scene.sentiment === 'bearish' ? -i * 0.8 : 0
    return base + trend + (Math.random() - 0.5) * 8
  })
  const color = scene.sentiment === 'bullish' ? '#00e676' : scene.sentiment === 'bearish' ? '#ff3d57' : '#ffc61a'

  return (
    <div className={cn(
      'absolute inset-0 flex flex-col items-center justify-center p-8 transition-opacity duration-500',
      active ? 'opacity-100' : 'opacity-0 pointer-events-none'
    )} style={{ background: '#0a0d14' }}>
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={active ? { scale: 1, opacity: 1 } : {}}
        transition={{ duration: 0.4 }}
        className="text-center w-full max-w-sm"
      >
        <p className="text-[11px] text-gray-500 uppercase tracking-widest mb-2">ET Alpha Market Brief</p>
        <h2 className="text-2xl font-black text-white mb-1">{scene.title}</h2>
        <p className="text-sm text-gray-400 mb-4">{scene.subtitle}</p>

        <div className="flex items-center justify-center gap-3 mb-4">
          <span className="text-3xl font-black font-mono text-white">{scene.value}</span>
          <span className={cn('text-lg font-mono font-bold flex items-center gap-1', scene.sentiment === 'bullish' ? 'text-neon-green' : scene.sentiment === 'bearish' ? 'text-neon-red' : 'text-brand-400')}>
            {scene.sentiment === 'bullish' ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
            {scene.change}
          </span>
        </div>

        <div className="flex justify-center mb-4">
          <AnimatedChart data={priceData} color={color} />
        </div>

        <p className="text-xs text-gray-400 leading-relaxed max-w-xs mx-auto">{scene.script.slice(0, 120)}...</p>
      </motion.div>
    </div>
  )
}

export default function VideoPage() {
  const { setAgentStatus } = useStore()
  const [prompt, setPrompt]       = useState('')
  const [scenes, setScenes]       = useState<VideoScene[]>([])
  const [currentScene, setCurrentScene] = useState(0)
  const [generating, setGenerating] = useState(false)
  const [playing, setPlaying]     = useState(false)
  const [recording, setRecording] = useState(false)
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null)
  const [fullScript, setFullScript] = useState('')

  const timerRef    = useRef<ReturnType<typeof setInterval>>()
  const mediaRecRef = useRef<MediaRecorder | null>(null)
  const chunksRef   = useRef<Blob[]>([])
  const canvasRef   = useRef<HTMLCanvasElement>(null)
  const videoRef    = useRef<HTMLDivElement>(null)

  const QUICK_PROMPTS = [
    'Make a 60-second video about NIFTY 50 today',
    'Create a market update video about RELIANCE',
    'Video about top NSE gainers this week',
    'Explain why HDFCBANK is moving today',
    'Market opening summary for today',
  ]

  const generateVideo = async (userPrompt: string) => {
    if (!userPrompt.trim()) return
    setGenerating(true)
    setDownloadUrl(null)
    setAgentStatus('video', 'running', 'Fetching live market data...')

    try {
      // Fetch real live prices
      const symbols  = NSE_TICKERS.slice(0, 8).map(t => t.yf)
      const quotes   = await fetchMultipleQuotes(symbols)
      const priceCtx = NSE_TICKERS.slice(0, 8)
        .map(t => {
          const q = quotes[t.yf]
          return q ? `${t.sym}: ₹${q.price.toFixed(0)} (${q.chgPct >= 0 ? '+' : ''}${q.chgPct}%)` : null
        })
        .filter(Boolean).join(', ')

      setAgentStatus('video', 'thinking', 'Groq scripting the video...')

      const scriptText = await groqChat(
        'You are a financial video scriptwriter for ET Alpha. Create engaging, data-driven market videos. Return ONLY valid JSON.',
        `Create a 60-second market video script. User request: "${userPrompt}"
Live NSE data right now: ${priceCtx}

Return ONLY this JSON (no markdown, no explanation):
{
  "title": "Video title",
  "fullScript": "Complete 60-second narration script (150-200 words)",
  "scenes": [
    {
      "title": "Scene heading",
      "subtitle": "one line context",
      "value": "₹23,450" or "NIFTY 50",
      "change": "+0.74%",
      "sentiment": "bullish",
      "duration": 15,
      "script": "Narration text for this scene (30-40 words)"
    }
  ]
}`
      )

      const match = scriptText.match(/\{[\s\S]*\}/)
      if (!match) throw new Error('Invalid script format')
      const data = JSON.parse(match[0])

      setScenes(data.scenes || [])
      setFullScript(data.fullScript || '')
      setCurrentScene(0)
      setAgentStatus('video', 'done', `${data.scenes?.length || 0} scenes generated`)
    } catch (e: any) {
      setAgentStatus('video', 'error', e.message?.slice(0, 50))
    }
    setGenerating(false)
  }

  const playVideo = async () => {
    if (!scenes.length) return
    setPlaying(true)
    setCurrentScene(0)

    // Web Speech API narration — 100% free, built into browser
    const speak = (text: string, rate = 1.0) => new Promise<void>(resolve => {
      if (!window.speechSynthesis) { resolve(); return }
      window.speechSynthesis.cancel()
      const utt = new SpeechSynthesisUtterance(text)
      utt.rate  = rate
      utt.pitch = 1.1
      utt.volume = 1
      // Try to pick an Indian English voice
      const voices = window.speechSynthesis.getVoices()
      const indian = voices.find(v => v.lang.includes('en-IN') || v.name.includes('India'))
      if (indian) utt.voice = indian
      utt.onend  = () => resolve()
      utt.onerror = () => resolve()
      window.speechSynthesis.speak(utt)
    })

    for (let i = 0; i < scenes.length; i++) {
      setCurrentScene(i)
      await speak(scenes[i].script)
      await new Promise(r => setTimeout(r, 500))
    }

    setPlaying(false)
  }

  const stopVideo = () => {
    setPlaying(false)
    window.speechSynthesis?.cancel()
    clearInterval(timerRef.current)
  }

  const downloadScript = () => {
    const blob = new Blob([fullScript], { type: 'text/plain' })
    const url  = URL.createObjectURL(blob)
    const a    = document.createElement('a')
    a.href     = url
    a.download = 'et-alpha-market-brief-script.txt'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-4 pb-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-purple-500/10 rounded-lg flex items-center justify-center border border-purple-500/20">
          <Video size={16} className="text-purple-400" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-white">AI Video Generator</h2>
          <p className="text-[11px] text-gray-400">60-second market briefing · Real NSE data · Browser TTS · 100% free</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Left: Input + controls */}
        <div className="space-y-3">
          {/* Prompt input */}
          <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-3">
            <p className="text-xs font-semibold text-gray-300">What video do you want?</p>
            <textarea
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="e.g. Make a 60-second video about NIFTY 50 performance today with signals..."
              rows={3}
              className="w-full bg-surface-600 border border-surface-500 text-xs text-gray-200 placeholder-gray-600 px-3 py-2 rounded-lg outline-none focus:border-brand-500/50 resize-none"
            />
            <button
              onClick={() => generateVideo(prompt)}
              disabled={generating || !prompt.trim()}
              className="w-full flex items-center justify-center gap-2 bg-brand-500 text-surface-900 font-bold py-2.5 rounded-lg hover:bg-brand-400 transition-colors disabled:opacity-40 text-sm"
            >
              {generating ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
              {generating ? 'Groq generating script...' : 'Generate Video'}
            </button>
          </div>

          {/* Quick prompts */}
          <div className="space-y-1.5">
            <p className="text-[10px] text-gray-500 uppercase tracking-wider">Quick prompts</p>
            {QUICK_PROMPTS.map(p => (
              <button
                key={p}
                onClick={() => { setPrompt(p); generateVideo(p) }}
                disabled={generating}
                className="w-full text-left text-[11px] bg-surface-700 border border-surface-500/50 text-gray-400 hover:text-white hover:border-brand-500/30 px-3 py-2 rounded-lg transition-all disabled:opacity-40"
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Right: Video preview */}
        <div className="space-y-3">
          {/* Video canvas */}
          <div
            ref={videoRef}
            className="relative bg-surface-900 border border-surface-500/50 rounded-xl overflow-hidden"
            style={{ aspectRatio: '16/9', minHeight: '200px' }}
          >
            {scenes.length === 0 ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6">
                <Video size={32} className="text-gray-600 mb-3" />
                <p className="text-xs text-gray-500">Video preview will appear here</p>
                <p className="text-[10px] text-gray-700 mt-1">Generated using Groq + real NSE data + browser TTS</p>
              </div>
            ) : (
              <div className="absolute inset-0">
                {scenes.map((scene, i) => (
                  <SceneRenderer key={i} scene={scene} active={i === currentScene} />
                ))}

                {/* Scene progress bar */}
                <div className="absolute bottom-0 left-0 right-0 flex gap-1 p-2">
                  {scenes.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentScene(i)}
                      className={cn(
                        'flex-1 h-1 rounded-full transition-all',
                        i === currentScene ? 'bg-brand-400' : i < currentScene ? 'bg-brand-400/40' : 'bg-surface-600'
                      )}
                    />
                  ))}
                </div>

                {/* Scene counter */}
                <div className="absolute top-2 right-2 bg-black/60 text-[9px] text-gray-300 px-1.5 py-0.5 rounded font-mono">
                  {currentScene + 1}/{scenes.length}
                </div>
              </div>
            )}
          </div>

          {/* Playback controls */}
          {scenes.length > 0 && (
            <div className="flex items-center gap-2">
              {/* Prev */}
              <button
                onClick={() => setCurrentScene(s => Math.max(0, s - 1))}
                disabled={playing}
                className="p-2 bg-surface-700 border border-surface-500 rounded-lg text-gray-400 hover:text-white transition-colors disabled:opacity-30"
              >
                <RefreshCw size={13} className="rotate-180" />
              </button>

              {/* Play/Stop */}
              <button
                onClick={playing ? stopVideo : playVideo}
                className={cn(
                  'flex-1 flex items-center justify-center gap-2 py-2 rounded-lg font-semibold text-sm transition-colors',
                  playing
                    ? 'bg-neon-red/10 border border-neon-red/20 text-neon-red hover:bg-neon-red/20'
                    : 'bg-brand-500/10 border border-brand-500/20 text-brand-400 hover:bg-brand-500/20'
                )}
              >
                {playing ? <><Square size={13} /> Stop</> : <><Mic size={13} /> Play with Voice</>}
              </button>

              {/* Next */}
              <button
                onClick={() => setCurrentScene(s => Math.min(scenes.length - 1, s + 1))}
                disabled={playing}
                className="p-2 bg-surface-700 border border-surface-500 rounded-lg text-gray-400 hover:text-white transition-colors disabled:opacity-30"
              >
                <RefreshCw size={13} />
              </button>

              {/* Download script */}
              {fullScript && (
                <button
                  onClick={downloadScript}
                  className="p-2 bg-surface-700 border border-surface-500 rounded-lg text-gray-400 hover:text-white transition-colors"
                  title="Download script"
                >
                  <Download size={13} />
                </button>
              )}
            </div>
          )}

          {/* Full script */}
          {fullScript && (
            <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-3 max-h-32 overflow-y-auto">
              <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-1.5">Full script</p>
              <p className="text-[11px] text-gray-300 leading-relaxed">{fullScript}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
