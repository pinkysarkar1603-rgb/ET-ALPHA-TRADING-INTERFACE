import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Calculator, Scissors, Users, Download, Wrench } from 'lucide-react'
import { SIPCalculatorV2, TaxLossHarvesting, CouplePlanner, PDFExport } from '@/components/shared/MegaFeatures'
import { cn } from '@/lib/api'

const TABS = [
  { id: 'sip',     label: 'SIP V2',         icon: Calculator },
  { id: 'tax',     label: 'Tax Harvesting', icon: Scissors   },
  { id: 'couple',  label: 'Couple Planner', icon: Users      },
  { id: 'export',  label: 'PDF Export',     icon: Download   },
] as const

export default function ToolsPage() {
  const [tab, setTab] = useState<'sip'|'tax'|'couple'|'export'>('sip')

  return (
    <div className="space-y-4 pb-4">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-teal-500/10 rounded-lg flex items-center justify-center border border-teal-500/20">
          <Wrench size={16} className="text-teal-400" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-white">Financial Tools</h2>
          <p className="text-[11px] text-gray-400">Step-up SIP · Tax harvesting · Couple planner · PDF report</p>
        </div>
      </div>

      <div className="flex gap-2 flex-wrap">
        {TABS.map(t => {
          const Icon = t.icon
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={cn('flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border transition-all',
                tab === t.id ? 'bg-brand-500/10 border-brand-500/30 text-brand-400' : 'bg-surface-700 border-surface-500 text-gray-400 hover:text-white')}>
              <Icon size={12} />{t.label}
            </button>
          )
        })}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={tab} initial={{ opacity:0, y:6 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-6 }} transition={{ duration:0.15 }}>
          {tab === 'sip'    && <SIPCalculatorV2 />}
          {tab === 'tax'    && <TaxLossHarvesting />}
          {tab === 'couple' && <CouplePlanner />}
          {tab === 'export' && (
            <div className="space-y-4">
              <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-6 text-center space-y-4">
                <Download size={32} className="mx-auto text-brand-400/60" />
                <p className="text-sm font-semibold text-white">One-click Portfolio PDF Report</p>
                <p className="text-xs text-gray-400 max-w-sm mx-auto leading-relaxed">
                  Generates a complete portfolio report — holdings, P&L, fund analysis, today's signals, and AI insights. Opens in browser for printing or saving as PDF.
                </p>
                <PDFExport />
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
