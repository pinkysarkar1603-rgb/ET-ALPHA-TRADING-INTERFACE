import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { BriefcaseBusiness, BrainCircuit, CalendarClock, Filter, Flame, Globe2, Loader2, Minus, RefreshCw, ShieldAlert, SplitSquareHorizontal, Target, TrendingDown, TrendingUp, Waves, Zap } from 'lucide-react'
import { useStore } from '@/store'
import { cn, fetchRadarSignals } from '@/lib/api'
import { AlertBuilder, CompareBoard, EarningsRadar, EventHeatmap, ExplainStock, RotationBoard, SignalCard, StrategyLab, WatchlistBuilder, ImpactSimulator } from '@/components/radar/RadarSuite'

const TYPE_LABELS: Record<string, string> = {
  insider_trade: 'Insider Trade',
  bulk_deal: 'Bulk Deal',
  pattern: 'Chart Pattern',
  fundamental: 'Fundamental',
  alert: 'Risk Alert',
}

const RADAR_TABS = [
  { id: 'signals', label: 'Signals', icon: Zap },
  { id: 'compare', label: 'Compare', icon: SplitSquareHorizontal },
  { id: 'rotation', label: 'Rotation', icon: Waves },
  { id: 'events', label: 'Events', icon: Globe2 },
  { id: 'impact', label: 'Impact', icon: BriefcaseBusiness },
  { id: 'alerts', label: 'Alerts', icon: ShieldAlert },
  { id: 'lab', label: 'Lab', icon: Target },
  { id: 'watchlist', label: 'Watchlist', icon: Flame },
  { id: 'earnings', label: 'Earnings', icon: CalendarClock },
  { id: 'explain', label: 'Explain', icon: BrainCircuit },
] as const

type RadarTab = typeof RADAR_TABS[number]['id']

export default function RadarPage() {
  const { signals, setSignals, setAgentStatus } = useStore()
  const [activeView, setActiveView] = useState<RadarTab>('signals')
  const [filterType, setFilterType] = useState('all')
  const [filterSent, setFilterSent] = useState('all')
  const [onlyAction, setOnlyAction] = useState(false)
  const [sortBy, setSortBy] = useState<'time' | 'strength'>('time')
  const [refreshing, setRefreshing] = useState(false)

  const refresh = async () => {
    setRefreshing(true)
    setAgentStatus('radar', 'running', 'Running live indicator scan...')
    try {
      const { signals: nextSignals } = await fetchRadarSignals({ limit: 12, type: filterType, sentiment: filterSent })
      if (nextSignals.length > 0) {
        setSignals(nextSignals)
        setAgentStatus('radar', 'done', `${nextSignals.length} signals`)
      } else {
        setAgentStatus('radar', 'idle', 'No strong movers')
      }
    } catch {
      setAgentStatus('radar', 'error', 'Fetch failed')
    } finally {
      setRefreshing(false)
    }
  }

  const filtered = useMemo(() => (
    signals
      .filter(signal => filterType === 'all' || signal.type === filterType)
      .filter(signal => filterSent === 'all' || signal.sentiment === filterSent)
      .filter(signal => !onlyAction || signal.actionable)
      .sort((a, b) => sortBy === 'time' ? b.timestamp - a.timestamp : b.strength - a.strength)
  ), [signals, filterSent, filterType, onlyAction, sortBy])

  const stats = useMemo(() => ({
    total: signals.length,
    bullish: signals.filter(signal => signal.sentiment === 'bullish').length,
    bearish: signals.filter(signal => signal.sentiment === 'bearish').length,
    actionable: signals.filter(signal => signal.actionable).length,
  }), [signals])

  return (
    <div className="flex h-full flex-col gap-4">
      <div className="flex flex-wrap gap-2">
        {RADAR_TABS.map(tab => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => setActiveView(tab.id)}
              className={cn(
                'inline-flex items-center gap-2 rounded-2xl border px-4 py-2 text-sm font-semibold transition-all',
                activeView === tab.id ? 'border-brand-400/40 bg-brand-500/12 text-white shadow-glow-amber' : 'border-surface-500/50 bg-surface-700/70 text-gray-400 hover:text-white',
              )}
            >
              <Icon size={14} />
              {tab.label}
            </button>
          )
        })}
      </div>

      {activeView === 'signals' && (
        <>
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'Total Signals', value: stats.total, color: 'text-white' },
              { label: 'Bullish', value: stats.bullish, color: 'text-neon-green' },
              { label: 'Bearish', value: stats.bearish, color: 'text-neon-red' },
              { label: 'Actionable', value: stats.actionable, color: 'text-brand-400' },
            ].map((item, index) => (
              <motion.div key={item.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }} className="rounded-xl border border-surface-500/50 bg-surface-700 p-3">
                <p className="mb-1 text-[10px] uppercase tracking-wider text-gray-500">{item.label}</p>
                <p className={cn('font-mono text-2xl font-black', item.color)}>{item.value}</p>
              </motion.div>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Filter size={13} className="text-gray-500" />
            <select value={filterType} onChange={event => setFilterType(event.target.value)} className="rounded-lg border border-surface-500 bg-surface-700 px-2 py-1.5 text-xs text-gray-300 focus:border-brand-500 focus:outline-none">
              <option value="all">All Types</option>
              {Object.entries(TYPE_LABELS).map(([key, value]) => <option key={key} value={key}>{value}</option>)}
            </select>
            <select value={filterSent} onChange={event => setFilterSent(event.target.value)} className="rounded-lg border border-surface-500 bg-surface-700 px-2 py-1.5 text-xs text-gray-300 focus:border-brand-500 focus:outline-none">
              <option value="all">All Sentiment</option>
              <option value="bullish">Bullish</option>
              <option value="bearish">Bearish</option>
              <option value="neutral">Neutral</option>
            </select>
            <button onClick={() => setOnlyAction(value => !value)} className={cn('flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs transition-all', onlyAction ? 'border-brand-500/30 bg-brand-500/10 text-brand-400' : 'border-surface-500 bg-surface-700 text-gray-400 hover:text-white')}>
              <Zap size={11} />
              Actionable only
            </button>
            <div className="ml-auto flex items-center gap-2">
              <span className="text-[10px] text-gray-500">{filtered.length} signals</span>
              {(['time', 'strength'] as const).map(item => (
                <button key={item} onClick={() => setSortBy(item)} className={cn('rounded border px-2 py-1 text-[10px] capitalize transition-all', sortBy === item ? 'border-brand-500/30 bg-brand-500/10 text-brand-400' : 'border-surface-500 bg-surface-700 text-gray-500')}>
                  {item}
                </button>
              ))}
              <button onClick={refresh} disabled={refreshing} className="flex items-center gap-1 rounded-lg border border-surface-500 bg-surface-700 px-2.5 py-1.5 text-xs text-gray-400 transition-all hover:text-white disabled:opacity-50">
                <RefreshCw size={11} className={refreshing ? 'animate-spin' : ''} />
                {refreshing ? 'Fetching NSE...' : 'Refresh'}
              </button>
            </div>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto pb-4">
            {signals.length === 0 && !refreshing && (
              <div className="flex flex-col items-center justify-center py-16 text-gray-500">
                <Zap size={28} className="mb-3 opacity-40" />
                <p className="text-sm">No live signals are loaded right now.</p>
                <button onClick={refresh} className="mt-4 text-xs text-brand-400 underline">Force refresh</button>
              </div>
            )}
            {filtered.map((signal, index) => <SignalCard key={signal.id} signal={signal} index={index} />)}
          </div>
        </>
      )}

      {activeView === 'compare' && <CompareBoard />}
      {activeView === 'rotation' && <RotationBoard />}
      {activeView === 'events' && <EventHeatmap />}
      {activeView === 'impact' && <ImpactSimulator />}
      {activeView === 'alerts' && <AlertBuilder />}
      {activeView === 'lab' && <StrategyLab />}
      {activeView === 'watchlist' && <WatchlistBuilder />}
      {activeView === 'earnings' && <EarningsRadar />}
      {activeView === 'explain' && <ExplainStock />}
    </div>
  )
}
