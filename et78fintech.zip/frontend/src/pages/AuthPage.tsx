import { useState, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { TrendingUp, Eye, EyeOff, Loader2, AlertCircle, CheckCircle2, ArrowLeft } from 'lucide-react'
import { cn } from '@/lib/api'

interface AuthPageProps {
  onLogin: (token: string, username: string, userId: number) => void
}

type Screen = 'login' | 'register' | 'forgot' | 'reset'

// ── Field MUST be outside AuthPage so it never remounts on re-render ──────────
interface FieldProps {
  label: string
  value: string
  onChange: (v: string) => void
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void
  type?: string
  placeholder?: string
  autoFocus?: boolean
  showPw?: boolean
  onTogglePw?: () => void
}

function Field({ label, value, onChange, onKeyDown, type='text', placeholder='', autoFocus=false, showPw=false, onTogglePw }: FieldProps) {
  const inputType = type === 'password' ? (showPw ? 'text' : 'password') : type
  return (
    <div className="space-y-1.5">
      <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">{label}</label>
      <div className="relative">
        <input
          type={inputType}
          value={value}
          onChange={e => onChange(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={placeholder}
          autoFocus={autoFocus}
          autoComplete={type === 'password' ? 'current-password' : 'off'}
          className="w-full bg-surface-700 border border-surface-500 text-sm text-white px-4 py-3 rounded-xl outline-none focus:border-brand-500/60 placeholder-gray-600 transition-colors"
        />
        {type === 'password' && onTogglePw && (
          <button
            type="button"
            onClick={onTogglePw}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
          >
            {showPw ? <EyeOff size={15}/> : <Eye size={15}/>}
          </button>
        )}
      </div>
    </div>
  )
}

function AlertBox({ type, msg }: { type: 'error'|'success'; msg: string }) {
  if (!msg) return null
  return (
    <div className={cn(
      'flex items-center gap-2 text-[12px] rounded-lg px-3 py-2 border',
      type === 'error'
        ? 'text-neon-red bg-neon-red/5 border-neon-red/20'
        : 'text-neon-green bg-neon-green/5 border-neon-green/20'
    )}>
      {type === 'error' ? <AlertCircle size={13}/> : <CheckCircle2 size={13}/>}
      {msg}
    </div>
  )
}

export default function AuthPage({ onLogin }: AuthPageProps) {
  const [screen, setScreen]       = useState<Screen>('login')
  const [username, setUsername]   = useState('')
  const [email, setEmail]         = useState('')
  const [password, setPassword]   = useState('')
  const [confirm, setConfirm]     = useState('')
  const [resetCode, setResetCode] = useState('')
  const [showPw, setShowPw]       = useState(false)
  const [loading, setLoading]     = useState(false)
  const [error, setError]         = useState('')
  const [success, setSuccess]     = useState('')

  const clearMessages = () => { setError(''); setSuccess('') }
  const togglePw      = () => setShowPw(v => !v)

  const goTo = (s: Screen) => { setScreen(s); clearMessages() }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key !== 'Enter') return
    if (screen === 'login')    handleLogin()
    if (screen === 'register') handleRegister()
    if (screen === 'forgot')   handleForgot()
    if (screen === 'reset')    handleReset()
  }

  const handleLogin = async () => {
    if (!username || !password) { setError('Enter username/email and password'); return }
    setLoading(true); clearMessages()
    try {
      const res  = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Login failed')
      localStorage.setItem('et_token',    data.token)
      localStorage.setItem('et_username', data.username)
      localStorage.setItem('et_user_id',  String(data.user_id))
      onLogin(data.token, data.username, data.user_id)
    } catch (e: any) { setError(e.message) }
    setLoading(false)
  }

  const handleRegister = async () => {
    if (!username || !email || !password) { setError('All fields required'); return }
    if (password !== confirm) { setError('Passwords do not match'); return }
    if (password.length < 6)  { setError('Password must be at least 6 characters'); return }
    setLoading(true); clearMessages()
    try {
      const res  = await fetch('/api/auth/register', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, email, password })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Registration failed')
      localStorage.setItem('et_token',    data.token)
      localStorage.setItem('et_username', data.username)
      localStorage.setItem('et_user_id',  String(data.user_id))
      onLogin(data.token, data.username, data.user_id)
    } catch (e: any) { setError(e.message) }
    setLoading(false)
  }

  const handleForgot = async () => {
    if (!email) { setError('Enter your email'); return }
    setLoading(true); clearMessages()
    try {
      const res  = await fetch('/api/auth/forgot-password', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Failed')
      setSuccess(data.message)
      setTimeout(() => goTo('reset'), 2000)
    } catch (e: any) { setError(e.message) }
    setLoading(false)
  }

  const handleReset = async () => {
    if (!resetCode || !password) { setError('Enter reset code and new password'); return }
    if (password !== confirm)    { setError('Passwords do not match'); return }
    setLoading(true); clearMessages()
    try {
      const res  = await fetch('/api/auth/reset-password', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: resetCode, password })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Reset failed')
      setSuccess('Password reset! Redirecting to login...')
      setTimeout(() => { goTo('login'); setPassword(''); setConfirm(''); setResetCode('') }, 1500)
    } catch (e: any) { setError(e.message) }
    setLoading(false)
  }

  const btnClass = "w-full flex items-center justify-center gap-2 bg-brand-500 hover:bg-brand-400 text-surface-900 font-bold py-3 rounded-xl transition-colors disabled:opacity-60 text-sm"

  return (
    <div className="min-h-screen bg-surface-900 flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-brand-500/5 rounded-full blur-3xl"/>
      </div>

      <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="w-full max-w-md relative">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-brand-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <TrendingUp size={22} className="text-surface-900"/>
          </div>
          <h1 className="text-2xl font-black text-white">ET Alpha</h1>
          <p className="text-sm text-gray-500 mt-1">AI Market Co-Pilot</p>
        </div>

        <div className="bg-surface-800 border border-surface-500/50 rounded-2xl p-8 shadow-2xl">
          <AnimatePresence mode="wait">

            {screen === 'login' && (
              <motion.div key="login" initial={{opacity:0,x:-20}} animate={{opacity:1,x:0}} exit={{opacity:0,x:20}} className="space-y-5">
                <div>
                  <h2 className="text-lg font-bold text-white">Welcome back</h2>
                  <p className="text-[12px] text-gray-500 mt-0.5">Your portfolio data is safe and waiting</p>
                </div>
                <Field label="Username or Email" value={username} onChange={setUsername} onKeyDown={handleKeyDown} placeholder="akshat or akshat@email.com" autoFocus/>
                <Field label="Password" value={password} onChange={setPassword} onKeyDown={handleKeyDown} type="password" placeholder="••••••••" showPw={showPw} onTogglePw={togglePw}/>
                <AlertBox type="error"   msg={error}/>
                <AlertBox type="success" msg={success}/>
                <button onClick={handleLogin} disabled={loading} className={btnClass}>
                  {loading && <Loader2 size={16} className="animate-spin"/>}
                  {loading ? 'Signing in...' : 'Sign In'}
                </button>
                <div className="flex items-center justify-between text-[12px]">
                  <button onClick={() => goTo('register')} className="text-brand-400 hover:text-brand-300">Create account</button>
                  <button onClick={() => goTo('forgot')}   className="text-gray-500 hover:text-gray-300">Forgot password?</button>
                </div>
              </motion.div>
            )}

            {screen === 'register' && (
              <motion.div key="register" initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-20}} className="space-y-4">
                <div className="flex items-center gap-2">
                  <button onClick={() => goTo('login')} className="text-gray-500 hover:text-white"><ArrowLeft size={16}/></button>
                  <div>
                    <h2 className="text-lg font-bold text-white">Create account</h2>
                    <p className="text-[12px] text-gray-500">Your data is saved forever</p>
                  </div>
                </div>
                <Field label="Username"         value={username} onChange={setUsername} onKeyDown={handleKeyDown} placeholder="akshat" autoFocus/>
                <Field label="Email"            value={email}    onChange={setEmail}    onKeyDown={handleKeyDown} type="email" placeholder="you@email.com"/>
                <Field label="Password"         value={password} onChange={setPassword} onKeyDown={handleKeyDown} type="password" placeholder="Min 6 characters" showPw={showPw} onTogglePw={togglePw}/>
                <Field label="Confirm Password" value={confirm}  onChange={setConfirm}  onKeyDown={handleKeyDown} type="password" placeholder="Repeat password"   showPw={showPw} onTogglePw={togglePw}/>
                <AlertBox type="error"   msg={error}/>
                <AlertBox type="success" msg={success}/>
                <button onClick={handleRegister} disabled={loading} className={btnClass}>
                  {loading && <Loader2 size={16} className="animate-spin"/>}
                  {loading ? 'Creating account...' : 'Create Account'}
                </button>
              </motion.div>
            )}

            {screen === 'forgot' && (
              <motion.div key="forgot" initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-20}} className="space-y-5">
                <div className="flex items-center gap-2">
                  <button onClick={() => goTo('login')} className="text-gray-500 hover:text-white"><ArrowLeft size={16}/></button>
                  <div>
                    <h2 className="text-lg font-bold text-white">Reset password</h2>
                    <p className="text-[12px] text-gray-500">Reset code appears in backend terminal</p>
                  </div>
                </div>
                <Field label="Email" value={email} onChange={setEmail} onKeyDown={handleKeyDown} type="email" placeholder="your registered email" autoFocus/>
                <AlertBox type="error"   msg={error}/>
                <AlertBox type="success" msg={success}/>
                <button onClick={handleForgot} disabled={loading} className={btnClass}>
                  {loading && <Loader2 size={16} className="animate-spin"/>}
                  {loading ? 'Sending...' : 'Send Reset Code'}
                </button>
                <button onClick={() => goTo('reset')} className="w-full text-center text-[12px] text-gray-500 hover:text-gray-300">
                  Already have a reset code? →
                </button>
              </motion.div>
            )}

            {screen === 'reset' && (
              <motion.div key="reset" initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-20}} className="space-y-5">
                <div className="flex items-center gap-2">
                  <button onClick={() => goTo('forgot')} className="text-gray-500 hover:text-white"><ArrowLeft size={16}/></button>
                  <div>
                    <h2 className="text-lg font-bold text-white">Enter reset code</h2>
                    <p className="text-[12px] text-gray-500">Check your backend CMD window</p>
                  </div>
                </div>
                <Field label="Reset Code"         value={resetCode} onChange={setResetCode} onKeyDown={handleKeyDown} placeholder="ABC123" autoFocus/>
                <Field label="New Password"       value={password}  onChange={setPassword}  onKeyDown={handleKeyDown} type="password" placeholder="Min 6 characters" showPw={showPw} onTogglePw={togglePw}/>
                <Field label="Confirm Password"   value={confirm}   onChange={setConfirm}   onKeyDown={handleKeyDown} type="password" placeholder="Repeat password"   showPw={showPw} onTogglePw={togglePw}/>
                <AlertBox type="error"   msg={error}/>
                <AlertBox type="success" msg={success}/>
                <button onClick={handleReset} disabled={loading} className={btnClass}>
                  {loading && <Loader2 size={16} className="animate-spin"/>}
                  {loading ? 'Resetting...' : 'Reset Password'}
                </button>
              </motion.div>
            )}

          </AnimatePresence>
        </div>

        <p className="text-center text-[11px] text-gray-600 mt-4">
          Data stored in <code className="text-gray-500">et78/data/etAlpha.db</code>
        </p>
      </motion.div>
    </div>
  )
}
