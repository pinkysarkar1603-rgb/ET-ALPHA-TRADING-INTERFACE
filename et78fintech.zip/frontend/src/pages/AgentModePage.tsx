import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Bot, Play, CheckCircle2, XCircle, AlertTriangle, Loader2,
  Globe, TrendingUp, Shield, Zap, Terminal, ChevronRight,
  ThumbsUp, ThumbsDown, RefreshCw, ExternalLink, Lock
} from 'lucide-react'
import { useStore } from '@/store'
import { cn, formatINR } from '@/lib/api'

const BROKERS = [
  { id: 'demo',      label: 'Demo Mode',    desc: 'No login needed — uses live NSE data', icon: '🎯', safe: true  },
  { id: 'groww',     label: 'Groww',        desc: 'Opens Groww in browser',               icon: '🟢', safe: false },
  { id: 'zerodha',   label: 'Zerodha Kite', desc: 'Opens Kite in browser',               icon: '🔵', safe: false },
  { id: 'sharekhan', label: 'Sharekhan',    desc: 'Opens Sharekhan in browser',           icon: '🟠', safe: false },
]

const RISK_PROFILES = [
  { id: 'conservative', label: 'Conservative', desc: 'Blue chips only, min volatility' },
  { id: 'moderate',     label: 'Moderate',     desc: 'Mix of growth + stability' },
  { id: 'aggressive',   label: 'Aggressive',   desc: 'High growth, higher risk' },
]

const AGENT_STEPS = [
  { key: 'research',  label: 'Research Agent',   icon: Globe,      desc: 'Fetching live NSE prices for 15 stocks' },
  { key: 'analysis',  label: 'Analysis Agent',   icon: TrendingUp, desc: 'Groq LLaMA scoring opportunities' },
  { key: 'browser',   label: 'Browser Agent',    icon: ExternalLink,desc: 'Playwright controlling broker session' },
  { key: 'trade',     label: 'Trade Agent',      icon: Zap,        desc: 'Calculating order quantities' },
  { key: 'risk',      label: 'Risk Agent',       icon: Shield,     desc: 'Validating risk rules + guardrails' },
  { key: 'execution', label: 'Execution Agent',  icon: CheckCircle2,desc: 'Staging orders on broker' },
]

interface TradeOrder {
  ticker: string; company: string; action: string; qty: number
  price: number; total_value: number; reason: string; risk: string; score: number
}

interface AgentUpdate {
  step: string; status: string; ts: number
}

function normalizeAuditStatus(status?: string): 'running' | 'done' | 'error' {
  if (status === 'running' || status === 'done' || status === 'error') return status
  return 'done'
}

export default function AgentModePage() {
  const { addAuditEntry, setAgentStatus, addNotification } = useStore()

  const [phase, setPhase]         = useState<'setup'|'running'|'confirm'|'executing'|'done'>('setup')
  const [broker, setBroker]       = useState('demo')
  const [budget, setBudget]       = useState(50000)
  const [riskProfile, setRisk]    = useState('moderate')
  const [userGoal, setGoal]       = useState('Find me the best 2 stocks to buy today based on live NSE data and momentum')
  const [sessionId, setSessionId] = useState<string|null>(null)
  const [updates, setUpdates]     = useState<AgentUpdate[]>([])
  const [pendingTrades, setPendingTrades] = useState<TradeOrder[]>([])
  const [riskWarnings, setRiskWarnings]   = useState<string[]>([])
  const [auditLog, setAuditLog]   = useState<any[]>([])
  const [executed, setExecuted]   = useState<any[]>([])
  const [activeStep, setActiveStep] = useState(0)
  const [error, setError]         = useState<string|null>(null)
  const pollRef = useRef<ReturnType<typeof setInterval>>()
  const updatesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    updatesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [updates])

  const startAgent = async () => {
    setPhase('running')
    setUpdates([])
    setPendingTrades([])
    setRiskWarnings([])
    setAuditLog([])
    setActiveStep(0)
    setError(null)

    setAgentStatus('radar', 'running', 'Agentic pipeline starting...')
    addAuditEntry({ agentName:'Orchestrator', step:'Pipeline initiated', input:userGoal, output:'', status:'running' })

    try {
      const res = await fetch('/api/agent/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_goal: userGoal, broker, budget, risk_profile: riskProfile }),
      })
      if (!res.ok) throw new Error(`Backend returned ${res.status}`)
      const { session_id } = await res.json()
      setSessionId(session_id)

      // Poll for updates every 1s
      pollRef.current = setInterval(async () => {
        try {
          const statusRes = await fetch(`/api/agent/status/${session_id}`)
          if (!statusRes.ok) return
          const data = await statusRes.json()

          if (data.updates) {
            setUpdates(data.updates)
            setActiveStep(Math.min(data.updates.length, 5))
            data.updates.forEach((u: AgentUpdate) => {
              addAuditEntry({ agentName: u.step.split(':')[0] || 'Agent', step: u.step, input:'', output:'', status: normalizeAuditStatus(u.status) })
            })
          }

          if (data.status === 'awaiting_confirmation' && data.state) {
            clearInterval(pollRef.current)
            setPendingTrades(data.state.pending_trades || [])
            setRiskWarnings(data.state.risk_warnings || [])
            setAuditLog(data.state.audit_log || [])
            setPhase('confirm')
            setAgentStatus('radar', 'done', 'Awaiting user confirmation')
            addNotification({ type:'agent', title:'Agent ready — confirm trades', body:`${data.state.pending_trades?.length || 0} orders prepared` })
          }

          if (data.status === 'error') {
            clearInterval(pollRef.current)
            const lastMsg = data.updates?.[data.updates.length - 1]?.step || 'Pipeline error'
            setError(lastMsg)
            setPhase('setup')
            setAgentStatus('radar', 'error', 'Pipeline failed')
          }
        } catch {}
      }, 1000)

    } catch (err: any) {
      setError(`Backend not running. Start the FastAPI backend:\n  cd backend && pip install -r requirements.txt && uvicorn api.main:app --reload\n\nError: ${err.message}`)
      setPhase('setup')
      setAgentStatus('radar', 'error', 'Backend offline')
    }
  }

  const confirmTrades = async (confirmed: boolean) => {
    if (!confirmed) {
      setPhase('setup')
      addAuditEntry({ agentName:'User', step:'User rejected trade plan', input:'', output:'Trades cancelled', status:'done' })
      addNotification({ type:'agent', title:'Trades cancelled', body:'No orders placed.' })
      return
    }

    if (!sessionId) {
      setError('Session lost — please run the agent again.')
      setPhase('setup')
      return
    }

    setPhase('executing')
    addAuditEntry({ agentName:'ExecutionAgent', step:'User confirmed — sending to backend', input:'', output:'', status:'running' })

    try {
      const res = await fetch('/api/agent/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: sessionId, confirmed: true }),
      })
      if (!res.ok) throw new Error(`Confirm API returned ${res.status}: ${await res.text()}`)

      // Poll for execution completion
      pollRef.current = setInterval(async () => {
        try {
          const statusRes = await fetch(`/api/agent/status/${sessionId}`)
          if (!statusRes.ok) return
          const data = await statusRes.json()

          if (data.updates) {
            setUpdates(data.updates)
            data.updates.slice(-3).forEach((u: AgentUpdate) => {
              addAuditEntry({ agentName:'ExecutionAgent', step:u.step, input:'', output:'', status: normalizeAuditStatus(u.status) })
            })
          }

          if (data.status === 'completed') {
            clearInterval(pollRef.current)
            const executedTrades = data.state?.executed_trades || pendingTrades.map(t => ({ ...t, status: 'order_staged' }))
            setExecuted(executedTrades)
            setPhase('done')
            setAgentStatus('radar', 'done', `${executedTrades.length} orders placed on ${broker}`)
            addNotification({
              type: 'agent',
              title: `${executedTrades.length} orders staged on ${broker}`,
              body: `Open ${broker} to confirm and finalise execution`,
            })
          }

          if (data.status === 'error') {
            clearInterval(pollRef.current)
            const lastMsg = data.updates?.[data.updates.length - 1]?.step || 'Execution error'
            setError(lastMsg)
            setPhase('confirm') // Go back so user can retry
            setAgentStatus('radar', 'error', 'Execution failed')
          }
        } catch {}
      }, 1000)

    } catch (err: any) {
      setError(`Execution failed: ${err.message}`)
      setPhase('confirm')
      setAgentStatus('radar', 'error', 'Execution failed')
    }
  }

  const reset = () => {
    clearInterval(pollRef.current)
    setPhase('setup'); setUpdates([]); setPendingTrades([]); setRiskWarnings([]); setExecuted([]); setSessionId(null); setError(null)
  }

  return (
    <div className="space-y-4 pb-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 bg-brand-500/10 rounded-xl flex items-center justify-center border border-brand-500/30">
          <Bot size={18} className="text-brand-400" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-white">Agentic Trade Mode</h2>
          <p className="text-[11px] text-gray-400">
            6-agent LangGraph pipeline · Playwright browser control · Human-in-the-loop confirmation
          </p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <span className="text-[10px] bg-neon-green/10 border border-neon-green/20 text-neon-green px-2 py-1 rounded-full font-bold">
            AGENTIC MODE
          </span>
          {phase !== 'setup' && (
            <button onClick={reset} className="p-1.5 text-gray-500 hover:text-white bg-surface-600 rounded-lg">
              <RefreshCw size={12} />
            </button>
          )}
        </div>
      </div>

      {/* Safety disclaimer */}
      <div className="flex items-start gap-2 bg-orange-500/5 border border-orange-500/20 rounded-xl px-4 py-3">
        <Lock size={13} className="text-orange-400 mt-0.5 flex-shrink-0" />
        <p className="text-[11px] text-orange-300 leading-relaxed">
          <span className="font-bold">Human-in-the-loop guarantee:</span> The agent NEVER places orders without your explicit confirmation.
          You see every trade before it happens. You can reject at any time. Not financial advice.
        </p>
      </div>

      {/* Agent pipeline visualization */}
      <div className="grid grid-cols-6 gap-2">
        {AGENT_STEPS.map((step, i) => {
          const Icon  = step.icon
          const done  = phase === 'done' || (phase === 'confirm' && i < 5) || (phase === 'executing' && i < 5)
          const active = phase === 'running' && i === activeStep
          const exec  = phase === 'executing' && i === 5
          return (
            <div key={step.key} className="flex flex-col items-center gap-1">
              <div className={cn(
                'w-10 h-10 rounded-xl flex items-center justify-center border transition-all',
                done || exec ? 'bg-neon-green/10 border-neon-green/30' :
                active ? 'bg-brand-500/10 border-brand-500/40 animate-pulse' :
                'bg-surface-700 border-surface-500/40'
              )}>
                {active ? <Loader2 size={16} className="text-brand-400 animate-spin" /> :
                 done   ? <CheckCircle2 size={16} className="text-neon-green" /> :
                 exec   ? <Loader2 size={16} className="text-brand-400 animate-spin" /> :
                 <Icon size={14} className="text-gray-600" />}
              </div>
              <p className={cn('text-[9px] text-center leading-tight',
                done || active ? 'text-gray-300' : 'text-gray-600')}>
                {step.label}
              </p>
              {i < AGENT_STEPS.length - 1 && (
                <div className="hidden" /> // connector handled by grid
              )}
            </div>
          )
        })}
      </div>

      {/* ── PHASE: SETUP ── */}
      <AnimatePresence mode="wait">
        {phase === 'setup' && (
          <motion.div key="setup" initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0 }} className="space-y-4">
            {/* User goal */}
            <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-2">
              <label className="text-xs font-semibold text-gray-300">What should the agent do?</label>
              <textarea value={userGoal} onChange={e => setGoal(e.target.value)} rows={2}
                className="w-full bg-surface-600 border border-surface-500 text-xs text-gray-200 placeholder-gray-600 px-3 py-2 rounded-lg outline-none focus:border-brand-500/50 resize-none" />
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Find the best 2 stocks to buy today under ₹50K',
                  'Check if I should sell any holdings at a loss for tax',
                  'Buy 1 large cap stock with the lowest risk today',
                ].map(s => (
                  <button key={s} onClick={() => setGoal(s)}
                    className="text-[10px] bg-surface-600 border border-surface-500 text-gray-400 hover:text-white px-2 py-1 rounded transition-all">
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Broker */}
              <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-2">
                <label className="text-xs font-semibold text-gray-300">Broker</label>
                <div className="space-y-1.5">
                  {BROKERS.map(b => (
                    <button key={b.id} onClick={() => setBroker(b.id)}
                      className={cn('w-full flex items-center gap-2 px-3 py-2 rounded-lg border text-left transition-all',
                        broker === b.id ? 'bg-brand-500/10 border-brand-500/30' : 'bg-surface-600/50 border-surface-500/40 hover:border-surface-400')}>
                      <span style={{ fontSize:14 }}>{b.icon}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-semibold text-white">{b.label}</p>
                        <p className="text-[10px] text-gray-500 truncate">{b.desc}</p>
                      </div>
                      {b.safe && <span className="text-[9px] bg-neon-green/10 text-neon-green px-1.5 py-0.5 rounded">SAFE</span>}
                      {broker === b.id && <CheckCircle2 size={12} className="text-brand-400 flex-shrink-0" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Budget + Risk */}
              <div className="space-y-3">
                <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-3">
                  <label className="text-xs font-semibold text-gray-300">Budget: ₹{budget.toLocaleString('en-IN')}</label>
                  <input type="range" min={5000} max={500000} step={5000} value={budget}
                    onChange={e => setBudget(Number(e.target.value))}
                    className="w-full accent-brand-500 h-1.5" />
                  <div className="flex justify-between text-[9px] text-gray-600">
                    <span>₹5K</span><span>₹5L</span>
                  </div>
                </div>

                <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-2">
                  <label className="text-xs font-semibold text-gray-300">Risk profile</label>
                  <div className="space-y-1.5">
                    {RISK_PROFILES.map(r => (
                      <button key={r.id} onClick={() => setRisk(r.id)}
                        className={cn('w-full flex items-center gap-2 px-3 py-2 rounded-lg border text-left transition-all',
                          riskProfile === r.id ? 'bg-brand-500/10 border-brand-500/30' : 'bg-surface-600/50 border-surface-500/40 hover:border-surface-400')}>
                        <div className="flex-1">
                          <p className="text-[11px] font-semibold text-white">{r.label}</p>
                          <p className="text-[10px] text-gray-500">{r.desc}</p>
                        </div>
                        {riskProfile === r.id && <CheckCircle2 size={12} className="text-brand-400" />}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Error display */}
            {error && (
              <div className="flex items-start gap-2 bg-neon-red/5 border border-neon-red/20 rounded-xl px-4 py-3">
                <XCircle size={13} className="text-neon-red mt-0.5 flex-shrink-0" />
                <p className="text-[11px] text-neon-red/90 leading-relaxed whitespace-pre-wrap">{error}</p>
              </div>
            )}

            {/* Launch button */}
            <button onClick={startAgent}
              className="w-full flex items-center justify-center gap-3 bg-brand-500 text-surface-900 font-black py-4 rounded-xl hover:bg-brand-400 transition-colors text-sm">
              <Play size={18} />
              Launch 6-Agent Pipeline
              <span className="text-[10px] font-normal opacity-70">Research → Analysis → Browser → Trade → Risk → Execute</span>
            </button>
          </motion.div>
        )}

        {/* ── PHASE: RUNNING ── */}
        {phase === 'running' && (
          <motion.div key="running" initial={{ opacity:0 }} animate={{ opacity:1 }} className="space-y-3">
            <div className="bg-surface-700 border border-surface-500/50 rounded-xl overflow-hidden">
              <div className="flex items-center gap-2 px-4 py-2.5 border-b border-surface-500/30 bg-brand-500/5">
                <Terminal size={13} className="text-brand-400" />
                <span className="text-xs font-semibold text-white">Agent Pipeline Running</span>
                <Loader2 size={12} className="text-brand-400 animate-spin ml-auto" />
              </div>
              <div className="p-3 space-y-1.5 max-h-64 overflow-y-auto font-mono">
                {updates.map((u, i) => (
                  <motion.div key={i} initial={{ opacity:0, x:-4 }} animate={{ opacity:1, x:0 }}
                    className="flex items-start gap-2 text-[11px]">
                    <span className="text-gray-600 flex-shrink-0">{new Date(u.ts).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}</span>
                    <CheckCircle2 size={10} className="text-neon-green mt-0.5 flex-shrink-0" />
                    <span className="text-gray-300">{u.step}</span>
                  </motion.div>
                ))}
                {updates.length === 0 && (
                  <p className="text-[11px] text-gray-500 animate-pulse">Initialising pipeline...</p>
                )}
                <div ref={updatesEndRef} />
              </div>
            </div>
          </motion.div>
        )}

        {/* ── PHASE: CONFIRM ── */}
        {phase === 'confirm' && (
          <motion.div key="confirm" initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} className="space-y-4">
            <div className="bg-brand-500/5 border border-brand-500/30 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Shield size={15} className="text-brand-400" />
                <p className="text-sm font-bold text-white">Agent found {pendingTrades.length} trades — your approval required</p>
              </div>

              {/* Risk warnings */}
              {riskWarnings.length > 0 && (
                <div className="mb-3 space-y-1">
                  {riskWarnings.map((w, i) => (
                    <div key={i} className="flex items-center gap-2 text-[11px] text-orange-300 bg-orange-500/5 border border-orange-500/20 rounded-lg px-3 py-2">
                      <AlertTriangle size={11} className="flex-shrink-0" /> {w}
                    </div>
                  ))}
                </div>
              )}

              {/* Trade cards */}
              <div className="space-y-3 mb-4">
                {pendingTrades.map((trade, i) => (
                  <motion.div key={trade.ticker} initial={{ opacity:0, x:-8 }} animate={{ opacity:1, x:0 }} transition={{ delay:i*0.1 }}
                    className="bg-surface-700 border border-surface-500/50 rounded-xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-black text-white">{trade.ticker}</span>
                          <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded',
                            trade.action === 'BUY' ? 'bg-neon-green/10 text-neon-green' : 'bg-neon-red/10 text-neon-red')}>
                            {trade.action}
                          </span>
                          <span className="text-[10px] bg-brand-500/10 text-brand-400 px-1.5 py-0.5 rounded font-mono">
                            Score: {trade.score}/100
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-400 mt-0.5">{trade.company}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-black font-mono text-white">{formatINR(trade.total_value, true)}</p>
                        <p className="text-[11px] text-gray-400">{trade.qty} shares @ ₹{trade.price.toFixed(2)}</p>
                      </div>
                    </div>
                    <p className="text-[11px] text-gray-300 leading-relaxed mb-1">{trade.reason}</p>
                    <p className="text-[10px] text-orange-400">⚠ {trade.risk}</p>
                  </motion.div>
                ))}
              </div>

              {/* Total */}
              <div className="flex items-center justify-between bg-surface-700 rounded-xl px-4 py-3 mb-4">
                <span className="text-xs text-gray-400">Total order value</span>
                <span className="text-sm font-black font-mono text-white">
                  {formatINR(pendingTrades.reduce((s,t) => s+t.total_value, 0), true)}
                </span>
              </div>

              {/* Confirm / Reject */}
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => confirmTrades(false)}
                  className="flex items-center justify-center gap-2 bg-neon-red/10 border border-neon-red/20 text-neon-red py-3 rounded-xl hover:bg-neon-red/20 transition-colors font-semibold">
                  <ThumbsDown size={15} /> Reject All Trades
                </button>
                <button onClick={() => confirmTrades(true)}
                  className="flex items-center justify-center gap-2 bg-neon-green/10 border border-neon-green/30 text-neon-green py-3 rounded-xl hover:bg-neon-green/20 transition-colors font-bold text-sm">
                  <ThumbsUp size={15} /> Confirm & Execute
                </button>
              </div>
            </div>

            {/* Audit trail */}
            <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-3">
              <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-2 font-medium">Agent audit trail</p>
              <div className="space-y-1 max-h-40 overflow-y-auto font-mono">
                {updates.map((u, i) => (
                  <div key={i} className="flex items-center gap-2 text-[10px]">
                    <CheckCircle2 size={9} className="text-neon-green flex-shrink-0" />
                    <span className="text-gray-400">{u.step}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* ── PHASE: EXECUTING ── */}
        {phase === 'executing' && (
          <motion.div key="executing" initial={{ opacity:0 }} animate={{ opacity:1 }}
            className="bg-brand-500/5 border border-brand-500/30 rounded-xl p-6 text-center space-y-4">
            <Loader2 size={32} className="text-brand-400 animate-spin mx-auto" />
            <p className="text-sm font-bold text-white">Execution Agent working...</p>
            <p className="text-xs text-gray-400">Playwright is navigating to {broker} and staging orders</p>
            <div className="space-y-1.5 text-left max-h-40 overflow-y-auto font-mono">
              {updates.slice(-6).map((u, i) => (
                <div key={i} className="flex items-center gap-2 text-[10px]">
                  <CheckCircle2 size={9} className="text-neon-green" />
                  <span className="text-gray-400">{u.step}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* ── PHASE: DONE ── */}
        {phase === 'done' && (
          <motion.div key="done" initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} className="space-y-4">
            <div className="bg-neon-green/5 border border-neon-green/30 rounded-xl p-5 text-center space-y-3">
              <CheckCircle2 size={36} className="text-neon-green mx-auto" />
              <p className="text-sm font-bold text-white">{executed.length} orders staged on {broker}</p>
              <p className="text-xs text-gray-400">
                Open your {broker} app and confirm to finalise. Orders are staged but NOT yet executed until you press Buy on the broker.
              </p>
            </div>

            <div className="space-y-2">
              {executed.map((t, i) => (
                <div key={i} className="flex items-center gap-3 bg-surface-700 border border-neon-green/20 rounded-xl px-4 py-3">
                  <CheckCircle2 size={14} className="text-neon-green flex-shrink-0" />
                  <span className="text-sm font-bold text-white">{t.ticker}</span>
                  <span className={cn('text-xs font-bold', t.action==='BUY'?'text-neon-green':'text-neon-red')}>{t.action}</span>
                  <span className="text-xs text-gray-400">{t.qty} shares @ ₹{t.price}</span>
                  <span className="ml-auto text-xs font-mono font-bold text-white">{formatINR(t.total_value, true)}</span>
                  <span className="text-[10px] bg-neon-green/10 text-neon-green px-2 py-0.5 rounded">STAGED</span>
                </div>
              ))}
            </div>

            <button onClick={reset}
              className="w-full flex items-center justify-center gap-2 bg-surface-700 border border-surface-500 text-gray-300 hover:text-white py-3 rounded-xl transition-colors text-sm font-medium">
              <RefreshCw size={14} /> Run Agent Again
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
