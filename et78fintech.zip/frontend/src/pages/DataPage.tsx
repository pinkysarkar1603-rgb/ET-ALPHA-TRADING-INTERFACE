import { useEffect, useMemo, useState } from 'react'
import { BrainCircuit, CandlestickChart, Database, Loader2, Maximize2, RefreshCw, Search, X } from 'lucide-react'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  PolarAngleAxis,
  PolarGrid,
  Radar,
  RadarChart,
  RadialBar,
  RadialBarChart,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import StockChart from '@/components/charts/StockChart'
import { analyzeTickerWithAI, cn, fetchMarketDashboard, groqChat, type MarketIndicator } from '@/lib/api'

type CandlePoint = { time: string; open: number; high: number; low: number; close: number; volume: number }
type IndicatorCategory = 'Trend' | 'Momentum' | 'Volume' | 'Volatility' | 'Support/Resistance' | 'Price/Chart' | 'Cycle/Timing' | 'Advanced/Hybrid' | 'Breadth' | 'Custom'
type IndicatorMeta = { name: string; category: IndicatorCategory; description: string }
type IndicatorSnapshot = { name: string; category: IndicatorCategory; status: 'live' | 'proxy'; value: string; secondary: string; explanation: string; points: Array<{ label: string; value: number }> }

const INDICATOR_GROUPS: Array<{ category: IndicatorCategory; items: string[] }> = [
  { category: 'Trend', items: ['Moving Average (SMA)', 'Exponential Moving Average (EMA)', 'Weighted Moving Average (WMA)', 'Hull Moving Average (HMA)', 'Double EMA (DEMA)', 'Triple EMA (TEMA)', 'Variable Moving Average (VMA)', 'Moving Average Ribbon', 'Moving Average Envelope', 'MACD (Moving Average Convergence Divergence)', 'ADX (Average Directional Index)', 'DMI (Directional Movement Index)', 'Parabolic SAR', 'Supertrend', 'Ichimoku Cloud', 'Aroon Indicator', 'Aroon Oscillator', 'TRIX', 'Vortex Indicator', 'Guppy Multiple Moving Average (GMMA)'] },
  { category: 'Momentum', items: ['RSI (Relative Strength Index)', 'Stochastic Oscillator', 'Stochastic RSI', 'Commodity Channel Index (CCI)', 'Williams %R', 'Momentum Indicator', 'Rate of Change (ROC)', 'Relative Momentum Index (RMI)', 'True Strength Index (TSI)', 'Ultimate Oscillator', 'Chande Momentum Oscillator (CMO)', 'Connors RSI', 'Fisher Transform'] },
  { category: 'Volume', items: ['Volume', 'On-Balance Volume (OBV)', 'Volume Weighted Average Price (VWAP)', 'Anchored VWAP', 'Volume Oscillator', 'Accumulation/Distribution Line', 'Chaikin Money Flow (CMF)', 'Chaikin Oscillator', 'Ease of Movement (EOM)', 'Force Index', 'Klinger Volume Oscillator', 'Negative Volume Index (NVI)', 'Positive Volume Index (PVI)', 'Volume Profile', 'Volume Profile Visible Range (VPVR)', 'Market Facilitation Index'] },
  { category: 'Volatility', items: ['Bollinger Bands', 'Bollinger Band Width', 'Average True Range (ATR)', 'Keltner Channels', 'Donchian Channels', 'Standard Deviation', 'Chaikin Volatility', 'Historical Volatility'] },
  { category: 'Support/Resistance', items: ['Pivot Points (Classic)', 'Fibonacci Retracement', 'Fibonacci Extension', 'Fibonacci Fan', 'Fibonacci Arc', 'Camarilla Pivot Points', 'Woodie Pivot Points', 'DeMark Pivot Points', 'Gann Levels', 'Gann Fan', 'Gann Box', 'Andrews Pitchfork'] },
  { category: 'Price/Chart', items: ['Heikin Ashi', 'Renko', 'Kagi', 'Line Break', 'Zig Zag', 'Fractals (Bill Williams)', 'Swing High / Swing Low'] },
  { category: 'Cycle/Timing', items: ['Schaff Trend Cycle', 'Detrended Price Oscillator (DPO)', 'Hilbert Transform', 'Ehlers Sine Wave', 'Ehlers Fisher Transform'] },
  { category: 'Advanced/Hybrid', items: ['Elder Ray Index', 'Elder Force Index', 'Market Profile', 'Volume Profile (advanced)', 'Linear Regression Channel', 'Linear Regression Line', 'Standard Error Bands'] },
  { category: 'Breadth', items: ['Advance/Decline Line', 'Advance/Decline Ratio', 'McClellan Oscillator', 'McClellan Summation Index', 'TRIN (Arms Index)', 'TICK Index'] },
  { category: 'Custom', items: ['Squeeze Momentum Indicator', 'WaveTrend Oscillator', 'QQE (Quantitative Qualitative Estimation)', 'SSL Channel', 'Half Trend Indicator', 'Range Filter Indicator', 'LazyBear Indicators (various scripts)'] },
]

const INDICATOR_CATALOG: IndicatorMeta[] = INDICATOR_GROUPS.flatMap(group =>
  group.items.map(name => ({ name, category: group.category, description: `${name} is catalogued in the ${group.category.toLowerCase()} block and can be explored from live ET Alpha market data.` })),
)

function StatCard({ label, value, tone = 'text-white' }: { label: string; value: string; tone?: string }) {
  return <div className="rounded-2xl border border-surface-500/50 bg-surface-700/80 p-4"><p className="text-[10px] uppercase tracking-[0.18em] text-gray-500">{label}</p><p className={cn('mt-2 font-mono text-2xl font-black', tone)}>{value}</p></div>
}

function ChartCard({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return <div className="rounded-2xl border border-surface-500/50 bg-surface-700/80 p-4"><p className="text-[10px] uppercase tracking-[0.18em] text-gray-500">{title}</p><h3 className="mt-1 text-lg font-bold text-white">{subtitle}</h3><div className="mt-4 h-[260px]">{children}</div></div>
}

function sma(values: number[], period: number) {
  if (values.length < period) return 0
  const slice = values.slice(-period)
  return slice.reduce((sum, value) => sum + value, 0) / period
}

function ema(values: number[], period: number) {
  if (values.length < period) return 0
  const multiplier = 2 / (period + 1)
  let result = sma(values.slice(0, period), period)
  for (let index = period; index < values.length; index += 1) result = (values[index] - result) * multiplier + result
  return result
}

function wma(values: number[], period: number) {
  if (values.length < period) return 0
  const slice = values.slice(-period)
  const denominator = period * (period + 1) / 2
  return slice.reduce((sum, value, index) => sum + value * (index + 1), 0) / denominator
}

function stddev(values: number[], period: number) {
  if (values.length < period) return 0
  const slice = values.slice(-period)
  const avg = sma(slice, slice.length)
  const variance = slice.reduce((sum, value) => sum + (value - avg) ** 2, 0) / slice.length
  return Math.sqrt(variance)
}

function roc(values: number[], period: number) {
  if (values.length <= period) return 0
  const base = values[values.length - period - 1]
  if (!base) return 0
  return ((values[values.length - 1] - base) / base) * 100
}

function stochastic(highs: number[], lows: number[], closes: number[], period = 14) {
  if (closes.length < period || highs.length < period || lows.length < period) return 0
  const recentHigh = Math.max(...highs.slice(-period))
  const recentLow = Math.min(...lows.slice(-period))
  if (recentHigh === recentLow) return 0
  return ((closes[closes.length - 1] - recentLow) / (recentHigh - recentLow)) * 100
}

function williamsR(highs: number[], lows: number[], closes: number[], period = 14) {
  return stochastic(highs, lows, closes, period) - 100
}

function cci(highs: number[], lows: number[], closes: number[], period = 20) {
  if (closes.length < period) return 0
  const typical = highs.map((high, index) => (high + lows[index] + closes[index]) / 3)
  const slice = typical.slice(-period)
  const avg = sma(slice, slice.length)
  const meanDeviation = slice.reduce((sum, value) => sum + Math.abs(value - avg), 0) / period
  if (!meanDeviation) return 0
  return (slice[slice.length - 1] - avg) / (0.015 * meanDeviation)
}

function obv(closes: number[], volumes: number[]) {
  let total = 0
  for (let index = 1; index < closes.length; index += 1) {
    if (closes[index] > closes[index - 1]) total += volumes[index]
    else if (closes[index] < closes[index - 1]) total -= volumes[index]
  }
  return total
}

function vwap(highs: number[], lows: number[], closes: number[], volumes: number[]) {
  let cumulativePriceVolume = 0
  let cumulativeVolume = 0
  for (let index = 0; index < closes.length; index += 1) {
    const typicalPrice = (highs[index] + lows[index] + closes[index]) / 3
    cumulativePriceVolume += typicalPrice * volumes[index]
    cumulativeVolume += volumes[index]
  }
  return cumulativeVolume ? cumulativePriceVolume / cumulativeVolume : 0
}

function cmf(highs: number[], lows: number[], closes: number[], volumes: number[], period = 20) {
  if (closes.length < period) return 0
  const recent = closes.length - period
  let mfv = 0
  let vol = 0
  for (let index = recent; index < closes.length; index += 1) {
    const range = highs[index] - lows[index]
    const multiplier = range === 0 ? 0 : ((closes[index] - lows[index]) - (highs[index] - closes[index])) / range
    mfv += multiplier * volumes[index]
    vol += volumes[index]
  }
  return vol ? mfv / vol : 0
}

function pivotClassic(high: number, low: number, close: number) {
  const pivot = (high + low + close) / 3
  return { pivot, r1: (2 * pivot) - low, s1: (2 * pivot) - high }
}

async function fetchCandleSeries(symbol: string) {
  try {
    const response = await fetch(`/yf/v8/finance/chart/${encodeURIComponent(symbol)}.NS?interval=1d&range=6mo`)
    const data = await response.json()
    const result = data?.chart?.result?.[0]
    if (!result) return [] as CandlePoint[]
    const quote = result?.indicators?.quote?.[0]
    return (result.timestamp ?? []).map((time: number, index: number) => ({
      time: new Date(time * 1000).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
      open: +(quote?.open?.[index] ?? 0).toFixed(2),
      high: +(quote?.high?.[index] ?? 0).toFixed(2),
      low: +(quote?.low?.[index] ?? 0).toFixed(2),
      close: +(quote?.close?.[index] ?? 0).toFixed(2),
      volume: Number(quote?.volume?.[index] ?? 0),
    })).filter((row: CandlePoint) => row.close > 0)
  } catch {
    return [] as CandlePoint[]
  }
}

function buildIndicatorSnapshot(indicator: IndicatorMeta, row: MarketIndicator | null, candles: CandlePoint[]): IndicatorSnapshot {
  if (!row) return { name: indicator.name, category: indicator.category, status: 'proxy', value: '--', secondary: 'No stock selected', explanation: indicator.description, points: [] }
  const closes = candles.map(item => item.close)
  const highs = candles.map(item => item.high)
  const lows = candles.map(item => item.low)
  const volumes = candles.map(item => item.volume)
  const lastClose = closes[closes.length - 1] ?? row.price
  const bandStd = stddev(closes, 20)
  const pivot = pivotClassic(row.high, row.low, row.price)
  const live: Record<string, IndicatorSnapshot> = {
    'Moving Average (SMA)': { name: indicator.name, category: indicator.category, status: 'live', value: row.sma20.toFixed(2), secondary: `SMA50 ${row.sma50.toFixed(2)}`, explanation: 'Simple moving averages are coming from the live ET Alpha backend engine.', points: [{ label: 'Price', value: row.price }, { label: 'SMA20', value: row.sma20 }, { label: 'SMA50', value: row.sma50 }] },
    'Exponential Moving Average (EMA)': { name: indicator.name, category: indicator.category, status: 'live', value: row.ema12.toFixed(2), secondary: `EMA26 ${row.ema26.toFixed(2)}`, explanation: 'Short and medium EMA values are already live for the selected stock.', points: [{ label: 'Price', value: row.price }, { label: 'EMA12', value: row.ema12 }, { label: 'EMA26', value: row.ema26 }] },
    'Weighted Moving Average (WMA)': { name: indicator.name, category: indicator.category, status: 'live', value: wma(closes, 20).toFixed(2), secondary: '20-period weighted moving average', explanation: 'WMA is computed directly from the fetched six-month candle history.', points: closes.slice(-20).map((value, index) => ({ label: `${index + 1}`, value })) },
    'MACD (Moving Average Convergence Divergence)': { name: indicator.name, category: indicator.category, status: 'live', value: row.macd.toFixed(2), secondary: `Signal ${row.macdSignal.toFixed(2)} | Hist ${row.macdHistogram.toFixed(2)}`, explanation: 'MACD, signal, and histogram come from the real backend indicator engine.', points: [{ label: 'MACD', value: row.macd }, { label: 'Signal', value: row.macdSignal }, { label: 'Histogram', value: row.macdHistogram }] },
    'RSI (Relative Strength Index)': { name: indicator.name, category: indicator.category, status: 'live', value: row.rsi.toFixed(1), secondary: row.rsi >= 70 ? 'Overbought zone' : row.rsi <= 30 ? 'Oversold zone' : 'Balanced zone', explanation: 'RSI is live from ET Alpha and updates with the selected stock.', points: [{ label: 'RSI', value: row.rsi }, { label: 'Bull', value: row.bullishScore }, { label: 'Bear', value: row.bearishScore }] },
    'Stochastic Oscillator': { name: indicator.name, category: indicator.category, status: 'live', value: stochastic(highs, lows, closes).toFixed(1), secondary: '14-period stochastic', explanation: 'Stochastic is computed from the recent live high-low-close window.', points: closes.slice(-14).map((value, index) => ({ label: `${index + 1}`, value })) },
    'Commodity Channel Index (CCI)': { name: indicator.name, category: indicator.category, status: 'live', value: cci(highs, lows, closes).toFixed(1), secondary: '20-period CCI', explanation: 'CCI is computed from typical price and mean deviation on the live series.', points: closes.slice(-20).map((value, index) => ({ label: `${index + 1}`, value })) },
    'Williams %R': { name: indicator.name, category: indicator.category, status: 'live', value: williamsR(highs, lows, closes).toFixed(1), secondary: '14-period Williams %R', explanation: 'Williams %R is derived from the same live high-low-close window as stochastic.', points: lows.slice(-14).map((value, index) => ({ label: `${index + 1}`, value })) },
    'Rate of Change (ROC)': { name: indicator.name, category: indicator.category, status: 'live', value: roc(closes, 12).toFixed(2), secondary: '12-period ROC', explanation: 'ROC compares current price to the price twelve sessions back.', points: closes.slice(-13).map((value, index) => ({ label: `${index + 1}`, value })) },
    Volume: { name: indicator.name, category: indicator.category, status: 'live', value: `${(row.volume / 100000).toFixed(1)}L`, secondary: `${row.volumeSpike}x average`, explanation: 'Live exchange volume and volume-spike ratio are available from the backend engine.', points: volumes.slice(-20).map((value, index) => ({ label: `${index + 1}`, value })) },
    'On-Balance Volume (OBV)': { name: indicator.name, category: indicator.category, status: 'live', value: `${(obv(closes, volumes) / 1000000).toFixed(2)}M`, secondary: 'Cumulative directional volume', explanation: 'OBV is computed directly from the live close/volume series.', points: closes.slice(-20).map((value, index) => ({ label: `${index + 1}`, value })) },
    'Volume Weighted Average Price (VWAP)': { name: indicator.name, category: indicator.category, status: 'live', value: vwap(highs, lows, closes, volumes).toFixed(2), secondary: `Last close ${lastClose.toFixed(2)}`, explanation: 'VWAP is computed as a live volume-weighted benchmark for the selected stock.', points: closes.slice(-20).map((value, index) => ({ label: `${index + 1}`, value })) },
    'Chaikin Money Flow (CMF)': { name: indicator.name, category: indicator.category, status: 'live', value: cmf(highs, lows, closes, volumes).toFixed(3), secondary: '20-period money flow', explanation: 'CMF is derived from the candle and volume stream for the selected stock.', points: volumes.slice(-20).map((value, index) => ({ label: `${index + 1}`, value })) },
    'Bollinger Bands': { name: indicator.name, category: indicator.category, status: 'live', value: `${(sma(closes, 20) + bandStd * 2).toFixed(2)} / ${(sma(closes, 20) - bandStd * 2).toFixed(2)}`, secondary: `Mid ${sma(closes, 20).toFixed(2)}`, explanation: 'Upper, middle, and lower Bollinger levels are computed from the live close series.', points: closes.slice(-20).map((value, index) => ({ label: `${index + 1}`, value })) },
    'Bollinger Band Width': { name: indicator.name, category: indicator.category, status: 'live', value: (((bandStd * 4) / Math.max(sma(closes, 20), 1)) * 100).toFixed(2), secondary: 'Width % of basis', explanation: 'Band width is derived from the current Bollinger spread and basis average.', points: closes.slice(-20).map((value, index) => ({ label: `${index + 1}`, value })) },
    'Average True Range (ATR)': { name: indicator.name, category: indicator.category, status: 'live', value: row.atr.toFixed(2), secondary: `${row.atr_pct.toFixed(2)}% of price`, explanation: 'ATR is already computed by the real backend engine.', points: [{ label: 'ATR', value: row.atr }, { label: 'Support', value: row.support }, { label: 'Resistance', value: row.resistance }] },
    'Donchian Channels': { name: indicator.name, category: indicator.category, status: 'live', value: `${Math.max(...highs.slice(-20)).toFixed(2)} / ${Math.min(...lows.slice(-20)).toFixed(2)}`, secondary: '20-session channel', explanation: 'Donchian channels use the highest high and lowest low over the recent live window.', points: highs.slice(-20).map((value, index) => ({ label: `${index + 1}`, value })) },
    'Standard Deviation': { name: indicator.name, category: indicator.category, status: 'live', value: bandStd.toFixed(2), secondary: '20-period volatility spread', explanation: 'Standard deviation is computed directly from the recent close series.', points: closes.slice(-20).map((value, index) => ({ label: `${index + 1}`, value })) },
    'Pivot Points (Classic)': { name: indicator.name, category: indicator.category, status: 'live', value: pivot.pivot.toFixed(2), secondary: `S1 ${pivot.s1.toFixed(2)} | R1 ${pivot.r1.toFixed(2)}`, explanation: 'Classic pivot points are computed from the live session high, low, and close.', points: [{ label: 'Pivot', value: pivot.pivot }, { label: 'S1', value: pivot.s1 }, { label: 'R1', value: pivot.r1 }] },
    'Fibonacci Retracement': { name: indicator.name, category: indicator.category, status: 'live', value: `${(Math.max(...highs.slice(-60)) - (Math.max(...highs.slice(-60)) - Math.min(...lows.slice(-60))) * 0.382).toFixed(2)}`, secondary: '38.2% live retracement', explanation: 'Fibonacci retracement uses the recent 60-session swing high and low.', points: [{ label: 'High', value: Math.max(...highs.slice(-60)) }, { label: '38.2%', value: Math.max(...highs.slice(-60)) - (Math.max(...highs.slice(-60)) - Math.min(...lows.slice(-60))) * 0.382 }, { label: 'Low', value: Math.min(...lows.slice(-60)) }] },
  }
  return live[indicator.name] ?? { name: indicator.name, category: indicator.category, status: 'proxy', value: row.conviction.toFixed(0), secondary: `Live ${indicator.category} proxy`, explanation: `${indicator.name} is searchable and linked to the selected stock. This spotlight keeps it functional now with live ET Alpha context while the exact overlay is still being expanded.`, points: [{ label: 'Price', value: row.price }, { label: 'RSI', value: row.rsi }, { label: 'Conviction', value: row.conviction }] }
}

export default function DataPage() {
  const [rows, setRows] = useState<MarketIndicator[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [selectedTicker, setSelectedTicker] = useState('RELIANCE')
  const [tickerSearch, setTickerSearch] = useState('RELIANCE')
  const [indicatorSearch, setIndicatorSearch] = useState('RSI')
  const [selectedIndicator, setSelectedIndicator] = useState<IndicatorMeta>(INDICATOR_CATALOG.find(item => item.name.startsWith('RSI')) ?? INDICATOR_CATALOG[0])
  const [analysis, setAnalysis] = useState('Loading AI analysis...')
  const [analysisLoading, setAnalysisLoading] = useState(false)
  const [indicatorNarrative, setIndicatorNarrative] = useState('Select any indicator from the catalog to get a live AI explanation tied to the selected stock.')
  const [indicatorNarrativeLoading, setIndicatorNarrativeLoading] = useState(false)
  const [candles, setCandles] = useState<CandlePoint[]>([])
  const [candlesLoading, setCandlesLoading] = useState(false)
  const [chartExpanded, setChartExpanded] = useState(false)

  const load = async (silent = false) => {
    if (silent) setRefreshing(true)
    else setLoading(true)
    try {
      const data = await fetchMarketDashboard()
      setRows(data.indicators)
      if (!data.indicators.some(row => row.ticker === selectedTicker) && data.indicators[0]) {
        setSelectedTicker(data.indicators[0].ticker)
        setTickerSearch(data.indicators[0].ticker)
      }
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => { void load() }, [])

  useEffect(() => {
    if (!selectedTicker) return
    setAnalysisLoading(true)
    analyzeTickerWithAI(selectedTicker)
      .then(data => setAnalysis(data.analysis))
      .catch(() => setAnalysis('AI analysis is temporarily unavailable. The visual dashboard is still using live fetched market data and indicators.'))
      .finally(() => setAnalysisLoading(false))

    setCandlesLoading(true)
    fetchCandleSeries(selectedTicker)
      .then(setCandles)
      .catch(() => setCandles([]))
      .finally(() => setCandlesLoading(false))
  }, [selectedTicker])

  const selected = useMemo(() => rows.find(row => row.ticker === selectedTicker) ?? rows[0] ?? null, [rows, selectedTicker])
  const indicatorMatches = useMemo(() => INDICATOR_CATALOG.filter(item => item.name.toLowerCase().includes(indicatorSearch.toLowerCase()) || item.category.toLowerCase().includes(indicatorSearch.toLowerCase())).slice(0, 12), [indicatorSearch])
  const snapshot = useMemo(() => buildIndicatorSnapshot(selectedIndicator, selected, candles), [selectedIndicator, selected, candles])
  const sectorMix = useMemo(() => Object.entries(rows.reduce<Record<string, number>>((acc, row) => { acc[row.sector] = (acc[row.sector] ?? 0) + 1; return acc }, {})).map(([name, value]) => ({ name, value })), [rows])
  const breadthSeries = useMemo(() => rows.map(row => ({ ticker: row.ticker, changePct: row.changePct, conviction: row.conviction, rsi: row.rsi, volumeSpike: row.volumeSpike, smaGap: +(row.price - row.sma20).toFixed(2), momentum: row.momentum20d })), [rows])
  const trendCounts = useMemo(() => {
    const bullish = rows.filter(row => row.trend === 'bullish').length
    const bearish = rows.filter(row => row.trend === 'bearish').length
    const neutral = rows.filter(row => row.trend === 'neutral').length
    return [{ name: 'Bullish', value: bullish, fill: '#00e676' }, { name: 'Bearish', value: bearish, fill: '#ff3d57' }, { name: 'Neutral', value: neutral, fill: '#ffc61a' }]
  }, [rows])
  const leadership = useMemo(() => [...rows].sort((a, b) => b.conviction - a.conviction).slice(0, 8), [rows])
  const laggards = useMemo(() => [...rows].sort((a, b) => a.changePct - b.changePct).slice(0, 8), [rows])
  const radialData = useMemo(() => selected ? [{ name: 'Conviction', value: selected.conviction, fill: '#ffc61a' }, { name: 'RSI', value: selected.rsi, fill: '#38bdf8' }] : [], [selected])
  const radarData = useMemo(() => selected ? [{ metric: 'RSI', value: selected.rsi }, { metric: 'Bull', value: selected.bullishScore }, { metric: 'Bear', value: selected.bearishScore }, { metric: 'Conviction', value: selected.conviction }, { metric: 'VolSpike', value: Math.min(100, selected.volumeSpike * 25) }] : [], [selected])

  const handleTickerSearch = () => {
    const next = tickerSearch.trim().toUpperCase()
    if (!next) return
    const match = rows.find(row => row.ticker === next || row.company.toUpperCase().includes(next))
    if (match) setSelectedTicker(match.ticker)
  }

  const handleIndicatorSearch = () => {
    const match = indicatorMatches[0]
    if (match) setSelectedIndicator(match)
  }

  useEffect(() => {
    if (!selected) return
    setIndicatorNarrativeLoading(true)
    groqChat(
      'You explain stock indicators clearly for an investor dashboard. Keep it concise and practical.',
      `Stock: ${selected.ticker}
Indicator: ${snapshot.name}
Category: ${snapshot.category}
Mode: ${snapshot.status}
Current value: ${snapshot.value}
Secondary context: ${snapshot.secondary}
Explanation seed: ${snapshot.explanation}

Explain what this indicator currently suggests for this stock in 2 short sentences without giving investment-advice language.`,
    )
      .then(setIndicatorNarrative)
      .catch(() => setIndicatorNarrative(snapshot.explanation))
      .finally(() => setIndicatorNarrativeLoading(false))
  }, [selected?.ticker, snapshot.name, snapshot.value, snapshot.secondary, snapshot.status])

  if (loading) return <div className="flex min-h-[520px] items-center justify-center rounded-3xl border border-surface-500/50 bg-surface-700/70"><Loader2 size={22} className="animate-spin text-brand-300" /></div>

  return (
    <div className="space-y-5 pb-5">
      <div className="rounded-[28px] border border-brand-400/30 bg-[radial-gradient(circle_at_top_left,rgba(255,198,26,0.18),transparent_28%),linear-gradient(135deg,#10192a_0%,#0b111d_74%)] p-5 shadow-card">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
          <div className="max-w-3xl">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-brand-400/30 bg-brand-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-300"><Database size={12} />Data Intelligence Layer</div>
            <h2 className="font-display text-3xl font-black text-white">Live data lab with searchable indicator explorer</h2>
            <p className="mt-2 text-sm leading-6 text-gray-300">Separate from Markets, this page now combines multi-chart analytics with a searchable master indicator catalog. Type any indicator from your list, click it, and the spotlight panel switches to that indicator for the selected stock.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <input value={tickerSearch} onChange={event => setTickerSearch(event.target.value)} onKeyDown={event => event.key === 'Enter' && handleTickerSearch()} className="rounded-xl border border-surface-500 bg-surface-800 px-4 py-3 text-sm text-white outline-none focus:border-brand-500/50" />
            <button onClick={handleTickerSearch} className="rounded-xl bg-brand-500 px-4 py-3 text-surface-900 transition hover:bg-brand-400"><Search size={16} /></button>
            <button onClick={() => void load(true)} className="inline-flex items-center gap-2 rounded-xl border border-surface-500 bg-surface-800 px-4 py-3 text-sm text-gray-300 transition hover:text-white"><RefreshCw size={15} className={refreshing ? 'animate-spin' : ''} />Refresh</button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 xl:grid-cols-5">
        <StatCard label="Tracked" value={`${rows.length}`} />
        <StatCard label="Advancers" value={`${rows.filter(row => row.changePct > 0).length}`} tone="text-neon-green" />
        <StatCard label="Decliners" value={`${rows.filter(row => row.changePct < 0).length}`} tone="text-neon-red" />
        <StatCard label="Best Setup" value={leadership[0]?.ticker ?? '--'} tone="text-brand-300" />
        <StatCard label="Indicator" value={selectedIndicator.name.split('(')[0].trim()} />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1fr_1fr]">
        <div className="rounded-2xl border border-surface-500/50 bg-surface-700/80 p-4">
          <p className="text-[10px] uppercase tracking-[0.18em] text-gray-500">Indicator Search</p>
          <h3 className="mt-1 text-lg font-bold text-white">Master indicator catalog</h3>
          <div className="mt-4 flex gap-2">
            <input value={indicatorSearch} onChange={event => setIndicatorSearch(event.target.value)} onKeyDown={event => event.key === 'Enter' && handleIndicatorSearch()} placeholder="Search RSI, MACD, VWAP, Bollinger, Ichimoku..." className="flex-1 rounded-xl border border-surface-500 bg-surface-800 px-4 py-3 text-sm text-white outline-none focus:border-brand-500/50" />
            <button onClick={handleIndicatorSearch} className="rounded-xl bg-brand-500 px-4 py-3 text-surface-900 transition hover:bg-brand-400"><Search size={16} /></button>
          </div>
          <div className="mt-4 grid gap-2 md:grid-cols-2">
            {indicatorMatches.map(item => (
              <button key={item.name} onClick={() => setSelectedIndicator(item)} className={cn('rounded-xl border px-3 py-3 text-left transition', selectedIndicator.name === item.name ? 'border-brand-400/30 bg-brand-500/10' : 'border-surface-500/50 bg-surface-800 hover:border-surface-400/70')}>
                <p className="text-sm font-semibold text-white">{item.name}</p>
                <p className="mt-1 text-[11px] text-gray-500">{item.category}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-surface-500/50 bg-surface-700/80 p-4">
          <div className="flex items-center gap-2"><BrainCircuit size={16} className="text-brand-300" /><h3 className="text-lg font-bold text-white">Indicator Spotlight</h3></div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <StatCard label="Selected Indicator" value={snapshot.name.split('(')[0].trim()} tone="text-brand-300" />
            <StatCard label="Mode" value={snapshot.status.toUpperCase()} tone={snapshot.status === 'live' ? 'text-neon-green' : 'text-blue-300'} />
            <StatCard label="Current Value" value={snapshot.value} />
            <StatCard label="Secondary" value={snapshot.secondary} tone="text-blue-300" />
          </div>
          <p className="mt-4 text-sm leading-6 text-gray-300">{snapshot.explanation}</p>
          <div className="mt-4 rounded-xl border border-brand-400/20 bg-brand-500/8 p-3 text-sm leading-6 text-gray-300">
            {indicatorNarrativeLoading ? 'Refreshing indicator AI explanation...' : indicatorNarrative}
          </div>
          <div className="mt-4 h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={snapshot.points}>
                <CartesianGrid strokeDasharray="3 3" stroke="#22314d" />
                <XAxis dataKey="label" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#ffc61a" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-2xl border border-surface-500/50 bg-surface-700/80 p-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2"><CandlestickChart size={16} className="text-brand-300" /><h3 className="text-lg font-bold text-white">Candlestick Intelligence</h3></div>
            <button onClick={() => setChartExpanded(true)} className="inline-flex items-center gap-2 rounded-xl border border-brand-400/20 bg-brand-500/10 px-3 py-2 text-xs font-semibold text-brand-300 transition hover:bg-brand-500/20">
              <Maximize2 size={13} />
              Enlarge
            </button>
          </div>
          <div className="mt-4"><StockChart initialTicker={selectedTicker} headerLabel={`${selectedTicker} Candlestick + Move Blueprint`} selectedIndicatorName={selectedIndicator.name} /></div>
        </div>
        <div className="rounded-2xl border border-surface-500/50 bg-surface-700/80 p-4">
          <div className="flex items-center gap-2"><BrainCircuit size={16} className="text-brand-300" /><h3 className="text-lg font-bold text-white">AI Summary</h3></div>
          <p className="mt-3 text-sm leading-6 text-gray-300">{analysisLoading ? 'Refreshing AI analysis...' : analysis}</p>
          {selected && (
            <div className="mt-4 grid grid-cols-2 gap-3">
              <StatCard label="RSI" value={`${selected.rsi}`} tone={selected.rsi >= 65 ? 'text-neon-green' : selected.rsi <= 35 ? 'text-neon-red' : 'text-white'} />
              <StatCard label="Conviction" value={`${selected.conviction}/100`} tone="text-brand-300" />
              <StatCard label="Support" value={`Rs ${selected.support.toFixed(0)}`} tone="text-blue-300" />
              <StatCard label="Resistance" value={`Rs ${selected.resistance.toFixed(0)}`} tone="text-orange-300" />
            </div>
          )}
          <p className="mt-4 text-xs text-gray-500">{candlesLoading ? 'Refreshing live candle series for indicator computations...' : `${candles.length} daily candles loaded for ${selectedTicker}.`}</p>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <ChartCard title="Visual 1" subtitle="Performance leaderboard"><ResponsiveContainer width="100%" height="100%"><BarChart data={leadership}><CartesianGrid strokeDasharray="3 3" stroke="#22314d" /><XAxis dataKey="ticker" stroke="#94a3b8" /><YAxis stroke="#94a3b8" /><Tooltip /><Bar dataKey="changePct">{leadership.map(item => <Cell key={item.ticker} fill={item.changePct >= 0 ? '#00e676' : '#ff3d57'} />)}</Bar></BarChart></ResponsiveContainer></ChartCard>
        <ChartCard title="Visual 2" subtitle="RSI and conviction map"><ResponsiveContainer width="100%" height="100%"><ScatterChart><CartesianGrid strokeDasharray="3 3" stroke="#22314d" /><XAxis dataKey="rsi" stroke="#94a3b8" /><YAxis dataKey="conviction" stroke="#94a3b8" /><Tooltip /><Scatter data={breadthSeries} fill="#ffc61a" /></ScatterChart></ResponsiveContainer></ChartCard>
        <ChartCard title="Visual 3" subtitle="Trend distribution"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={trendCounts} dataKey="value" nameKey="name" outerRadius={95} label>{trendCounts.map(item => <Cell key={item.name} fill={item.fill} />)}</Pie><Tooltip /><Legend /></PieChart></ResponsiveContainer></ChartCard>
        <ChartCard title="Visual 4" subtitle="Selected ticker radar"><ResponsiveContainer width="100%" height="100%"><RadarChart data={radarData}><PolarGrid stroke="#22314d" /><PolarAngleAxis dataKey="metric" tick={{ fill: '#cbd5e1', fontSize: 11 }} /><Radar name="Score" dataKey="value" stroke="#ffc61a" fill="#ffc61a" fillOpacity={0.35} /><Tooltip /></RadarChart></ResponsiveContainer></ChartCard>
        <ChartCard title="Visual 5" subtitle="Momentum curve"><ResponsiveContainer width="100%" height="100%"><LineChart data={breadthSeries}><CartesianGrid strokeDasharray="3 3" stroke="#22314d" /><XAxis dataKey="ticker" stroke="#94a3b8" /><YAxis stroke="#94a3b8" /><Tooltip /><Line type="monotone" dataKey="momentum" stroke="#38bdf8" strokeWidth={2} dot={false} /></LineChart></ResponsiveContainer></ChartCard>
        <ChartCard title="Visual 6" subtitle="Volume spike profile"><ResponsiveContainer width="100%" height="100%"><AreaChart data={leadership}><CartesianGrid strokeDasharray="3 3" stroke="#22314d" /><XAxis dataKey="ticker" stroke="#94a3b8" /><YAxis stroke="#94a3b8" /><Tooltip /><Area type="monotone" dataKey="volumeSpike" stroke="#a78bfa" fill="#a78bfa" fillOpacity={0.25} /></AreaChart></ResponsiveContainer></ChartCard>
        <ChartCard title="Visual 7" subtitle="Price vs moving average gap"><ResponsiveContainer width="100%" height="100%"><ComposedChart data={breadthSeries}><CartesianGrid strokeDasharray="3 3" stroke="#22314d" /><XAxis dataKey="ticker" stroke="#94a3b8" /><YAxis stroke="#94a3b8" /><Tooltip /><Bar dataKey="smaGap" fill="#f59e0b" /><Line type="monotone" dataKey="changePct" stroke="#00e676" strokeWidth={2} /></ComposedChart></ResponsiveContainer></ChartCard>
        <ChartCard title="Visual 8" subtitle="Sector mix"><ResponsiveContainer width="100%" height="100%"><BarChart data={sectorMix} layout="vertical"><CartesianGrid strokeDasharray="3 3" stroke="#22314d" /><XAxis type="number" stroke="#94a3b8" /><YAxis dataKey="name" type="category" stroke="#94a3b8" width={80} /><Tooltip /><Bar dataKey="value" fill="#34d399" /></BarChart></ResponsiveContainer></ChartCard>
        <ChartCard title="Visual 9" subtitle="Selected strength ring"><ResponsiveContainer width="100%" height="100%"><RadialBarChart innerRadius="35%" outerRadius="95%" barSize={18} data={radialData}><RadialBar dataKey="value" cornerRadius={8} label={{ fill: '#fff', position: 'insideStart' }} /><Legend /><Tooltip /></RadialBarChart></ResponsiveContainer></ChartCard>
        <ChartCard title="Visual 10" subtitle="Weakest names risk board"><ResponsiveContainer width="100%" height="100%"><BarChart data={laggards}><CartesianGrid strokeDasharray="3 3" stroke="#22314d" /><XAxis dataKey="ticker" stroke="#94a3b8" /><YAxis stroke="#94a3b8" /><Tooltip /><Bar dataKey="changePct">{laggards.map(item => <Cell key={item.ticker} fill="#ff3d57" />)}</Bar></BarChart></ResponsiveContainer></ChartCard>
      </div>

      {chartExpanded && (
        <div className="fixed inset-0 z-[90] bg-surface-900/92 backdrop-blur-sm">
          <div className="flex h-full flex-col p-4">
            <div className="mb-4 flex items-center justify-between rounded-2xl border border-surface-500/50 bg-surface-800/90 px-4 py-3">
              <div>
                <p className="text-[10px] uppercase tracking-[0.18em] text-gray-500">Expanded Chart Lab</p>
                <h3 className="text-lg font-bold text-white">{selectedTicker} with {selectedIndicator.name}</h3>
              </div>
              <button onClick={() => setChartExpanded(false)} className="inline-flex items-center gap-2 rounded-xl border border-surface-500 bg-surface-700 px-3 py-2 text-sm text-gray-300 transition hover:text-white">
                <X size={14} />
                Close
              </button>
            </div>

            <div className="grid min-h-0 flex-1 gap-4 xl:grid-cols-[0.28fr_1fr]">
              <div className="overflow-y-auto rounded-2xl border border-surface-500/50 bg-surface-800/90 p-3">
                <p className="text-[10px] uppercase tracking-[0.18em] text-gray-500">Indicators</p>
                <div className="mt-3 space-y-2">
                  {INDICATOR_CATALOG.map(item => (
                    <button key={`expanded-${item.name}`} onClick={() => setSelectedIndicator(item)} className={cn('w-full rounded-xl border px-3 py-3 text-left transition', selectedIndicator.name === item.name ? 'border-brand-400/30 bg-brand-500/10' : 'border-surface-500/50 bg-surface-700 hover:border-surface-400/70')}>
                      <p className="text-sm font-semibold text-white">{item.name}</p>
                      <p className="mt-1 text-[11px] text-gray-500">{item.category}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="min-h-0 overflow-y-auto rounded-2xl border border-surface-500/50 bg-surface-800/90 p-4">
                <div className="mb-4 rounded-xl border border-brand-400/20 bg-brand-500/8 p-3 text-sm leading-6 text-gray-300">
                  <p className="font-semibold text-brand-300">{snapshot.name}</p>
                  <p className="mt-2">{indicatorNarrativeLoading ? 'Refreshing indicator AI explanation...' : indicatorNarrative}</p>
                </div>
                <StockChart initialTicker={selectedTicker} headerLabel={`${selectedTicker} Fullscreen Candlestick Intelligence`} selectedIndicatorName={selectedIndicator.name} />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
