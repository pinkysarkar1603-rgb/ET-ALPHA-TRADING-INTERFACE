import { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Activity,
  BarChart3,
  BrainCircuit,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Gauge,
  Globe2,
  Info,
  Loader2,
  Orbit,
  Newspaper,
  ShieldAlert,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  TrendingDown,
  TrendingUp,
} from 'lucide-react'
import OptionsChain from '@/components/charts/OptionsChain'
import StockChart from '@/components/charts/StockChart'
import { IPOTracker, SentimentScanner } from '@/components/shared/MegaFeatures'
import {
  analyzeTickerWithAI,
  cn,
  fetchMarketDashboard,
  groqSearchChat,
  type MarketIndicator,
  type SignalAnalysisResponse,
} from '@/lib/api'

type MarketsTab = 'markets' | 'info' | 'intel'

interface HeadlineItem {
  title: string
  publisher: string
  link: string
}

interface IntelEvent {
  title: string
  bucket: 'domestic' | 'global' | 'sector' | 'company'
  impact: 'bullish' | 'bearish' | 'neutral'
  why: string
  affected: string[]
  confidence: number
}

const analysisCache = new Map<string, SignalAnalysisResponse>()

function buildFallbackIntelEvents(symbol: string, headlines: HeadlineItem[]): IntelEvent[] {
  const ticker = symbol === 'NIFTY50' ? 'NIFTY50' : symbol
  if (headlines.length === 0) {
    return [
      {
        title: 'Technical context only',
        bucket: 'company',
        impact: 'neutral',
        why: 'No linked headline was returned, so ET Alpha is waiting for stronger external confirmation before assigning a narrative driver.',
        affected: [ticker],
        confidence: 34,
      },
    ]
  }

  return headlines.slice(0, 4).map((headline, index) => {
    const lower = headline.title.toLowerCase()
    const bucket =
      lower.includes('rbi') || lower.includes('india') || lower.includes('budget') || lower.includes('government') ? 'domestic' :
      lower.includes('fed') || lower.includes('us ') || lower.includes('oil') || lower.includes('war') || lower.includes('global') ? 'global' :
      lower.includes('sector') || lower.includes('demand') || lower.includes('industry') ? 'sector' :
      'company'

    const impact =
      lower.includes('surge') || lower.includes('beat') || lower.includes('growth') || lower.includes('record') || lower.includes('positive') ? 'bullish' :
      lower.includes('fall') || lower.includes('drop') || lower.includes('cuts') || lower.includes('warns') || lower.includes('miss') ? 'bearish' :
      'neutral'

    return {
      title: headline.title,
      bucket,
      impact,
      why: `${headline.publisher} headline linked to ${ticker}. Use it as a live reference point and verify the market reaction against price structure.`,
      affected: [ticker, bucket === 'sector' ? 'Sector peers' : 'NIFTY50'],
      confidence: Math.max(42, 70 - index * 6),
    } satisfies IntelEvent
  })
}

async function fetchTickerNews(symbol: string): Promise<HeadlineItem[]> {
  const query = symbol.replace('.NS', '').replace('^', '')
  try {
    const res = await fetch(`/yf/v1/finance/search?q=${encodeURIComponent(query)}&quotesCount=1&newsCount=8`)
    const data = await res.json()
    return (data?.news ?? []).slice(0, 6).map((item: any) => ({
      title: item.title as string,
      publisher: item.publisher as string,
      link: item.link as string,
    }))
  } catch {
    return []
  }
}

function parseJsonArray<T>(text: string): T[] {
  const match = text.match(/\[[\s\S]*\]/)
  if (!match) return []
  try {
    return JSON.parse(match[0]) as T[]
  } catch {
    return []
  }
}

function sentimentColor(value: 'bullish' | 'bearish' | 'neutral') {
  if (value === 'bullish') return 'text-neon-green border-neon-green/20 bg-neon-green/10'
  if (value === 'bearish') return 'text-neon-red border-neon-red/20 bg-neon-red/10'
  return 'text-gray-300 border-surface-500 bg-surface-600/50'
}

function metricTone(value: number, bullishHigher = true) {
  const positive = bullishHigher ? value >= 0 : value <= 0
  return positive ? 'text-neon-green' : 'text-neon-red'
}

function MiniStat({ label, value, tone = 'text-white' }: { label: string; value: string | number; tone?: string }) {
  return (
    <div className="rounded-xl border border-surface-500/50 bg-surface-700/80 p-3 shadow-card">
      <p className="mb-1 text-[10px] uppercase tracking-[0.18em] text-gray-500">{label}</p>
      <p className={cn('font-mono text-xl font-black', tone)}>{value}</p>
    </div>
  )
}

function IndicatorGauge({ label, value, hint }: { label: string; value: number; hint: string }) {
  const width = `${Math.max(6, Math.min(100, value))}%`
  const color = value >= 70 ? 'bg-neon-green' : value <= 35 ? 'bg-neon-red' : 'bg-brand-400'

  return (
    <div className="rounded-xl border border-surface-500/50 bg-surface-700/60 p-3">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs font-semibold text-gray-200">{label}</span>
        <span className="font-mono text-xs text-white">{value}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-surface-600">
        <div className={cn('h-full rounded-full', color)} style={{ width }} />
      </div>
      <p className="mt-2 text-[11px] text-gray-500">{hint}</p>
    </div>
  )
}

function DetailMetric({ label, value, tone = 'text-white' }: { label: string; value: string; tone?: string }) {
  return (
    <div className="rounded-xl border border-surface-500/50 bg-surface-700/60 p-3">
      <p className="text-[10px] uppercase tracking-[0.18em] text-gray-500">{label}</p>
      <p className={cn('mt-1 font-mono text-sm font-bold', tone)}>{value}</p>
    </div>
  )
}

function MarketRow({
  item,
  selected,
  onClick,
}: {
  item: MarketIndicator
  selected: boolean
  onClick: () => void
}) {
  const up = item.changePct >= 0

  return (
    <button
      onClick={onClick}
      className={cn(
        'grid w-full grid-cols-[1.4fr_0.9fr_0.9fr_1fr_0.8fr] items-center gap-3 rounded-2xl border px-4 py-3 text-left transition-all',
        selected
          ? 'border-brand-400/50 bg-brand-500/10 shadow-glow-amber'
          : 'border-surface-500/40 bg-surface-700/60 hover:border-surface-400/70 hover:bg-surface-700',
      )}
    >
      <div>
        <div className="flex items-center gap-2">
          <span className="text-sm font-black text-white">{item.ticker}</span>
          <span className="rounded-full border border-surface-500 bg-surface-600 px-2 py-0.5 text-[10px] text-gray-400">
            {item.sector}
          </span>
        </div>
        <p className="mt-1 text-[11px] text-gray-500">{item.company}</p>
        <p className="mt-2 text-[11px] text-brand-300">{item.setup}</p>
      </div>

      <div>
        <p className="font-mono text-sm font-bold text-white">Rs {item.price.toFixed(2)}</p>
        <p className={cn('mt-1 flex items-center gap-1 text-xs font-bold', up ? 'text-neon-green' : 'text-neon-red')}>
          {up ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          {up ? '+' : ''}{item.changePct}%
        </p>
      </div>

      <div>
        <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">RSI</p>
        <p className={cn('mt-1 font-mono text-sm font-bold', item.rsi >= 65 ? 'text-neon-green' : item.rsi <= 35 ? 'text-neon-red' : 'text-white')}>
          {item.rsi}
        </p>
      </div>

      <div>
        <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">Volume Spike</p>
        <p className={cn('mt-1 font-mono text-sm font-bold', item.volumeSpike >= 1.5 ? 'text-brand-300' : 'text-gray-300')}>
          {item.volumeSpike}x
        </p>
      </div>

      <div>
        <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">Conviction</p>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-surface-600">
          <div
            className={cn('h-full rounded-full', item.trend === 'bullish' ? 'bg-neon-green' : item.trend === 'bearish' ? 'bg-neon-red' : 'bg-brand-400')}
            style={{ width: `${item.conviction}%` }}
          />
        </div>
        <p className="mt-1 font-mono text-xs text-gray-300">{item.conviction}/100</p>
      </div>
    </button>
  )
}

function explainSetup(item: MarketIndicator) {
  if (item.setup === 'Momentum breakout') return 'Price, momentum, and volume are aligned. This is the cleanest continuation profile on the board.'
  if (item.setup === 'Oversold rebound') return 'The stock is trying to reverse from exhaustion. This is useful when you want to compare reversal quality instead of only chasing strong trends.'
  if (item.setup === 'Breakdown pressure') return 'Weak structure with negative trend stack. Good place for ET Alpha to show guarded SELL or WATCH behaviour.'
  if (item.setup === 'Support retest') return 'Price is sitting near a known demand zone. This is where risk control and confidence thresholds matter most.'
  return 'Signals are mixed, which is exactly where our guardrails matter. ET Alpha should watch, not hallucinate.'
}

function MarketsWarRoom() {
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [dashboard, setDashboard] = useState<{ overview: any; indicators: MarketIndicator[] } | null>(null)
  const [selectedTicker, setSelectedTicker] = useState<string>('')
  const [search, setSearch] = useState('')
  const [sector, setSector] = useState('All')
  const [analysis, setAnalysis] = useState<SignalAnalysisResponse | null>(null)
  const [analysisLoading, setAnalysisLoading] = useState(false)

  const loadDashboard = async (silent = false) => {
    if (silent) setRefreshing(true)
    else setLoading(true)
    try {
      const data = await fetchMarketDashboard()
      setDashboard(data)
      if (!selectedTicker && data.indicators[0]) setSelectedTicker(data.indicators[0].ticker)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => {
    loadDashboard()
  }, [])

  const sectors = useMemo(() => {
    const all = dashboard?.indicators.map(item => item.sector) ?? []
    return ['All', ...Array.from(new Set(all))]
  }, [dashboard])

  const filtered = useMemo(() => {
    const rows = dashboard?.indicators ?? []
    return rows.filter(item => {
      const matchesSector = sector === 'All' || item.sector === sector
      const query = search.trim().toLowerCase()
      const matchesSearch = !query || item.ticker.toLowerCase().includes(query) || item.company.toLowerCase().includes(query)
      return matchesSector && matchesSearch
    })
  }, [dashboard, search, sector])

  const selected = useMemo(
    () => filtered.find(item => item.ticker === selectedTicker) ?? dashboard?.indicators.find(item => item.ticker === selectedTicker) ?? null,
    [dashboard, filtered, selectedTicker],
  )

  useEffect(() => {
    if (!selected) {
      setAnalysis(null)
      return
    }
    let cancelled = false
    const cached = analysisCache.get(selected.ticker)
    if (cached) {
      setAnalysis(cached)
      setAnalysisLoading(false)
      return
    }
    setAnalysisLoading(true)
    const timer = setTimeout(() => {
      analyzeTickerWithAI(selected.ticker)
        .then(data => {
          analysisCache.set(selected.ticker, data)
          if (!cancelled) setAnalysis(data)
        })
        .catch(() => {
          if (!cancelled) setAnalysis(null)
        })
        .finally(() => {
          if (!cancelled) setAnalysisLoading(false)
        })
    }, 120)
    return () => {
      cancelled = true
      clearTimeout(timer)
    }
  }, [selected?.ticker])

  const topSetups = dashboard?.indicators.slice(0, 3) ?? []

  if (loading && !dashboard) {
    return (
      <div className="flex min-h-[420px] items-center justify-center rounded-3xl border border-surface-500/40 bg-surface-800/70">
        <div className="flex items-center gap-3 text-sm text-gray-400">
          <Loader2 size={18} className="animate-spin" />
          Loading ET Alpha live indicator matrix...
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-5 pb-3">
      <div className="relative overflow-hidden rounded-[28px] border border-brand-400/30 bg-[radial-gradient(circle_at_top_right,rgba(255,198,26,0.16),transparent_28%),linear-gradient(135deg,#10192a_0%,#0a0d14_72%)] p-5 shadow-card">
        <div className="absolute inset-0 bg-grid-surface opacity-25" />
        <div className="absolute inset-0 bg-scanline opacity-40" />
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-brand-400/30 bg-brand-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-300">
              <Sparkles size={12} />
              Track 5 Style Domain Agent Surface
            </div>
            <h2 className="font-display text-3xl font-black text-white">ET Alpha Market War Room</h2>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-gray-300">
              Live data only. No fake indicators. Every idea on this screen is built from fetched market structure,
              then passed through analyst, guardrail, and audit-style reasoning.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {['Signal Scan Agent', 'Indicator Engine', 'Compliance Guardrail Agent', 'AI Thesis Agent', 'Audit Trail Ready'].map(label => (
                <span key={label} className="rounded-full border border-surface-500 bg-surface-700/70 px-3 py-1 text-xs text-gray-300">
                  {label}
                </span>
              ))}
            </div>
          </div>

          <button
            onClick={() => loadDashboard(true)}
            disabled={refreshing}
            className="inline-flex items-center gap-2 rounded-2xl border border-brand-400/40 bg-brand-500/10 px-4 py-3 text-sm font-semibold text-brand-200 transition hover:bg-brand-500/20 disabled:opacity-60"
          >
            <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
            {refreshing ? 'Refreshing Live Feed' : 'Refresh Live Feed'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-5">
        <MiniStat label="Tracked Symbols" value={dashboard?.overview.tracked ?? 0} />
        <MiniStat label="Advancers" value={dashboard?.overview.advancers ?? 0} tone="text-neon-green" />
        <MiniStat label="Decliners" value={dashboard?.overview.decliners ?? 0} tone="text-neon-red" />
        <MiniStat label="Average RSI" value={dashboard?.overview.avgRsi ?? 0} tone="text-brand-300" />
        <MiniStat label="Top Setup" value={dashboard?.overview.topSetup ?? 'None'} tone="text-blue-300" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.35fr_0.95fr]">
        <div className="space-y-4">
          <div className="rounded-3xl border border-surface-500/40 bg-surface-800/80 p-4">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-[11px] uppercase tracking-[0.22em] text-gray-500">Best Live Setups</p>
                <h3 className="mt-1 text-lg font-bold text-white">Conviction-ranked opportunities</h3>
              </div>
              <Gauge size={18} className="text-brand-300" />
            </div>

            <div className="grid gap-3 md:grid-cols-3">
              {topSetups.map(item => (
                <motion.div
                  key={item.ticker}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-2xl border border-surface-500/50 bg-surface-700/80 p-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-black text-white">{item.ticker}</span>
                    <span className={cn('rounded-full border px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.15em]', sentimentColor(item.trend))}>
                      {item.trend}
                    </span>
                  </div>
                  <p className="mt-2 text-xs text-brand-300">{item.setup}</p>
                  <p className="mt-3 font-mono text-xl font-black text-white">Rs {item.price.toFixed(2)}</p>
                  <div className="mt-2 flex items-center gap-2 text-xs">
                    <span className={cn('font-bold', item.changePct >= 0 ? 'text-neon-green' : 'text-neon-red')}>
                      {item.changePct >= 0 ? '+' : ''}{item.changePct}%
                    </span>
                    <span className="text-gray-500">RSI {item.rsi}</span>
                    <span className="text-gray-500">Vol {item.volumeSpike}x</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="rounded-3xl border border-surface-500/40 bg-surface-800/80 p-4">
            <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="text-[11px] uppercase tracking-[0.22em] text-gray-500">Indicator Matrix</p>
                <h3 className="mt-1 text-lg font-bold text-white">Real-time market diagnostics</h3>
              </div>

              <div className="flex flex-wrap gap-2">
                <div className="relative min-w-[220px] flex-1">
                  <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    value={search}
                    onChange={event => setSearch(event.target.value)}
                    placeholder="Search ticker or company..."
                    className="w-full rounded-2xl border border-surface-500 bg-surface-700 px-9 py-2.5 text-sm text-white outline-none transition focus:border-brand-400/60"
                  />
                </div>

                <div className="flex flex-wrap gap-2">
                  {sectors.map(name => (
                    <button
                      key={name}
                      onClick={() => setSector(name)}
                      className={cn(
                        'rounded-2xl border px-3 py-2 text-xs font-semibold transition',
                        sector === name
                          ? 'border-brand-400/50 bg-brand-500/10 text-brand-300'
                          : 'border-surface-500 bg-surface-700 text-gray-400 hover:text-white',
                      )}
                    >
                      {name}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mb-3 grid grid-cols-[1.4fr_0.9fr_0.9fr_1fr_0.8fr] gap-3 px-1 text-[10px] uppercase tracking-[0.18em] text-gray-500">
              <span>Symbol</span>
              <span>Price</span>
              <span>RSI</span>
              <span>Volume</span>
              <span>Conviction</span>
            </div>

            <div className="space-y-2">
              {filtered.map(item => (
                <MarketRow
                  key={item.ticker}
                  item={item}
                  selected={selectedTicker === item.ticker}
                  onClick={() => setSelectedTicker(item.ticker)}
                />
              ))}
              {filtered.length === 0 && (
                <div className="rounded-2xl border border-dashed border-surface-500 p-6 text-center text-sm text-gray-500">
                  No symbols match this filter.
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {selected ? (
            <>
              <div className="rounded-3xl border border-surface-500/40 bg-surface-800/80 p-5 shadow-panel">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-2xl font-black text-white">{selected.ticker}</h3>
                      <span className={cn('rounded-full border px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.15em]', sentimentColor(selected.trend))}>
                        {selected.trend}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-gray-400">{selected.company} · {selected.sector}</p>
                    <p className="mt-3 text-xs text-brand-300">{selected.setup}</p>
                  </div>

                  <div className="text-right">
                    <p className="font-mono text-3xl font-black text-white">Rs {selected.price.toFixed(2)}</p>
                    <p className={cn('mt-2 inline-flex items-center gap-1 rounded-full px-2 py-1 text-sm font-bold', selected.changePct >= 0 ? 'bg-neon-green/10 text-neon-green' : 'bg-neon-red/10 text-neon-red')}>
                      {selected.changePct >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                      {selected.changePct >= 0 ? '+' : ''}{selected.changePct}%
                    </p>
                  </div>
                </div>

                <div className="mt-5 grid grid-cols-2 gap-3">
                  <DetailMetric label="Open" value={`Rs ${selected.open.toFixed(2)}`} />
                  <DetailMetric label="Prev Close" value={`Rs ${selected.previousClose.toFixed(2)}`} />
                  <DetailMetric label="Day High" value={`Rs ${selected.high.toFixed(2)}`} tone="text-neon-green" />
                  <DetailMetric label="Day Low" value={`Rs ${selected.low.toFixed(2)}`} tone="text-neon-red" />
                  <DetailMetric label="Support" value={`Rs ${selected.support.toFixed(2)}`} tone="text-blue-300" />
                  <DetailMetric label="Resistance" value={`Rs ${selected.resistance.toFixed(2)}`} tone="text-orange-300" />
                </div>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <IndicatorGauge label="Bullish Score" value={selected.bullishScore} hint="Trend + momentum + volume alignment." />
                <IndicatorGauge label="Bearish Score" value={selected.bearishScore} hint="Breakdown pressure and weak structure." />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <DetailMetric label="RSI" value={`${selected.rsi}`} tone={selected.rsi >= 65 ? 'text-neon-green' : selected.rsi <= 35 ? 'text-neon-red' : 'text-white'} />
                <DetailMetric label="Volume Spike" value={`${selected.volumeSpike}x`} tone={selected.volumeSpike >= 1.5 ? 'text-brand-300' : 'text-white'} />
                <DetailMetric label="MACD" value={`${selected.macd}`} tone={selected.macdHistogram >= 0 ? 'text-neon-green' : 'text-neon-red'} />
                <DetailMetric label="MACD Signal" value={`${selected.macdSignal}`} />
                <DetailMetric label="SMA20" value={`Rs ${selected.sma20}`} tone={metricTone(selected.price - selected.sma20)} />
                <DetailMetric label="SMA50" value={`Rs ${selected.sma50}`} tone={metricTone(selected.price - selected.sma50)} />
                <DetailMetric label="ATR" value={`${selected.atr}`} tone={selected.atr_pct >= 4 ? 'text-neon-red' : 'text-brand-300'} />
                <DetailMetric label="ATR %" value={`${selected.atr_pct}%`} tone={selected.atr_pct >= 4 ? 'text-neon-red' : 'text-white'} />
                <DetailMetric label="5D Momentum" value={`${selected.momentum5d}%`} tone={selected.momentum5d >= 0 ? 'text-neon-green' : 'text-neon-red'} />
                <DetailMetric label="20D Momentum" value={`${selected.momentum20d}%`} tone={selected.momentum20d >= 0 ? 'text-neon-green' : 'text-neon-red'} />
                <DetailMetric label="Distance To 52W High" value={`${selected.distanceTo52wHighPct}%`} tone={selected.distanceTo52wHighPct <= 5 ? 'text-neon-green' : 'text-white'} />
                <DetailMetric label="Distance To 52W Low" value={`${selected.distanceTo52wLowPct}%`} tone={selected.distanceTo52wLowPct <= 5 ? 'text-neon-red' : 'text-white'} />
              </div>

              <div className="rounded-3xl border border-surface-500/40 bg-surface-800/80 p-5">
                <div className="mb-3 flex items-center gap-2">
                  <Activity size={16} className="text-brand-300" />
                  <h4 className="text-sm font-bold text-white">Agentic Interpretation</h4>
                </div>
                <p className="text-sm leading-6 text-gray-300">{explainSetup(selected)}</p>
              </div>

              <div className="rounded-3xl border border-surface-500/40 bg-surface-800/80 p-5">
                <div className="mb-3 flex items-center gap-2">
                  <ShieldCheck size={16} className="text-blue-300" />
                  <h4 className="text-sm font-bold text-white">Risk Flags & Guardrails</h4>
                </div>
                <div className="flex flex-wrap gap-2">
                  {selected.riskFlags.length > 0 ? selected.riskFlags.map(flag => (
                    <span key={flag} className="rounded-full border border-neon-red/20 bg-neon-red/10 px-3 py-1 text-xs text-neon-red">
                      {flag}
                    </span>
                  )) : (
                    <span className="rounded-full border border-neon-green/20 bg-neon-green/10 px-3 py-1 text-xs text-neon-green">
                      No major structural risk flag
                    </span>
                  )}
                </div>
              </div>

              <div className="rounded-3xl border border-brand-400/25 bg-[linear-gradient(180deg,rgba(255,198,26,0.08),rgba(20,29,46,0.92))] p-5 shadow-card">
                <div className="mb-3 flex items-center gap-2">
                  <BrainCircuit size={16} className="text-brand-300" />
                  <h4 className="text-sm font-bold text-white">Groq Analyst Verdict</h4>
                  {analysisLoading && <Loader2 size={14} className="animate-spin text-brand-300" />}
                </div>

                {analysis ? (
                  <div className="space-y-4">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-full border border-brand-400/30 bg-brand-500/10 px-3 py-1 text-xs font-semibold text-brand-200">
                        Verdict: {analysis.verdict}
                      </span>
                      <span className="rounded-full border border-surface-500 bg-surface-700 px-3 py-1 text-xs font-semibold text-gray-300">
                        Confidence: {analysis.confidence}/100
                      </span>
                    </div>

                    <p className="text-sm leading-6 text-gray-200">{analysis.analysis}</p>

                    {(analysis.bullCase || analysis.bearCase || analysis.nextTrigger) && (
                      <div className="grid gap-3">
                        {analysis.bullCase && (
                          <div className="rounded-2xl border border-neon-green/20 bg-neon-green/10 p-3 text-sm text-neon-green">
                            Bull case: {analysis.bullCase}
                          </div>
                        )}
                        {analysis.bearCase && (
                          <div className="rounded-2xl border border-neon-red/20 bg-neon-red/10 p-3 text-sm text-neon-red">
                            Bear case: {analysis.bearCase}
                          </div>
                        )}
                        {analysis.nextTrigger && (
                          <div className="rounded-2xl border border-surface-500 bg-surface-700/70 p-3 text-sm text-gray-300">
                            Next trigger: {analysis.nextTrigger}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-sm text-gray-400">
                    {analysisLoading ? 'Building live thesis from fetched indicators...' : 'AI analysis unavailable right now.'}
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="rounded-3xl border border-dashed border-surface-500 bg-surface-800/80 p-10 text-center text-gray-500">
              Select a symbol to view live indicator analysis.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function InfoBlueprintCard() {
  return (
    <div className="rounded-2xl border border-surface-500/50 bg-surface-700/70 p-4">
      <div className="mb-3 flex items-center gap-2">
        <Info size={15} className="text-blue-300" />
        <p className="text-sm font-bold text-white">What lives in Info</p>
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        {[
          {
            title: 'Candlestick Intelligence',
            body: 'Click any candle and ET Alpha builds a factor blueprint using live chart structure plus linked headlines.',
            tone: 'text-blue-300',
          },
          {
            title: 'Narrative + Sentiment',
            body: 'IPO watch and market sentiment come back together here so you can compare numbers and narrative in one place.',
            tone: 'text-teal-300',
          },
          {
            title: 'Derivatives Context',
            body: 'Options chain AI gives support, resistance, and F&O bias so the chart story is not floating alone.',
            tone: 'text-purple-300',
          },
        ].map(card => (
          <div key={card.title} className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3">
            <p className={cn('text-xs font-semibold uppercase tracking-[0.16em]', card.tone)}>{card.title}</p>
            <p className="mt-2 text-sm leading-6 text-gray-400">{card.body}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

function InfoTab() {
  return (
    <div className="space-y-5 pb-3">
      <div className="relative overflow-hidden rounded-[28px] border border-blue-400/30 bg-[radial-gradient(circle_at_top_left,rgba(56,189,248,0.16),transparent_26%),linear-gradient(135deg,#0e1628_0%,#08101d_78%)] p-5 shadow-card">
        <div className="absolute inset-0 bg-grid-surface opacity-25" />
        <div className="relative flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-blue-400/30 bg-blue-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-blue-300">
              <Sparkles size={12} />
              Intelligence Layer
            </div>
            <h2 className="font-display text-3xl font-black text-white">Market Info Command Center</h2>
            <p className="mt-2 text-sm leading-6 text-gray-300">
              This restores the deeper research tools: candlesticks, IPO watch, sentiment scan, options context, and
              the new move blueprint that explains what likely pushed a stock up or down.
            </p>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <MiniStat label="Chart AI" value="Live" tone="text-blue-300" />
            <MiniStat label="Narrative Scan" value="On" tone="text-teal-300" />
            <MiniStat label="Blueprint" value="Active" tone="text-brand-300" />
          </div>
        </div>
      </div>

      <InfoBlueprintCard />

      <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <StockChart />
        <div className="space-y-4">
          <IPOTracker />
          <SentimentScanner />
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.05fr_0.95fr]">
        <OptionsChain />
        <div className="rounded-2xl border border-surface-500/50 bg-surface-700/70 p-4">
          <div className="mb-4 flex items-center gap-2">
            <BarChart3 size={15} className="text-brand-300" />
            <p className="text-sm font-bold text-white">Research Notes</p>
          </div>

          <div className="space-y-3">
            {[
              'The candlestick blueprint now keeps the most important factor tags directly on the chart so you can see the likely cause without scrolling away from price action.',
              'IPO Tracker and Sentiment Scanner sit beside the chart so primary market interest and secondary market narrative are visible together.',
              'Options Chain adds derivatives context so support, resistance, and positioning can validate the stock blueprint.',
              'When evidence is weak, the blueprint marks items as hypotheses and suggests what to verify next instead of overstating certainty.',
            ].map(step => (
              <div key={step} className="rounded-xl border border-surface-500/40 bg-surface-800/70 px-3 py-3 text-sm leading-6 text-gray-300">
                {step}
              </div>
            ))}
          </div>

          <div className="mt-4 rounded-xl border border-neon-red/20 bg-neon-red/10 p-3 text-sm leading-6 text-neon-red">
            Guardrail: the blueprint panel only treats supplied headlines as facts. When evidence is thin, it marks the reason as a hypothesis instead of pretending certainty.
          </div>
        </div>
      </div>
    </div>
  )
}

function IntelTab() {
  const [ticker, setTicker] = useState('RELIANCE')
  const [input, setInput] = useState('RELIANCE')
  const [loading, setLoading] = useState(true)
  const [briefing, setBriefing] = useState('')
  const [events, setEvents] = useState<IntelEvent[]>([])
  const [headlines, setHeadlines] = useState<HeadlineItem[]>([])
  const [citations, setCitations] = useState<{ title: string; url: string; content: string }[]>([])

  const loadIntel = async (symbol: string) => {
    setLoading(true)
    try {
      const news = await fetchTickerNews(symbol)
      setHeadlines(news)
      const fallbackEvents = buildFallbackIntelEvents(symbol, news)
      const fallbackBriefing = news.length > 0
        ? `Linked headlines were found for ${symbol}. ET Alpha is using those live references while richer web intelligence is loading or temporarily unavailable.`
        : `No linked headlines were found for ${symbol} right now, so ET Alpha is waiting for stronger live external context.`
      const tickerQuery = symbol === 'NIFTY50' ? 'NIFTY 50 India market' : `${symbol} NSE India stock`

      try {
        const research = await groqSearchChat(
          'You are a market intelligence analyst. Build a concise current-impact briefing using live web search. Separate confirmed information from inference. Return plain text for the briefing.',
          `Create a current market intelligence briefing for ${tickerQuery}. Focus on the latest national, international, sector, and company factors affecting the move. Mention only the most relevant current items and keep it under 140 words.`,
          {
            country: 'india',
            include_domains: ['reuters.com', 'economictimes.indiatimes.com', 'moneycontrol.com', 'nseindia.com', 'business-standard.com'],
          },
        )
        setBriefing(research.content || fallbackBriefing)
        setCitations(research.citations.slice(0, 6))

        const eventPrompt = `Ticker: ${tickerQuery}
Current web research summary:
${research.content}

Yahoo/related headlines:
${news.map((item, index) => `${index + 1}. ${item.title} | ${item.publisher}`).join('\n') || 'No Yahoo headlines returned'}

Return ONLY a JSON array:
[{
  "title":"event title",
  "bucket":"domestic|global|sector|company",
  "impact":"bullish|bearish|neutral",
  "why":"one sentence on why it matters",
  "affected":["RELIANCE","NIFTY50","sector ETF"],
  "confidence":0-100
}]

Rules:
- 4 to 6 items only.
- Use current information from the supplied summary/headlines.
- If evidence is mixed, use impact neutral.
- affected should be short ticker or sector labels.`

        const classified = await groqSearchChat(
          'You are a precise financial event classifier. Return only JSON and do not add markdown.',
          eventPrompt,
          {
            country: 'india',
            include_domains: ['reuters.com', 'economictimes.indiatimes.com', 'moneycontrol.com', 'nseindia.com', 'business-standard.com'],
          },
        )
        const parsedEvents = parseJsonArray<IntelEvent>(classified.content)
        setEvents(parsedEvents.length > 0 ? parsedEvents : fallbackEvents)
      } catch {
        setBriefing(fallbackBriefing)
        setEvents(fallbackEvents)
        setCitations(news.map(item => ({ title: item.title, url: item.link, content: item.publisher })).slice(0, 6))
      }
    } catch {
      setBriefing('Market intelligence is temporarily unavailable.')
      setEvents([])
      setCitations([])
      setHeadlines([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadIntel(ticker)
  }, [ticker])

  const grouped = useMemo(() => ({
    domestic: events.filter(item => item.bucket === 'domestic'),
    global: events.filter(item => item.bucket === 'global'),
    sector: events.filter(item => item.bucket === 'sector'),
    company: events.filter(item => item.bucket === 'company'),
  }), [events])

  return (
    <div className="space-y-5 pb-3">
      <div className="relative overflow-hidden rounded-[28px] border border-emerald-400/30 bg-[radial-gradient(circle_at_top_right,rgba(16,185,129,0.16),transparent_28%),linear-gradient(135deg,#0d1822_0%,#08101d_72%)] p-5 shadow-card">
        <div className="absolute inset-0 bg-grid-surface opacity-25" />
        <div className="relative flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-emerald-300">
              <Orbit size={12} />
              Live Market Intelligence
            </div>
            <h2 className="font-display text-3xl font-black text-white">Intel Feed</h2>
            <p className="mt-2 text-sm leading-6 text-gray-300">
              A live external-driver layer for each stock. ET Alpha pulls current web context, classifies what matters,
              and maps domestic, global, sector, and company forces into one view.
            </p>
          </div>

          <div className="flex gap-2">
            <input
              value={input}
              onChange={event => setInput(event.target.value.toUpperCase())}
              onKeyDown={event => event.key === 'Enter' && setTicker(input.trim().toUpperCase() || 'RELIANCE')}
              placeholder="Ticker"
              className="rounded-2xl border border-surface-500 bg-surface-700 px-4 py-3 text-sm text-white outline-none focus:border-emerald-400/60"
            />
            <button
              onClick={() => setTicker(input.trim().toUpperCase() || 'RELIANCE')}
              className="inline-flex items-center gap-2 rounded-2xl border border-emerald-400/40 bg-emerald-500/10 px-4 py-3 text-sm font-semibold text-emerald-200 transition hover:bg-emerald-500/20"
            >
              <Search size={15} />
              Load Intel
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <MiniStat label="Ticker" value={ticker} tone="text-emerald-300" />
        <MiniStat label="Intel Events" value={events.length} tone="text-white" />
        <MiniStat label="Linked Headlines" value={headlines.length} tone="text-blue-300" />
        <MiniStat label="Web Sources" value={citations.length} tone="text-purple-300" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]">
        <div className="space-y-4">
          <div className="rounded-3xl border border-surface-500/40 bg-surface-800/80 p-5">
            <div className="mb-3 flex items-center gap-2">
              <Globe2 size={16} className="text-emerald-300" />
              <h3 className="text-lg font-bold text-white">Current Briefing</h3>
              {loading && <Loader2 size={14} className="animate-spin text-emerald-300" />}
            </div>
            <p className="text-sm leading-6 text-gray-200">
              {loading ? 'Collecting current web context and classifying the most relevant drivers...' : briefing || 'No briefing available.'}
            </p>
          </div>

          <div className="rounded-3xl border border-surface-500/40 bg-surface-800/80 p-5">
            <div className="mb-4 flex items-center gap-2">
              <ShieldAlert size={16} className="text-brand-300" />
              <h3 className="text-lg font-bold text-white">Factor Grid</h3>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              {[
                { label: 'Domestic', tone: 'text-blue-300', items: grouped.domestic },
                { label: 'Global', tone: 'text-purple-300', items: grouped.global },
                { label: 'Sector', tone: 'text-emerald-300', items: grouped.sector },
                { label: 'Company', tone: 'text-amber-300', items: grouped.company },
              ].map(group => (
                <div key={group.label} className="rounded-2xl border border-surface-500/40 bg-surface-700/60 p-4">
                  <p className={cn('text-xs font-semibold uppercase tracking-[0.16em]', group.tone)}>{group.label}</p>
                  <div className="mt-3 space-y-2">
                    {group.items.length > 0 ? group.items.map(item => (
                      <div key={`${group.label}-${item.title}`} className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-semibold text-white">{item.title}</p>
                          <span className={cn(
                            'rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.14em]',
                            item.impact === 'bullish'
                              ? 'border-neon-green/20 bg-neon-green/10 text-neon-green'
                              : item.impact === 'bearish'
                              ? 'border-neon-red/20 bg-neon-red/10 text-neon-red'
                              : 'border-surface-500 bg-surface-700 text-gray-300',
                          )}>
                            {item.impact}
                          </span>
                        </div>
                        <p className="mt-2 text-[11px] leading-5 text-gray-400">{item.why}</p>
                        <div className="mt-3 flex flex-wrap gap-2">
                          {item.affected.map(tag => (
                            <span key={`${item.title}-${tag}`} className="rounded-full border border-surface-500 bg-surface-700 px-2.5 py-1 text-[10px] text-gray-300">
                              {tag}
                            </span>
                          ))}
                          <span className="rounded-full border border-brand-400/20 bg-brand-500/10 px-2.5 py-1 text-[10px] text-brand-300">
                            Confidence {item.confidence}
                          </span>
                        </div>
                      </div>
                    )) : (
                      <div className="rounded-xl border border-dashed border-surface-500 px-3 py-4 text-sm text-gray-500">
                        {loading ? 'Loading factors...' : 'No classified factors yet.'}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-3xl border border-surface-500/40 bg-surface-800/80 p-5">
            <div className="mb-3 flex items-center gap-2">
              <Newspaper size={16} className="text-blue-300" />
              <h3 className="text-lg font-bold text-white">Linked Headlines</h3>
            </div>
            <div className="space-y-2">
              {headlines.length > 0 ? headlines.map(item => (
                <a
                  key={item.link}
                  href={item.link}
                  target="_blank"
                  rel="noreferrer"
                  className="block rounded-xl border border-surface-500/40 bg-surface-700/60 p-3 transition hover:border-blue-400/40 hover:bg-surface-700"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-white">{item.title}</p>
                      <p className="mt-1 text-[11px] text-gray-500">{item.publisher}</p>
                    </div>
                    <ExternalLink size={13} className="mt-0.5 text-gray-500" />
                  </div>
                </a>
              )) : (
                <div className="rounded-xl border border-dashed border-surface-500 px-3 py-4 text-sm text-gray-500">
                  {loading ? 'Loading linked headlines...' : 'No linked headlines were found.'}
                </div>
              )}
            </div>
          </div>

          <div className="rounded-3xl border border-surface-500/40 bg-surface-800/80 p-5">
            <div className="mb-3 flex items-center gap-2">
              <BrainCircuit size={16} className="text-purple-300" />
              <h3 className="text-lg font-bold text-white">Source Snapshot</h3>
            </div>
            <div className="space-y-2">
              {citations.length > 0 ? citations.map(source => (
                <a
                  key={source.url}
                  href={source.url}
                  target="_blank"
                  rel="noreferrer"
                  className="block rounded-xl border border-surface-500/40 bg-surface-700/60 p-3 transition hover:border-purple-400/40 hover:bg-surface-700"
                >
                  <p className="text-sm font-semibold text-white">{source.title}</p>
                  <p className="mt-1 text-[11px] leading-5 text-gray-400">{source.content}</p>
                  <p className="mt-2 text-[10px] text-purple-300">{source.url}</p>
                </a>
              )) : (
                <div className="rounded-xl border border-dashed border-surface-500 px-3 py-4 text-sm text-gray-500">
                  {loading ? 'Collecting web sources...' : 'No web sources were returned.'}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function MarketsPage() {
  const [activeTab, setActiveTab] = useState<MarketsTab>('markets')

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'markets' as const, label: 'Markets', icon: Activity },
          { id: 'info' as const, label: 'Info', icon: Newspaper },
          { id: 'intel' as const, label: 'Intel', icon: Globe2 },
        ].map(tab => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                'inline-flex items-center gap-2 rounded-2xl border px-4 py-2.5 text-sm font-semibold transition-all',
                activeTab === tab.id
                  ? 'border-brand-400/40 bg-brand-500/12 text-white shadow-glow-amber'
                  : 'border-surface-500/50 bg-surface-700/70 text-gray-400 hover:text-white',
              )}
            >
              <Icon size={15} />
              {tab.label}
            </button>
          )
        })}
      </div>

      {activeTab === 'markets' ? <MarketsWarRoom /> : activeTab === 'info' ? <InfoTab /> : <IntelTab />}
    </div>
  )
}
