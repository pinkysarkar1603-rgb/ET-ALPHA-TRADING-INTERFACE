import { useEffect, useMemo, useState } from 'react'
import { AudioLines, Bot, BrainCircuit, FileText, Globe2, GraduationCap, Loader2, MessageSquare, Mic, Network, Search, ShieldCheck, Sparkles, Trophy, Upload, Wand2 } from 'lucide-react'
import { VoiceInput } from '@/components/shared/MegaFeatures'
import { cn, fetchMarketDashboard, groqChat, type MarketIndicator } from '@/lib/api'

const BHARAT_TABS = [
  { id: 'screener', label: 'Bharat Screener', icon: Mic },
  { id: 'predictive', label: 'Predictive', icon: BrainCircuit },
  { id: 'network', label: 'Network', icon: Network },
  { id: 'macro', label: 'Macro', icon: Globe2 },
  { id: 'reach', label: 'Distribution', icon: MessageSquare },
  { id: 'arena', label: 'Arena', icon: Trophy },
  { id: 'reports', label: 'Reports', icon: FileText },
  { id: 'trust', label: 'Trust', icon: ShieldCheck },
  { id: 'learn', label: 'Learning', icon: GraduationCap },
] as const

type BharatTab = typeof BHARAT_TABS[number]['id']
type ScreenerFilters = { maxPrice?: number; nearHighPct?: number; keywords: string[]; bullishOnly?: boolean; minConviction?: number }
type EarningsSetup = { ticker: string; beatProbability: number; confidence: number; reason: string; headline?: string }
type MacroImpact = { ticker: string; sector: string; impact: 'benefit' | 'risk' | 'mixed'; score: number; note: string }
type ReportInsight = { title: string; detail: string; tone: 'good' | 'watch' | 'risk' }

const QUICK_TERMS: Record<string, string> = {
  PCR: 'Put-call ratio shows how options traders are positioned between downside protection and upside participation.',
  RSI: 'Relative Strength Index measures the pace of moves. Very high values can signal overheating and very low values can signal stress.',
  '52W High': 'Distance from the 52-week high shows whether price is near long-term breakout territory or still recovering.',
  'MACD Histogram': 'The MACD histogram helps show whether momentum is accelerating or fading versus the signal line.',
}

const BHARAT_QUERIES = [
  'Reliance',
  'Bank stocks near support',
  'Railway stocks below Rs 500',
  'Bullish IT names near 52-week high',
]

function withTimeout<T>(promise: Promise<T>, ms = 9000): Promise<T> {
  return Promise.race([promise, new Promise<T>((_, reject) => setTimeout(() => reject(new Error('timeout')), ms))])
}

function parseJsonObject<T>(text: string): T | null {
  const match = text.match(/\{[\s\S]*\}/)
  if (!match) return null
  try { return JSON.parse(match[0]) as T } catch { return null }
}

function parseJsonArray<T>(text: string): T[] {
  const match = text.match(/\[[\s\S]*\]/)
  if (!match) return []
  try { return JSON.parse(match[0]) as T[] } catch { return [] }
}

async function fetchTickerNews(symbol: string) {
  try {
    const response = await withTimeout(fetch(`/yf/v1/finance/search?q=${encodeURIComponent(symbol)}&quotesCount=1&newsCount=4`), 4000)
    const data = await response.json()
    return (data?.news ?? []).slice(0, 3).map((item: any) => ({
      title: String(item?.title ?? ''),
      publisher: String(item?.publisher ?? 'Yahoo'),
      link: String(item?.link ?? '#'),
    }))
  } catch {
    return []
  }
}

function localFiltersFromQuery(query: string): ScreenerFilters {
  const lower = query.toLowerCase()
  const maxPriceMatch = lower.match(/(?:under|below|less than|se kam|<=?)\s*(?:rs\.?|₹)?\s*(\d+)/i) ?? lower.match(/(\d+)\s*(?:se kam|ke andar)/i)
  const nearHigh = lower.includes('52-week high') || lower.includes('52 week high') || lower.includes('high ke paas')
  const keywords = ['railway', 'bank', 'it', 'pharma', 'auto', 'energy', 'consumer', 'infra', 'logistics', 'manufacturing', 'defense'].filter(keyword => lower.includes(keyword))
  return { maxPrice: maxPriceMatch ? Number(maxPriceMatch[1]) : undefined, nearHighPct: nearHigh ? 8 : undefined, keywords, bullishOnly: /bullish|strong|breakout|upar|uptrend/i.test(lower), minConviction: /best|strongest|high conviction/i.test(lower) ? 60 : undefined }
}

function queryIntent(query: string) {
  const lower = query.toLowerCase()
  return {
    hasPriceConstraint: /(?:under|below|less than|se kam|<=?)\s*(?:rs\.?|₹)?\s*\d+/i.test(lower) || /(\d+)\s*(?:se kam|ke andar)/i.test(lower),
    hasHighConstraint: lower.includes('52-week high') || lower.includes('52 week high') || lower.includes('high ke paas'),
    hasBullishConstraint: /bullish|strong|breakout|upar|uptrend/i.test(lower),
    hasConvictionConstraint: /best|strongest|high conviction/i.test(lower),
  }
}

function queryMatches(row: MarketIndicator, filters: ScreenerFilters) {
  if (filters.maxPrice !== undefined && row.price > filters.maxPrice) return false
  if (filters.nearHighPct !== undefined && row.distanceTo52wHighPct > filters.nearHighPct) return false
  if (filters.bullishOnly && row.trend !== 'bullish') return false
  if (filters.minConviction !== undefined && row.conviction < filters.minConviction) return false
  if (filters.keywords.length > 0) {
    const haystack = `${row.company} ${row.sector} ${row.setup}`.toLowerCase()
    const keywordMatch = filters.keywords.some(keyword => {
      if (keyword === 'railway') return /rail|infra|logistics/i.test(haystack)
      if (keyword === 'bank') return /bank/i.test(haystack)
      if (keyword === 'it') return /\bit\b|technology|software/i.test(haystack)
      if (keyword === 'pharma') return /pharma|health/i.test(haystack)
      if (keyword === 'auto') return /auto|motor/i.test(haystack)
      if (keyword === 'energy') return /energy|oil|gas/i.test(haystack)
      if (keyword === 'consumer') return /consumer|retail|fmcg/i.test(haystack)
      return haystack.includes(keyword)
    })
    if (!keywordMatch) return false
  }
  return true
}

function buildPredictiveRows(rows: MarketIndicator[], headlines: Record<string, string>): EarningsSetup[] {
  return rows.slice(0, 5).map(row => {
    const momentumScore = Math.max(-8, Math.min(8, row.momentum5d * 1.2))
    const volumeScore = Math.min(8, Math.max(0, (row.volumeSpike - 1) * 10))
    const rsiScore = row.rsi >= 45 && row.rsi <= 68 ? 8 : row.rsi > 75 ? -4 : row.rsi < 28 ? -3 : 2
    const trendScore = row.trend === 'bullish' ? 9 : row.trend === 'bearish' ? -7 : 0
    const base = 50 + momentumScore + volumeScore + rsiScore + trendScore + row.conviction * 0.12
    return {
      ticker: row.ticker,
      beatProbability: Math.max(28, Math.min(86, Math.round(base))),
      confidence: Math.max(48, Math.min(90, Math.round(44 + row.conviction * 0.42))),
      headline: headlines[row.ticker],
      reason: `${row.setup} with RSI ${row.rsi}, ${row.volumeSpike}x volume, and ${row.momentum5d}% 5-day momentum.`,
    }
  })
}

function buildMacroImpacts(rows: MarketIndicator[], theme: string): MacroImpact[] {
  const lower = theme.toLowerCase()
  const sectorBias = (sector: string) => {
    if (/crude|oil/.test(lower)) { if (sector === 'Energy') return 1.4; if (sector === 'Auto' || sector === 'Consumer') return -1.1 }
    if (/rbi|rate|repo/.test(lower)) { if (sector === 'Banking' || sector === 'Auto') return 1.2; if (sector === 'Consumer') return 0.7 }
    if (/usd|inr|dollar|fed|us cpi|us inflation/.test(lower)) { if (sector === 'IT' || sector === 'Pharma') return 1.1; if (sector === 'Energy') return -0.4 }
    if (/china|pmi|metals|global growth/.test(lower)) { if (sector === 'Logistics' || sector === 'Energy') return 0.8 }
    return 0
  }
  return rows.map(row => {
    const scoreFloat = +(sectorBias(row.sector) + (row.changePct >= 0 ? 0.2 : -0.2) + row.momentum20d * 0.03).toFixed(2)
    return {
      ticker: row.ticker,
      sector: row.sector,
      impact: scoreFloat > 0.45 ? 'benefit' as const : scoreFloat < -0.45 ? 'risk' as const : 'mixed' as const,
      score: Math.min(95, Math.round(50 + Math.abs(scoreFloat) * 20 + row.conviction * 0.2)),
      note: `${row.sector} sensitivity plus current trend (${row.trend}) suggests ${row.ticker} is ${scoreFloat > 0.45 ? 'positively' : scoreFloat < -0.45 ? 'negatively' : 'moderately'} exposed to this theme.`,
    }
  }).sort((a, b) => b.score - a.score).slice(0, 6)
}

function buildRelationshipNodes(selected: MarketIndicator | null, rows: MarketIndicator[]) {
  if (!selected) return []
  const peers = rows.filter(row => row.sector === selected.sector && row.ticker !== selected.ticker).slice(0, 3)
  const macro = selected.sector === 'IT' ? ['USD/INR', 'US Demand'] : selected.sector === 'Energy' ? ['Crude', 'Policy'] : selected.sector === 'Banking' ? ['RBI', 'Liquidity'] : ['Nifty50', 'Flows']
  return [
    { id: selected.ticker, x: 180, y: 82, label: selected.ticker, kind: 'core' },
    ...peers.map((peer, index) => ({ id: peer.ticker, x: 80 + index * 100, y: 185, label: peer.ticker, kind: 'peer' as const })),
    ...macro.map((label, index) => ({ id: label, x: index === 0 ? 95 : 265, y: 268, label, kind: 'macro' as const })),
  ]
}

function fallbackReportInsights(reportText: string): ReportInsight[] {
  const lower = reportText.toLowerCase()
  return [
    { title: 'Tone Shift', detail: lower.includes('growth') || lower.includes('expansion') ? 'Management language is leaning toward growth and expansion.' : 'Tone appears balanced with limited explicit expansion language.', tone: 'good' },
    { title: 'Accounting Watch', detail: lower.includes('contingent liabilities') || lower.includes('exceptional') ? 'Contingent liabilities or exceptional items are mentioned and should be reviewed carefully.' : 'No obvious accounting stress terms were detected in the pasted text.', tone: lower.includes('contingent liabilities') ? 'risk' : 'watch' },
    { title: 'Capex vs Depreciation', detail: lower.includes('capex') && lower.includes('depreciation') ? 'Capex and depreciation are both referenced, which helps compare maintenance vs expansion spending.' : 'Add capex and depreciation sections for a stronger investment-read output.', tone: 'watch' },
  ]
}

function SectionCard({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return <div className="rounded-2xl border border-surface-500/50 bg-surface-700/90 p-5"><p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">{title}</p><h3 className="mt-1 text-lg font-bold text-white">{subtitle}</h3><div className="mt-4">{children}</div></div>
}

export default function BharatPage() {
  const [tab, setTab] = useState<BharatTab>('screener')
  const [rows, setRows] = useState<MarketIndicator[]>([])
  const [rowsLoading, setRowsLoading] = useState(true)
  const [query, setQuery] = useState('Rs 500 se kam ke railway stocks dikhao jo 52-week high ke paas hain')
  const [results, setResults] = useState<MarketIndicator[]>([])
  const [querySummary, setQuerySummary] = useState('Live screener waits for your typed or spoken query.')
  const [screenerLoading, setScreenerLoading] = useState(false)
  const [earningsSetups, setEarningsSetups] = useState<EarningsSetup[]>([])
  const [predictiveLoading, setPredictiveLoading] = useState(false)
  const [networkTicker, setNetworkTicker] = useState('RELIANCE')
  const [macroTheme, setMacroTheme] = useState('Fed rate cut and USD/INR softening')
  const [coachInput, setCoachInput] = useState('Bought after seeing a breakout but I exited too early when price pulled back.')
  const [coachOutput, setCoachOutput] = useState('Run the coach to get a structured bias check and an improvement plan.')
  const [coachLoading, setCoachLoading] = useState(false)
  const [reportText, setReportText] = useState('Paste annual report text here, then run analysis. The engine will turn it into management-tone, accounting-watch, and business-risk bullets.')
  const [reportInsights, setReportInsights] = useState<ReportInsight[]>(fallbackReportInsights(''))
  const [reportLoading, setReportLoading] = useState(false)
  const [learningTerm, setLearningTerm] = useState('PCR')

  useEffect(() => {
    setRowsLoading(true)
    fetchMarketDashboard().then(data => { setRows(data.indicators); setResults(data.indicators.slice(0, 6)) }).catch(() => { setRows([]); setResults([]) }).finally(() => setRowsLoading(false))
  }, [])

  useEffect(() => {
    if (rows.length === 0) return
    void runScreener(query)
    void loadPredictive()
  }, [rows])

  const selectedRow = useMemo(() => rows.find(row => row.ticker === networkTicker) ?? rows[0] ?? null, [networkTicker, rows])
  const relationshipNodes = useMemo(() => buildRelationshipNodes(selectedRow, rows), [selectedRow, rows])
  const macroImpacts = useMemo(() => buildMacroImpacts(rows, macroTheme), [macroTheme, rows])
  const learningText = QUICK_TERMS[learningTerm] ?? QUICK_TERMS.PCR

  async function runScreener(rawQuery: string) {
    if (!rows.length) return
    setScreenerLoading(true)
    const localFilters = localFiltersFromQuery(rawQuery)
    const intent = queryIntent(rawQuery)
    let applied = localFilters
    let explanation = 'Live screener matched the request against price, trend, sector, and 52-week context.'
    if (!intent.hasPriceConstraint && !intent.hasHighConstraint && rawQuery.trim().length <= 15) {
      explanation = `Screening for live ticker or company matches around "${rawQuery.trim()}".`
    }
    try {
      const text = await withTimeout(groqChat('You convert Indian stock screener requests into strict JSON filters. Return only JSON.', `Query: ${rawQuery}
Available sectors and setups:
${rows.slice(0, 12).map(row => `${row.ticker}: sector ${row.sector}, setup ${row.setup}, price ${row.price}`).join('\n')}
Return JSON with keys maxPrice, nearHighPct, keywords, bullishOnly, minConviction, explanation.`), 7000)
      const parsed = parseJsonObject<ScreenerFilters & { explanation?: string }>(text)
      if (parsed) {
        applied = {
          maxPrice: intent.hasPriceConstraint ? parsed.maxPrice ?? localFilters.maxPrice : localFilters.maxPrice,
          nearHighPct: intent.hasHighConstraint ? parsed.nearHighPct ?? localFilters.nearHighPct : localFilters.nearHighPct,
          keywords: Array.isArray(parsed.keywords) && parsed.keywords.length > 0
            ? parsed.keywords.filter(keyword => rawQuery.toLowerCase().includes(String(keyword).toLowerCase()) || rows.some(row => row.ticker.toLowerCase() === String(keyword).toLowerCase() || row.company.toLowerCase().includes(String(keyword).toLowerCase())))
            : localFilters.keywords,
          bullishOnly: intent.hasBullishConstraint ? parsed.bullishOnly ?? localFilters.bullishOnly : localFilters.bullishOnly,
          minConviction: intent.hasConvictionConstraint ? parsed.minConviction ?? localFilters.minConviction : localFilters.minConviction,
        }
        if (applied.keywords.length === 0 && rawQuery.trim().length <= 15) applied.keywords = [rawQuery.trim()]
        if (intent.hasPriceConstraint || intent.hasHighConstraint || intent.hasBullishConstraint || intent.hasConvictionConstraint) {
          explanation = parsed.explanation ?? explanation
        }
      }
    } catch {
      explanation = 'AI parsing was skipped, so the screener used local Hindi-English rule matching on the live market feed.'
    }
    if (applied.keywords.length === 0 && rawQuery.trim().length <= 15) applied.keywords = [rawQuery.trim()]
    setResults(rows.filter(row => queryMatches(row, applied)).sort((a, b) => b.conviction - a.conviction).slice(0, 8))
    setQuerySummary(explanation)
    setScreenerLoading(false)
  }

  async function loadPredictive() {
    if (!rows.length) return
    setPredictiveLoading(true)
    const news = await Promise.all(rows.slice(0, 5).map(async row => [row.ticker, (await fetchTickerNews(row.ticker))[0]?.title ?? 'No fresh headline was fetched for this symbol.'] as const))
    setEarningsSetups(buildPredictiveRows(rows.slice(0, 5), Object.fromEntries(news)))
    setPredictiveLoading(false)
  }

  async function runCoachAnalysis() {
    setCoachLoading(true)
    try {
      setCoachOutput(await withTimeout(groqChat('You are a trading psychology coach for Indian retail investors. Be practical and concise.', `User trade journal:
${coachInput}

Return exactly 3 short sections:
Bias:
What went right:
Next rule:`), 7000))
    } catch {
      const lower = coachInput.toLowerCase()
      const bias = lower.includes('too early') || lower.includes('panic') ? 'Loss aversion / early-profit bias' : lower.includes('averaged down') ? 'Anchoring bias' : 'Execution discipline needs review'
      setCoachOutput(`Bias: ${bias}\nWhat went right: you recognised the setup instead of chasing random noise.\nNext rule: define entry, stop, and hold condition before the trade starts.`)
    } finally {
      setCoachLoading(false)
    }
  }

  async function runReportAnalysis() {
    setReportLoading(true)
    try {
      const text = await withTimeout(groqChat('You analyze annual report excerpts for investors. Return only valid JSON.', `Analyze this report excerpt:
${reportText}

Return JSON array with exactly 4 items, each having title, detail, and tone where tone is good, watch, or risk.
Focus on management tone, accounting watchpoints, capex vs depreciation, and business risks.`), 8000)
      const parsed = parseJsonArray<ReportInsight>(text)
      setReportInsights(parsed.length > 0 ? parsed.slice(0, 4) : fallbackReportInsights(reportText))
    } catch {
      setReportInsights(fallbackReportInsights(reportText))
    } finally {
      setReportLoading(false)
    }
  }

  return (
    <div className="space-y-5 pb-5">
      <div className="relative overflow-hidden rounded-[28px] border border-brand-400/30 bg-[radial-gradient(circle_at_top_left,rgba(255,198,26,0.16),transparent_28%),linear-gradient(135deg,#10192a_0%,#0b111d_74%)] p-5 shadow-card">
        <div className="relative flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-brand-400/30 bg-brand-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-300">
              <Sparkles size={12} />
              Bharat Intelligence Layer
            </div>
            <h2 className="font-display text-3xl font-black text-white">ARTHA DNA, grounded in live market data</h2>
            <p className="mt-2 text-sm leading-6 text-gray-300">
              This layer keeps the Bharat-first product ideas, but now ties them to fetched indicators, live headlines, and Groq-assisted analysis instead of static placeholder cards.
            </p>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Live Feed', value: rowsLoading ? 'Loading' : `${rows.length} names`, tone: 'text-brand-300' },
              { label: 'AI', value: 'Groq', tone: 'text-blue-300' },
              { label: 'Guardrails', value: 'On', tone: 'text-emerald-300' },
            ].map(item => (
              <div key={item.label} className="rounded-xl border border-surface-500/50 bg-surface-800/70 p-3">
                <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">{item.label}</p>
                <p className={cn('mt-1 font-mono text-lg font-black', item.tone)}>{item.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {BHARAT_TABS.map(item => {
          const Icon = item.icon
          return (
            <button key={item.id} onClick={() => setTab(item.id)} className={cn('inline-flex items-center gap-2 rounded-2xl border px-4 py-2 text-sm font-semibold transition-all', tab === item.id ? 'border-brand-400/40 bg-brand-500/12 text-white shadow-glow-amber' : 'border-surface-500/50 bg-surface-700/70 text-gray-400 hover:text-white')}>
              <Icon size={14} />
              {item.label}
            </button>
          )
        })}
      </div>

      {tab === 'screener' && (
        <div className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
          <SectionCard title="India-First" subtitle="Voice-first Bharat stock screener">
            <div className="flex gap-2">
              <input value={query} onChange={event => setQuery(event.target.value)} onKeyDown={event => event.key === 'Enter' && void runScreener(query)} className="flex-1 rounded-xl border border-surface-500 bg-surface-800 px-4 py-3 text-sm text-white outline-none focus:border-brand-500/50" />
              <VoiceInput onTranscript={text => { setQuery(text); void runScreener(text) }} />
              <button onClick={() => void runScreener(query)} className="rounded-xl bg-brand-500 px-4 py-3 text-surface-900 transition hover:bg-brand-400">
                {screenerLoading ? <Loader2 size={16} className="animate-spin" /> : <AudioLines size={16} />}
              </button>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {BHARAT_QUERIES.map(sample => (
                <button key={sample} onClick={() => { setQuery(sample); void runScreener(sample) }} className="rounded-full border border-surface-500 bg-surface-800 px-3 py-1.5 text-[11px] text-gray-300 transition hover:border-brand-400/30 hover:text-white">
                  {sample}
                </button>
              ))}
            </div>
            <p className="mt-3 text-xs leading-6 text-gray-400">{querySummary}</p>
            <div className="mt-4 grid gap-3">
              {results.length > 0 ? results.map(row => (
                <div key={row.ticker} className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-bold text-white">{row.ticker}</p>
                      <p className="text-[11px] text-gray-500">{row.company}</p>
                    </div>
                    <span className={cn('text-sm font-bold', row.changePct >= 0 ? 'text-neon-green' : 'text-neon-red')}>{row.changePct >= 0 ? '+' : ''}{row.changePct}%</span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <span className="rounded-full border border-surface-500 bg-surface-700 px-2.5 py-1 text-[10px] text-gray-300">Rs {row.price.toFixed(2)}</span>
                    <span className="rounded-full border border-blue-400/20 bg-blue-500/10 px-2.5 py-1 text-[10px] text-blue-300">52W high distance {row.distanceTo52wHighPct}%</span>
                    <span className="rounded-full border border-brand-400/20 bg-brand-500/10 px-2.5 py-1 text-[10px] text-brand-300">{row.setup}</span>
                    <span className="rounded-full border border-emerald-400/20 bg-emerald-500/10 px-2.5 py-1 text-[10px] text-emerald-300">Conviction {row.conviction}</span>
                  </div>
                </div>
              )) : <div className="rounded-xl border border-dashed border-surface-500 px-4 py-6 text-sm text-gray-500">No live matches yet for that query.</div>}
            </div>
          </SectionCard>

          <SectionCard title="Live Snapshot" subtitle="What the screener is reading">
            <div className="grid gap-3">
              {rows.slice(0, 4).map(row => (
                <div key={row.ticker} className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-bold text-white">{row.ticker}</p>
                    <p className={cn('text-xs font-semibold', row.trend === 'bullish' ? 'text-neon-green' : row.trend === 'bearish' ? 'text-neon-red' : 'text-gray-300')}>{row.trend}</p>
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <div className="rounded-lg border border-surface-500/40 bg-surface-900 p-2">
                      <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">RSI</p>
                      <p className="mt-1 text-sm font-bold text-white">{row.rsi}</p>
                    </div>
                    <div className="rounded-lg border border-surface-500/40 bg-surface-900 p-2">
                      <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">Volume Spike</p>
                      <p className="mt-1 text-sm font-bold text-brand-300">{row.volumeSpike}x</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </SectionCard>
        </div>
      )}

      {tab === 'predictive' && (
        <SectionCard title="Predictive" subtitle="Earnings setup probability engine">
          <div className="mb-4 flex items-center justify-between gap-4">
            <p className="text-sm leading-6 text-gray-400">
              This is a live event-setup engine. It combines current momentum, volume, RSI balance, and the latest fetched headline context.
            </p>
            <button onClick={() => void loadPredictive()} className="inline-flex items-center gap-2 rounded-xl border border-brand-400/20 bg-brand-500/10 px-4 py-2 text-xs font-semibold text-brand-300 transition hover:bg-brand-500/20">
              {predictiveLoading ? <Loader2 size={13} className="animate-spin" /> : <Wand2 size={13} />}
              Refresh
            </button>
          </div>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {(predictiveLoading ? Array.from({ length: 3 }, (_, index) => ({ ticker: `loading-${index}` } as EarningsSetup)) : earningsSetups).map(item => (
              <div key={item.ticker} className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-4">
                {'beatProbability' in item ? (
                  <>
                    <div className="flex items-center justify-between">
                      <p className="text-lg font-black text-white">{item.ticker}</p>
                      <span className="text-sm font-black text-brand-300">{item.beatProbability}%</span>
                    </div>
                    <p className="mt-1 text-[11px] uppercase tracking-[0.16em] text-gray-500">Beat Probability</p>
                    <p className="mt-3 text-sm leading-6 text-gray-300">{item.reason}</p>
                    <div className="mt-4 rounded-xl border border-surface-500/40 bg-surface-900 p-3">
                      <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">Latest Headline Context</p>
                      <p className="mt-2 text-[11px] leading-5 text-gray-300">{item.headline ?? 'No fresh headline available.'}</p>
                    </div>
                    <p className="mt-3 text-[11px] text-gray-500">Confidence {item.confidence}/100</p>
                  </>
                ) : (
                  <div className="flex min-h-[180px] items-center justify-center text-gray-400"><Loader2 size={18} className="animate-spin" /></div>
                )}
              </div>
            ))}
          </div>
        </SectionCard>
      )}

      {tab === 'network' && (
        <div className="grid gap-4 xl:grid-cols-[0.95fr_1.05fr]">
          <SectionCard title="Network" subtitle="Live relationship graph">
            <div className="mb-4 flex flex-wrap gap-2">
              {rows.slice(0, 6).map(row => (
                <button key={row.ticker} onClick={() => setNetworkTicker(row.ticker)} className={cn('rounded-full border px-3 py-1 text-xs font-semibold transition', networkTicker === row.ticker ? 'border-brand-400/30 bg-brand-500/10 text-brand-300' : 'border-surface-500 bg-surface-800 text-gray-300')}>
                  {row.ticker}
                </button>
              ))}
            </div>
            <svg width="100%" viewBox="0 0 360 320" className="rounded-2xl border border-surface-500/40 bg-[linear-gradient(180deg,#0b111d_0%,#10192a_100%)]">
              {relationshipNodes.slice(1).map(node => (
                <line key={`link-${node.id}`} x1={180} y1={82} x2={node.x} y2={node.y} stroke="#243354" strokeWidth="2" />
              ))}
              {relationshipNodes.map(node => (
                <g key={node.id}>
                  <circle cx={node.x} cy={node.y} r={node.kind === 'core' ? 30 : 24} fill={node.kind === 'core' ? '#17233b' : '#10192a'} stroke={node.kind === 'macro' ? '#38bdf8' : '#ffc61a'} strokeWidth="2" />
                  <text x={node.x} y={node.y + 4} textAnchor="middle" fill="#fff" fontSize="10" fontWeight="700">{node.label}</text>
                </g>
              ))}
            </svg>
          </SectionCard>

          <SectionCard title="Context" subtitle={selectedRow ? `${selectedRow.ticker} relationship summary` : 'Relationship summary'}>
            {selectedRow ? (
              <div className="space-y-3">
                <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3">
                  <p className="text-sm font-bold text-white">{selectedRow.company}</p>
                  <p className="mt-1 text-[11px] leading-5 text-gray-400">
                    Sector: {selectedRow.sector}. Setup: {selectedRow.setup}. Current conviction: {selectedRow.conviction}/100. The graph links this stock to same-sector peers and the macro variables most likely to change its trade quality.
                  </p>
                </div>
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3">
                    <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">Support / Resistance</p>
                    <p className="mt-2 text-sm font-bold text-blue-300">Rs {selectedRow.support.toFixed(2)} / Rs {selectedRow.resistance.toFixed(2)}</p>
                  </div>
                  <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3">
                    <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">Flow State</p>
                    <p className="mt-2 text-sm font-bold text-white">{selectedRow.volumeSpike}x volume, {selectedRow.momentum20d}% 20D momentum</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-surface-500 px-4 py-6 text-sm text-gray-500">Relationship graph will activate once live rows are available.</div>
            )}
          </SectionCard>
        </div>
      )}

      {tab === 'macro' && (
        <SectionCard title="Macro" subtitle="Global macro impact engine">
          <div className="mb-4 flex gap-2">
            <input value={macroTheme} onChange={event => setMacroTheme(event.target.value)} className="flex-1 rounded-xl border border-surface-500 bg-surface-800 px-4 py-3 text-sm text-white outline-none focus:border-brand-500/50" />
            <button onClick={() => setMacroTheme(macroTheme)} className="rounded-xl bg-brand-500 px-4 py-3 text-surface-900 transition hover:bg-brand-400">
              <Search size={16} />
            </button>
          </div>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {macroImpacts.map(item => (
              <div key={`${item.ticker}-${item.sector}`} className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-4">
                <div className="flex items-center justify-between">
                  <p className="text-lg font-black text-white">{item.ticker}</p>
                  <span className={cn('rounded-full border px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.14em]', item.impact === 'benefit' ? 'border-neon-green/20 bg-neon-green/10 text-neon-green' : item.impact === 'risk' ? 'border-neon-red/20 bg-neon-red/10 text-neon-red' : 'border-surface-500 bg-surface-900 text-gray-300')}>{item.impact}</span>
                </div>
                <p className="mt-1 text-[11px] text-gray-500">{item.sector}</p>
                <p className="mt-3 text-sm leading-6 text-gray-300">{item.note}</p>
                <div className="mt-4 h-2 overflow-hidden rounded-full bg-surface-900">
                  <div className="h-full rounded-full bg-brand-400" style={{ width: `${item.score}%` }} />
                </div>
                <p className="mt-2 text-[11px] text-gray-500">Confidence band {item.score}/100</p>
              </div>
            ))}
          </div>
        </SectionCard>
      )}

      {tab === 'reach' && (
        <div className="grid gap-4 xl:grid-cols-2">
          <SectionCard title="Distribution" subtitle="WhatsApp-native intelligence">
            <div className="space-y-3">
              {['Send "NIFTY" for live levels.', 'Send a stock name for instant AI analysis.', 'Send a portfolio screenshot for health check.', 'Receive a personalised 8:45 AM pre-market brief.'].map(item => (
                <div key={item} className="rounded-xl border border-surface-500/40 bg-surface-800/70 px-3 py-3 text-sm text-gray-300">{item}</div>
              ))}
            </div>
          </SectionCard>
          <SectionCard title="Speed" subtitle="Pre-market alpha brief">
            <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-4">
              <p className="text-sm leading-6 text-gray-300">
                This module is kept as a clean product surface for now. The live market stack behind it is already in ET Alpha, so the next activation step is delivery, not fake mock content.
              </p>
            </div>
          </SectionCard>
        </div>
      )}

      {tab === 'arena' && (
        <SectionCard title="Arena" subtitle="Paper trading arena with AI coach">
          <div className="grid gap-4 xl:grid-cols-[0.95fr_1.05fr]">
            <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-4">
              <p className="text-sm font-bold text-white">Virtual capital: Rs 10,00,000</p>
              <div className="mt-3 grid grid-cols-3 gap-3">
                {[
                  { label: 'Win rate', value: rows.length > 0 ? `${Math.max(42, Math.min(68, Math.round(48 + rows.filter(row => row.changePct > 0).length * 3)))}%` : '--' },
                  { label: 'Loss aversion', value: '58/100' },
                  { label: 'Overconfidence', value: '37/100' },
                ].map(item => (
                  <div key={item.label} className="rounded-lg border border-surface-500/40 bg-surface-900 p-3">
                    <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">{item.label}</p>
                    <p className="mt-1 font-mono text-sm font-bold text-white">{item.value}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-4">
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold text-white">AI Coach</p>
                <button onClick={() => void runCoachAnalysis()} className="inline-flex items-center gap-2 rounded-xl border border-brand-400/20 bg-brand-500/10 px-4 py-2 text-xs font-semibold text-brand-300 transition hover:bg-brand-500/20">
                  {coachLoading ? <Loader2 size={13} className="animate-spin" /> : <Bot size={13} />}
                  Analyze
                </button>
              </div>
              <textarea value={coachInput} onChange={event => setCoachInput(event.target.value)} className="mt-3 h-28 w-full rounded-xl border border-surface-500 bg-surface-900 px-3 py-3 text-xs text-gray-300 outline-none focus:border-brand-500/50" />
              <div className="mt-3 whitespace-pre-wrap rounded-xl border border-brand-400/20 bg-brand-500/8 p-3 text-sm leading-6 text-gray-300">
                {coachOutput}
              </div>
            </div>
          </div>
        </SectionCard>
      )}

      {tab === 'reports' && (
        <SectionCard title="Live + Deep" subtitle="Report intelligence">
          <div className="grid gap-4 xl:grid-cols-[1.05fr_0.95fr]">
            <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Upload size={14} className="text-blue-300" />
                  <p className="text-sm font-bold text-white">Annual Report Intelligence</p>
                </div>
                <button onClick={() => void runReportAnalysis()} className="inline-flex items-center gap-2 rounded-xl border border-brand-400/20 bg-brand-500/10 px-4 py-2 text-xs font-semibold text-brand-300 transition hover:bg-brand-500/20">
                  {reportLoading ? <Loader2 size={13} className="animate-spin" /> : <Wand2 size={13} />}
                  Analyze
                </button>
              </div>
              <textarea value={reportText} onChange={event => setReportText(event.target.value)} className="mt-3 h-36 w-full rounded-xl border border-surface-500 bg-surface-900 px-3 py-3 text-xs text-gray-300 outline-none focus:border-brand-500/50" />
            </div>
            <div className="grid gap-3">
              {reportInsights.map(item => (
                <div key={item.title} className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-bold text-white">{item.title}</p>
                    <span className={cn('rounded-full px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.14em]', item.tone === 'good' ? 'bg-neon-green/10 text-neon-green' : item.tone === 'risk' ? 'bg-neon-red/10 text-neon-red' : 'bg-surface-900 text-gray-300')}>{item.tone}</span>
                  </div>
                  <p className="mt-2 text-sm leading-6 text-gray-300">{item.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </SectionCard>
      )}

      {tab === 'trust' && (
        <SectionCard title="Trust" subtitle="SEBI compliance and hallucination guard">
          <div className="grid gap-4 md:grid-cols-3">
            {[
              'Every recommendation is framed as market intelligence, not registered investment advice.',
              'Current outputs are checked against live indicator values before being shown in the UI.',
              'Low-confidence setups should produce watch-or-escalate behaviour instead of forced conviction.',
            ].map(item => (
              <div key={item} className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-4 text-sm leading-6 text-gray-300">{item}</div>
            ))}
          </div>
        </SectionCard>
      )}

      {tab === 'learn' && (
        <SectionCard title="Education" subtitle="Micro-learning engine">
          <div className="mb-4 flex flex-wrap gap-2">
            {Object.keys(QUICK_TERMS).map(term => (
              <button key={term} onClick={() => setLearningTerm(term)} className={cn('rounded-full border px-3 py-1 text-xs font-semibold transition', learningTerm === term ? 'border-brand-400/30 bg-brand-500/10 text-brand-300' : 'border-surface-500 bg-surface-800 text-gray-300')}>
                {term}
              </button>
            ))}
          </div>
          <div className="grid gap-4 md:grid-cols-[0.75fr_1.25fr]">
            <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-4">
              <p className="text-sm font-bold text-white">{learningTerm}</p>
              <p className="mt-3 text-sm leading-6 text-gray-300">{learningText}</p>
            </div>
            <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-4">
              <p className="text-sm font-bold text-white">Why it matters right now</p>
              <p className="mt-3 text-sm leading-6 text-gray-300">
                ET Alpha connects these concepts directly to live indicator cards, chart annotations, and risk flags, so the education layer is anchored to what the user is actually seeing in the market.
              </p>
            </div>
          </div>
        </SectionCard>
      )}
    </div>
  )
}
