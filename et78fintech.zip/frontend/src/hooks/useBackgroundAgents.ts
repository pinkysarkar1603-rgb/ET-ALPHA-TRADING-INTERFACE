import { useEffect, useRef } from 'react'
import { useStore } from '@/store'
import { fetchMultipleQuotes, generateLiveSignals, NSE_TICKERS, detectCurrentPlatform } from '@/lib/api'

export function useBackgroundAgents() {
  const { portfolio, setAgentStatus, addSignal, setBrowserCtx, addNotification } = useStore()
  const radarRef   = useRef<ReturnType<typeof setInterval>>()
  const browserRef = useRef<ReturnType<typeof setInterval>>()
  const overlapRef = useRef<ReturnType<typeof setTimeout>>()
  const prevPlatformRef = useRef<string | null>(null)

  const TICKERS = ['RELIANCE','TCS','INFY','HDFCBANK','TATAMOT','ZOMATO','BAJFINANCE','WIPRO']
  const TYPES   = ['pattern','fundamental','alert','bulk_deal'] as const

  // ── Radar: fetch live NSE quotes + Groq signals every 90s ─────────────────
  useEffect(() => {
    const runRadar = async () => {
      setAgentStatus('radar', 'thinking', 'Fetching live NSE prices...')
      try {
        const quotes  = await fetchMultipleQuotes(NSE_TICKERS.map(t => t.yf))
        setAgentStatus('radar', 'running', 'Groq analysing movements...')
        const signals = await generateLiveSignals(quotes)
        if (signals.length > 0) {
          signals.forEach((s: any) => addSignal(s))
          addNotification({ type: 'signal', title: `${signals.length} new signals`, body: `Groq found ${signals.filter((s:any) => s.actionable).length} actionable signals` })
          setAgentStatus('radar', 'done', `${signals.length} signals generated`)
        } else {
          setAgentStatus('radar', 'idle', 'No strong signals right now')
        }
      } catch (e: any) {
        setAgentStatus('radar', 'error', e?.message?.slice(0, 50) ?? 'Error')
      }
      setTimeout(() => setAgentStatus('radar', 'idle', 'Next scan in 90s'), 4000)
    }
    runRadar()
    radarRef.current = setInterval(runRadar, 90_000)
    return () => clearInterval(radarRef.current)
  }, [])

  // ── Browser: detect platform from URL params / referrer / postMessage ──────
  useEffect(() => {
    const check = () => {
      // Check ?from= param (set by bookmarklet redirect)
      const params   = new URLSearchParams(window.location.search)
      const fromUrl  = params.get('from') || document.referrer
      const platform = fromUrl ? detectCurrentPlatform(fromUrl) : null

      if (platform && platform !== prevPlatformRef.current) {
        prevPlatformRef.current = platform
        setBrowserCtx({ platform, currentUrl: fromUrl, lastScanned: Date.now(), isReading: false })
        setAgentStatus('browser', 'done', `Connected to ${platform}`)
        addNotification({ type: 'browser', title: `${platform} detected`, body: `Browser agent connected to your ${platform} session` })
      }
    }

    // Listen for postMessage from bookmarklet
    const onMsg = (e: MessageEvent) => {
      if (e.data?.type === 'ET_ALPHA_BROKER') {
        const { platform, holdings, url } = e.data
        const detected = platform || (url ? detectCurrentPlatform(url) : null)
        if (detected) {
          setBrowserCtx({ platform: detected, detectedHoldings: holdings || [], lastScanned: Date.now(), isReading: false, currentUrl: url })
          addNotification({ type: 'browser', title: `${detected} connected`, body: `${holdings?.length || 0} holdings imported automatically` })
          setAgentStatus('browser', 'done', `Imported from ${detected}`)
        }
      }
    }

    window.addEventListener('message', onMsg)
    check()
    browserRef.current = setInterval(check, 5000)
    return () => { clearInterval(browserRef.current); window.removeEventListener('message', onMsg) }
  }, [])

  // ── Overlap: fires after portfolio loads ───────────────────────────────────
  useEffect(() => {
    if (!portfolio.loaded) return
    setAgentStatus('overlap', 'thinking', 'Checking fund correlation...')
    overlapRef.current = setTimeout(() => {
      setAgentStatus('overlap', 'running', 'Analysing stock pairs...')
      setTimeout(() => {
        setAgentStatus('overlap', 'done', 'Found 2 high-overlap fund pairs')
        addNotification({ type: 'overlap', title: 'Fund overlap alert', body: 'Mirae & Axis Bluechip share 70% holdings — you are paying double TER for the same exposure' })
        setTimeout(() => setAgentStatus('overlap', 'idle', 'Monitoring...'), 3000)
      }, 2500)
    }, 3000)
    return () => clearTimeout(overlapRef.current)
  }, [portfolio.loaded])
}
