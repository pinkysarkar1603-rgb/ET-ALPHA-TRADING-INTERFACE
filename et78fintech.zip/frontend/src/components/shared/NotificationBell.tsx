import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Bell, X, Zap, AlertTriangle, Globe, Bot, TrendingUp } from 'lucide-react'
import { useStore } from '@/store'
import { cn, timeAgo } from '@/lib/api'

const ICONS: Record<string, any> = {
  signal:  Zap,
  overlap: AlertTriangle,
  browser: Globe,
  agent:   Bot,
  price:   TrendingUp,
}
const COLORS: Record<string, string> = {
  signal:  'text-brand-400 bg-brand-500/10',
  overlap: 'text-orange-400 bg-orange-500/10',
  browser: 'text-blue-400 bg-blue-500/10',
  agent:   'text-purple-400 bg-purple-500/10',
  price:   'text-neon-green bg-neon-green/10',
}

export default function NotificationBell() {
  const { notifications, markAllRead, unreadCount } = useStore()
  const [open, setOpen] = useState(false)
  const count = unreadCount()

  return (
    <div className="relative">
      <button
        onClick={() => { setOpen(o => !o); if (!open) markAllRead() }}
        className="relative p-1.5 text-gray-400 hover:text-white hover:bg-surface-600 rounded-md transition-colors"
      >
        <Bell size={14} />
        {count > 0 && (
          <motion.span
            initial={{ scale: 0 }} animate={{ scale: 1 }}
            className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-neon-red rounded-full text-[8px] font-black text-white flex items-center justify-center"
          >
            {count > 9 ? '9+' : count}
          </motion.span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.96 }}
              className="absolute right-0 top-8 w-80 bg-surface-700 border border-surface-500/60 rounded-xl shadow-xl z-50 overflow-hidden"
            >
              <div className="flex items-center justify-between px-4 py-2.5 border-b border-surface-500/40">
                <p className="text-xs font-semibold text-white">Notifications</p>
                <button onClick={() => setOpen(false)} className="text-gray-500 hover:text-white"><X size={12} /></button>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="py-8 text-center text-xs text-gray-500">No notifications yet</div>
                ) : notifications.map(n => {
                  const Icon = ICONS[n.type] ?? Bell
                  return (
                    <div key={n.id} className={cn('flex gap-3 px-4 py-3 border-b border-surface-500/20 hover:bg-surface-600/40 transition-colors', !n.read && 'bg-brand-500/3')}>
                      <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5', COLORS[n.type] || 'bg-surface-600 text-gray-400')}>
                        <Icon size={12} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-semibold text-white leading-snug">{n.title}</p>
                        <p className="text-[10px] text-gray-400 mt-0.5 leading-relaxed">{n.body}</p>
                        <p className="text-[9px] text-gray-600 mt-1">{timeAgo(n.timestamp)}</p>
                      </div>
                      {!n.read && <div className="w-1.5 h-1.5 bg-brand-400 rounded-full mt-1.5 flex-shrink-0" />}
                    </div>
                  )
                })}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
