import { useState, useEffect, useRef } from 'react'
import { TrendingUp, TrendingDown, Wifi, WifiOff, Loader2 } from 'lucide-react'
import { NSE_TICKERS, cn } from '@/lib/api'
import { fetchMultipleQuotes, SEED_PRICES, type LiveQuote } from '@/lib/marketData'

export default function LiveTicker() {
  // Start with seed prices instantly — no blank screen
  const [quotes, setQuotes] = useState<Record<string, LiveQuote>>(() => {
    const init: Record<string, LiveQuote> = {}
    NSE_TICKERS.forEach(t => {
      const s = SEED_PRICES[t.yf]
      if (s) init[t.yf] = { sym: t.yf, price: s.price, chg: 0, chgPct: s.chgPct, prev: s.price, volume: 0, high: s.price, low: s.price, open: s.price }
    })
    return init
  })
  const [live, setLive]       = useState(false)
  const [loading, setLoading] = useState(true)
  const timerRef              = useRef<ReturnType<typeof setInterval>>()

  const loadQuotes = async () => {
    try {
      const syms = NSE_TICKERS.map(t => t.yf)
      const data = await fetchMultipleQuotes(syms)
      // Only update if we got real live data (volume > 0 means real quote)
      const hasLive = Object.values(data).some(q => q.volume > 0)
      setQuotes(prev => ({ ...prev, ...data }))
      setLive(hasLive)
    } catch {
      setLive(false)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadQuotes()
    timerRef.current = setInterval(loadQuotes, 30_000)
    return () => clearInterval(timerRef.current)
  }, [])

  const items = NSE_TICKERS.map(t => {
    const q = quotes[t.yf]
    return { sym: t.sym, price: q?.price ?? 0, chgPct: q?.chgPct ?? 0, isLive: (q?.volume ?? 0) > 0 }
  })
  const doubled = [...items, ...items]

  return (
    <div className="bg-surface-800 border-b border-surface-500/50 h-8 flex items-center overflow-hidden relative">
      <div className="absolute left-0 top-0 w-12 h-full bg-gradient-to-r from-surface-800 to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 top-0 w-20 h-full bg-gradient-to-l from-surface-800 to-transparent z-10 pointer-events-none" />

      <div className="ticker-wrap flex-1 overflow-hidden">
        <div className="ticker-inner flex items-center">
          {doubled.map((t, i) => (
            <span key={i} className="inline-flex items-center gap-1.5 px-4 border-r border-surface-500/30 whitespace-nowrap">
              <span className="text-[11px] font-medium text-gray-400">{t.sym}</span>
              <span className={cn('text-[11px] font-mono font-semibold', t.chgPct > 0 ? 'text-neon-green' : t.chgPct < 0 ? 'text-neon-red' : 'text-gray-300')}>
                {t.price > 1000 ? t.price.toLocaleString('en-IN', { maximumFractionDigits: 1 }) : t.price.toFixed(2)}
              </span>
              <span className={cn('inline-flex items-center gap-0.5 text-[10px] font-mono', t.chgPct > 0 ? 'text-neon-green' : t.chgPct < 0 ? 'text-neon-red' : 'text-gray-500')}>
                {t.chgPct > 0 ? <TrendingUp size={9} /> : t.chgPct < 0 ? <TrendingDown size={9} /> : null}
                {t.chgPct >= 0 ? '+' : ''}{t.chgPct.toFixed(2)}%
              </span>
            </span>
          ))}
        </div>
      </div>

      {/* Status badge */}
      <div className="absolute right-2 top-0 h-full flex items-center z-20">
        {loading ? (
          <div className="flex items-center gap-1 text-[9px] text-gray-500">
            <Loader2 size={8} className="animate-spin" /> fetching
          </div>
        ) : live ? (
          <div className="flex items-center gap-1 text-[9px] text-neon-green">
            <Wifi size={9} /> LIVE
          </div>
        ) : (
          <div className="flex items-center gap-1 text-[9px] text-gray-500">
            <WifiOff size={9} /> cached
          </div>
        )}
      </div>
    </div>
  )
}
