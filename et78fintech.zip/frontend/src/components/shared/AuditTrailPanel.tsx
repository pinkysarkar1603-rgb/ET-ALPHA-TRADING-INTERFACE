import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronDown, ChevronRight, CheckCircle2, XCircle, Loader2, Terminal, Trash2 } from 'lucide-react'
import { useStore } from '@/store'
import { cn, timeAgo } from '@/lib/api'
import type { AuditEntry } from '@/store'

function AuditRow({ entry, index }: { entry: AuditEntry; index: number }) {
  const [expanded, setExpanded] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.03 }}
      className="border-b border-surface-500/20 last:border-0"
    >
      <button
        onClick={() => setExpanded(e => !e)}
        className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-surface-600/30 transition-colors text-left"
      >
        {/* Status icon */}
        <div className="flex-shrink-0">
          {entry.status === 'running' && <Loader2 size={12} className="text-brand-400 animate-spin" />}
          {entry.status === 'done'    && <CheckCircle2 size={12} className="text-neon-green" />}
          {entry.status === 'error'   && <XCircle size={12} className="text-neon-red" />}
        </div>

        {/* Agent name */}
        <span className={cn(
          'text-[10px] font-bold px-1.5 py-0.5 rounded flex-shrink-0',
          entry.agentName.includes('Radar')     ? 'bg-brand-500/10 text-brand-400' :
          entry.agentName.includes('Portfolio') ? 'bg-blue-500/10 text-blue-400' :
          entry.agentName.includes('Overlap')   ? 'bg-orange-500/10 text-orange-400' :
          entry.agentName.includes('Planner')   ? 'bg-purple-500/10 text-purple-400' :
          entry.agentName.includes('Video')     ? 'bg-pink-500/10 text-pink-400' :
          'bg-surface-600 text-gray-400'
        )}>
          {entry.agentName.replace(' Agent','')}
        </span>

        {/* Step */}
        <span className="text-[11px] text-gray-300 flex-1 truncate">{entry.step}</span>

        {/* Duration */}
        {entry.durationMs && (
          <span className="text-[10px] text-gray-600 font-mono flex-shrink-0">{entry.durationMs}ms</span>
        )}

        {/* Time */}
        <span className="text-[9px] text-gray-600 flex-shrink-0">{timeAgo(entry.timestamp)}</span>

        {/* Expand */}
        {expanded ? <ChevronDown size={10} className="text-gray-600 flex-shrink-0" /> : <ChevronRight size={10} className="text-gray-600 flex-shrink-0" />}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-3 pb-3 space-y-2 bg-surface-800/40">
              {entry.input && (
                <div>
                  <p className="text-[9px] text-gray-600 uppercase tracking-wider mb-1">Input</p>
                  <p className="text-[10px] text-gray-400 font-mono bg-surface-700/50 rounded px-2 py-1.5 leading-relaxed">{entry.input}</p>
                </div>
              )}
              {entry.output && (
                <div>
                  <p className="text-[9px] text-gray-600 uppercase tracking-wider mb-1">Output</p>
                  <p className={cn('text-[10px] font-mono bg-surface-700/50 rounded px-2 py-1.5 leading-relaxed',
                    entry.status === 'error' ? 'text-neon-red' : 'text-neon-green'
                  )}>{entry.output}</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

export default function AuditTrailPanel() {
  const { auditLog, clearAudit, agents } = useStore()
  const [collapsed, setCollapsed] = useState(false)

  const activeCount = Object.values(agents).filter(a => a.status === 'running' || a.status === 'thinking').length
  const doneCount   = auditLog.filter(e => e.status === 'done').length
  const errorCount  = auditLog.filter(e => e.status === 'error').length

  return (
    <div className="bg-surface-800 border border-surface-500/50 rounded-xl overflow-hidden">
      {/* Header */}
      <div
        className="flex items-center gap-2 px-3 py-2.5 border-b border-surface-500/30 cursor-pointer hover:bg-surface-700/40 transition-colors"
        onClick={() => setCollapsed(c => !c)}
      >
        <Terminal size={13} className="text-brand-400 flex-shrink-0" />
        <span className="text-xs font-semibold text-white flex-1">Agent Audit Trail</span>

        {/* Live indicator */}
        {activeCount > 0 && (
          <div className="flex items-center gap-1 text-[9px] text-neon-green">
            <div className="w-1.5 h-1.5 bg-neon-green rounded-full animate-pulse" />
            {activeCount} running
          </div>
        )}

        {/* Stats */}
        <div className="flex items-center gap-2">
          <span className="text-[9px] bg-neon-green/10 text-neon-green px-1.5 py-0.5 rounded font-mono">{doneCount} done</span>
          {errorCount > 0 && <span className="text-[9px] bg-neon-red/10 text-neon-red px-1.5 py-0.5 rounded font-mono">{errorCount} err</span>}
          <span className="text-[9px] text-gray-500 font-mono">{auditLog.length} steps</span>
        </div>

        {/* Clear */}
        {auditLog.length > 0 && (
          <button
            onClick={e => { e.stopPropagation(); clearAudit() }}
            className="p-1 text-gray-600 hover:text-neon-red transition-colors"
          >
            <Trash2 size={11} />
          </button>
        )}

        {collapsed ? <ChevronRight size={12} className="text-gray-500" /> : <ChevronDown size={12} className="text-gray-500" />}
      </div>

      {/* Log entries */}
      <AnimatePresence>
        {!collapsed && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: 'auto' }}
            exit={{ height: 0 }}
            className="overflow-hidden"
          >
            <div className="max-h-64 overflow-y-auto">
              {auditLog.length === 0 ? (
                <div className="py-6 text-center text-[11px] text-gray-600">
                  No agent activity yet — agents log every step here
                </div>
              ) : (
                auditLog.map((entry, i) => (
                  <AuditRow key={entry.id} entry={entry} index={i} />
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
