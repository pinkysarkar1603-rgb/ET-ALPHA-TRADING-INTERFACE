import { useState, useEffect, useMemo } from 'react'
import { motion } from 'framer-motion'
import { Radar, Layers, Target, GraduationCap, Globe, Video, TrendingUp, BarChart2, Wrench, Bot, Menu, Clock, Languages, LogOut, User, Shield, Database, Search, Sparkles, Command } from 'lucide-react'
import { useStore } from '@/store'
import NotificationBell from './NotificationBell'
import { cn } from '@/lib/api'

const TABS = [
  { id:'agent',    label:'AGENT',    icon:Bot,          hot:true  },
  { id:'guardian', label:'Guardian', icon:Shield,       new_:true },
  { id:'radar',    label:'Radar',    icon:Radar                   },
  { id:'markets',  label:'Markets',  icon:BarChart2               },
  { id:'xray',     label:'X-Ray',    icon:Layers                  },
  { id:'planner',  label:'FIRE',     icon:Target                  },
  { id:'mentor',   label:'Mentor',   icon:GraduationCap           },
  { id:'tools',    label:'Tools',    icon:Wrench                  },
  { id:'sidekick', label:'Sidekick', icon:Globe                   },
  { id:'video',    label:'Video',    icon:Video                   },
  { id:'impact',   label:'Impact',   icon:TrendingUp              },
  { id:'data',     label:'DATA',     icon:Database                },
] as const

interface TopBarProps {
  auth?: { username: string; token: string; userId: number } | null
  onLogout?: () => void
}

export default function TopBar({ auth, onLogout }: TopBarProps = {}) {
  const { activeTab, setActiveTab, sidebarOpen, setSidebarOpen, signals, browserCtx, language, setLanguage } = useStore()
  const [time, setTime] = useState(new Date())
  const [commandOpen, setCommandOpen] = useState(false)
  const [commandQuery, setCommandQuery] = useState('')

  useEffect(() => {
    const iv = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(iv)
  }, [])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        setCommandOpen(open => !open)
      }
      if (event.key === 'Escape') setCommandOpen(false)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  useEffect(() => {
    if (!commandOpen) setCommandQuery('')
  }, [commandOpen])

  const isMarketOpen = () => {
    const m = time.getHours() * 60 + time.getMinutes()
    return m >= 555 && m <= 930
  }

  const LANGS: Array<'en'|'hi'|'mr'> = ['en','hi','mr']
  const nextLang = () => setLanguage(LANGS[(LANGS.indexOf(language) + 1) % LANGS.length])

  const commandItems = useMemo(() => {
    const tabItems = TABS.map(tab => ({
      id: `tab-${tab.id}`,
      title: `Open ${tab.label}`,
      subtitle: 'Jump directly to this workspace',
      keywords: `${tab.label} ${tab.id} page screen`,
      action: () => {
        setActiveTab(tab.id as any)
        setCommandOpen(false)
      },
    }))

    const utilityItems = [
      {
        id: 'sidebar-toggle',
        title: sidebarOpen ? 'Collapse Sidebar' : 'Expand Sidebar',
        subtitle: 'Toggle the navigation rail',
        keywords: 'sidebar collapse expand menu navigation',
        action: () => {
          setSidebarOpen(!sidebarOpen)
          setCommandOpen(false)
        },
      },
      {
        id: 'lang-switch',
        title: `Switch Language (${language.toUpperCase()})`,
        subtitle: 'Rotate between EN, HI, and MR',
        keywords: 'language english hindi marathi locale',
        action: () => {
          nextLang()
          setCommandOpen(false)
        },
      },
      {
        id: 'focus-markets',
        title: 'Open Live Market Command Center',
        subtitle: 'Fast path to the strongest live dashboard',
        keywords: 'markets command center signals live stocks',
        action: () => {
          setActiveTab('markets')
          setCommandOpen(false)
        },
      },
      {
        id: 'focus-data',
        title: 'Open Indicator Data Lab',
        subtitle: 'Jump into the fullscreen chart and indicator explorer',
        keywords: 'data indicators chart lab fullscreen technical',
        action: () => {
          setActiveTab('data')
          setCommandOpen(false)
        },
      },
      {
        id: 'focus-bharat',
        title: 'Open Bharat Intelligence',
        subtitle: 'Natural-language screener and India-first workflows',
        keywords: 'bharat screener india natural language',
        action: () => {
          setActiveTab('bharat')
          setCommandOpen(false)
        },
      },
    ]

    return [...tabItems, ...utilityItems]
  }, [language, sidebarOpen, setActiveTab, setSidebarOpen])

  const filteredCommandItems = commandItems.filter(item => {
    const query = commandQuery.trim().toLowerCase()
    if (!query) return true
    return `${item.title} ${item.subtitle} ${item.keywords}`.toLowerCase().includes(query)
  }).slice(0, 9)

  return (
    <>
    <div className="bg-surface-800 border-b border-surface-500/50 flex items-center h-11 px-2 gap-1.5">
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="p-1.5 text-gray-400 hover:text-white hover:bg-surface-600 rounded-md transition-colors flex-shrink-0"
      >
        <Menu size={15} />
      </button>

      {!sidebarOpen && (
        <div className="flex items-center gap-1 mr-1 flex-shrink-0">
          <div className="w-5 h-5 bg-brand-500 rounded flex items-center justify-center">
            <span className="text-surface-900 font-black text-[9px]">ET</span>
          </div>
          <span className="text-white font-bold text-xs">Alpha</span>
        </div>
      )}

      <nav className="flex items-center gap-0.5 flex-1 overflow-x-auto scrollbar-none">
        {TABS.map(tab => {
          const Icon   = tab.icon
          const isAct  = activeTab === tab.id
          const badge  = tab.id === 'radar' ? signals.filter(s => s.actionable).length : 0
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                'relative flex items-center gap-1 px-2 py-1.5 rounded-md text-[11px] font-medium transition-all flex-shrink-0 whitespace-nowrap',
                isAct
                  ? 'bg-brand-500/10 text-brand-400 border border-brand-500/20'
                  : 'text-gray-500 hover:text-white hover:bg-surface-600/50'
              )}
            >
              <Icon size={11} />
              {tab.label}
              {badge > 0 && (
                <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-brand-500 text-surface-900 text-[7px] font-black rounded-full flex items-center justify-center">
                  {badge}
                </span>
              )}
              {'new_' in tab && tab.new_ && badge === 0 && (
                <span className="text-[7px] bg-neon-green/10 text-neon-green px-0.5 rounded">NEW</span>
              )}
              {'hot' in tab && tab.hot && badge === 0 && (
                <span className="text-[7px] bg-neon-red/10 text-neon-red px-0.5 rounded animate-pulse">HOT</span>
              )}
              {isAct && (
                <motion.div
                  layoutId="ti"
                  className="absolute inset-0 rounded-md border border-brand-500/30 bg-brand-500/5"
                  transition={{ type:'spring', stiffness:500, damping:35 }}
                />
              )}
            </button>
          )
        })}
      </nav>

      <div className="flex items-center gap-1.5 flex-shrink-0">
        <button
          onClick={() => setCommandOpen(true)}
          className="hidden lg:flex items-center gap-2 rounded-md border border-surface-500 bg-surface-700/70 px-2.5 py-1 text-[10px] text-gray-400 transition hover:text-white"
        >
          <Command size={10} />
          Jump
          <span className="rounded border border-surface-500 px-1 py-0.5 font-mono text-[9px] text-gray-500">Ctrl K</span>
        </button>

        <div className={cn(
          'flex items-center gap-1 px-1.5 py-1 rounded text-[9px] font-medium border',
          isMarketOpen()
            ? 'bg-neon-green/5 border-neon-green/20 text-neon-green'
            : 'bg-surface-600 border-surface-500 text-gray-500'
        )}>
          <div className={cn('w-1 h-1 rounded-full', isMarketOpen() ? 'bg-neon-green animate-pulse' : 'bg-gray-500')} />
          {isMarketOpen() ? 'Open' : 'Closed'}
        </div>

        {browserCtx.platform && (
          <div className="flex items-center gap-1 text-[9px] bg-blue-500/10 border border-blue-500/20 text-blue-400 px-1.5 py-1 rounded">
            <Globe size={8} />{browserCtx.platform}
          </div>
        )}

        <button
          onClick={nextLang}
          className={cn(
            'flex items-center gap-1 text-[9px] px-1.5 py-1 rounded border font-bold transition-all',
            language !== 'en'
              ? 'bg-brand-500/10 border-brand-500/20 text-brand-400'
              : 'bg-surface-600 border-surface-500 text-gray-500 hover:text-white'
          )}
        >
          <Languages size={8} />{language.toUpperCase()}
        </button>

        <div className="hidden md:flex items-center gap-1 text-[9px] text-gray-600 font-mono">
          <Clock size={9} />
          {time.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit', second:'2-digit' })}
        </div>

        {auth && (
          <div className="flex items-center gap-1">
            <div className="flex items-center gap-1 text-[9px] bg-surface-700 border border-surface-500 px-2 py-1 rounded-lg">
              <User size={9} className="text-brand-400" />
              <span className="text-gray-300 font-medium">{auth.username}</span>
            </div>
            <button
              onClick={onLogout}
              title="Logout"
              className="p-1 text-gray-500 hover:text-neon-red hover:bg-neon-red/5 rounded transition-colors"
            >
              <LogOut size={13} />
            </button>
          </div>
        )}

        <NotificationBell />
      </div>
    </div>
    {commandOpen && (
      <div className="fixed inset-0 z-[120] bg-surface-900/70 backdrop-blur-sm" onClick={() => setCommandOpen(false)}>
        <div className="mx-auto mt-20 w-full max-w-2xl px-4" onClick={event => event.stopPropagation()}>
          <div className="overflow-hidden rounded-3xl border border-brand-400/20 bg-[linear-gradient(180deg,rgba(16,25,42,0.98),rgba(7,12,22,0.98))] shadow-card">
            <div className="flex items-center gap-3 border-b border-surface-500/40 px-4 py-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-2xl border border-brand-400/20 bg-brand-500/10 text-brand-300">
                <Sparkles size={16} />
              </div>
              <div>
                <p className="text-sm font-bold text-white">ET Alpha Command Center</p>
                <p className="text-[11px] text-gray-500">Jump anywhere instantly, toggle layouts, and move faster.</p>
              </div>
            </div>

            <div className="border-b border-surface-500/40 px-4 py-3">
              <div className="flex items-center gap-3 rounded-2xl border border-surface-500 bg-surface-800/90 px-3 py-3">
                <Search size={15} className="text-gray-500" />
                <input
                  autoFocus
                  value={commandQuery}
                  onChange={event => setCommandQuery(event.target.value)}
                  placeholder="Search Markets, DATA, Bharat, language, sidebar..."
                  className="flex-1 bg-transparent text-sm text-white outline-none placeholder:text-gray-500"
                />
                <span className="rounded-md border border-surface-500 px-1.5 py-0.5 text-[10px] font-mono text-gray-500">Esc</span>
              </div>
            </div>

            <div className="max-h-[380px] overflow-y-auto p-3">
              {filteredCommandItems.length > 0 ? (
                <div className="space-y-2">
                  {filteredCommandItems.map(item => (
                    <button
                      key={item.id}
                      onClick={item.action}
                      className="w-full rounded-2xl border border-surface-500/40 bg-surface-800/70 px-4 py-3 text-left transition hover:border-brand-400/30 hover:bg-brand-500/8"
                    >
                      <p className="text-sm font-semibold text-white">{item.title}</p>
                      <p className="mt-1 text-[11px] text-gray-500">{item.subtitle}</p>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="rounded-2xl border border-dashed border-surface-500 px-4 py-10 text-center">
                  <p className="text-sm font-semibold text-white">No matching commands</p>
                  <p className="mt-1 text-[11px] text-gray-500">Try searching for Markets, DATA, Bharat, Radar, language, or sidebar.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    )}
    </>
  )
}
