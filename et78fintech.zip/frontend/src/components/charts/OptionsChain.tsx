import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { RefreshCw, Loader2, TrendingUp, TrendingDown, Activity } from 'lucide-react'
import { groqChat, cn, formatINR } from '@/lib/api'

interface OptionRow {
  strike: number
  callOI: number; callChgOI: number; callVol: number; callLTP: number; callIV: number
  putOI:  number; putChgOI:  number; putVol:  number; putLTP:  number; putIV:  number
  isATM:  boolean
}

// Fetch real NSE options chain
async function fetchOptionsChain(symbol: string): Promise<{ data: OptionRow[]; spotPrice: number; pcr: number } | null> {
  try {
    const url = symbol === 'NIFTY'
      ? '/nse/api/option-chain-indices?symbol=NIFTY'
      : `/nse/api/option-chain-equities?symbol=${symbol}`
    const res  = await fetch(url, { headers: { 'Accept': 'application/json' } })
    const json = await res.json()
    const records = json?.records?.data ?? []
    const spotPrice = json?.records?.underlyingValue ?? 0

    if (!records.length) return null

    // Find closest expiry
    const expiries = [...new Set(records.map((r: any) => r.expiryDate))] as string[]
    const nearExpiry = expiries[0]
    const filtered = records.filter((r: any) => r.expiryDate === nearExpiry)

    let totalCallOI = 0; let totalPutOI = 0
    const rows: OptionRow[] = filtered
      .filter((r: any) => r.strikePrice)
      .map((r: any) => {
        const c = r.CE || {}; const p = r.PE || {}
        totalCallOI += c.openInterest || 0
        totalPutOI  += p.openInterest || 0
        return {
          strike:     r.strikePrice,
          callOI:     c.openInterest || 0,
          callChgOI:  c.changeinOpenInterest || 0,
          callVol:    c.totalTradedVolume || 0,
          callLTP:    c.lastPrice || 0,
          callIV:     c.impliedVolatility || 0,
          putOI:      p.openInterest || 0,
          putChgOI:   p.changeinOpenInterest || 0,
          putVol:     p.totalTradedVolume || 0,
          putLTP:     p.lastPrice || 0,
          putIV:      p.impliedVolatility || 0,
          isATM:      Math.abs(r.strikePrice - spotPrice) < spotPrice * 0.005,
        }
      })
      .sort((a: OptionRow, b: OptionRow) => a.strike - b.strike)

    const atmIndex = rows.findIndex(row => row.isATM)
    const start = Math.max(0, (atmIndex === -1 ? 0 : atmIndex) - 10)
    const end = Math.min(rows.length, start + 20)

    return {
      data: rows.slice(start, end),
      spotPrice,
      pcr: totalCallOI > 0 ? +(totalPutOI / totalCallOI).toFixed(2) : 0,
    }
  } catch { return null }
}

// Fallback: generate synthetic options chain when NSE API is blocked
function generateSyntheticChain(spotPrice: number, symbol: string): OptionRow[] {
  const atm    = Math.round(spotPrice / 50) * 50
  const strikes = Array.from({ length: 15 }, (_, i) => atm + (i - 7) * 50)
  return strikes.map(strike => {
    const dist    = Math.abs(strike - spotPrice)
    const iv      = 18 + dist / spotPrice * 100
    const isATM   = Math.abs(strike - spotPrice) < 30
    const callOI  = isATM ? 800000 : Math.max(10000, 500000 - dist * 800)
    const putOI   = isATM ? 750000 : Math.max(10000, 480000 - dist * 750)
    const callLTP = Math.max(0.5, spotPrice - strike > 0 ? spotPrice - strike + iv * 2 : iv * 1.5)
    const putLTP  = Math.max(0.5, strike - spotPrice > 0 ? strike - spotPrice + iv * 2 : iv * 1.5)
    return { strike, callOI, callChgOI: (Math.random()-0.5)*50000, callVol: callOI*0.3, callLTP: +callLTP.toFixed(2), callIV: +iv.toFixed(1),
             putOI, putChgOI: (Math.random()-0.5)*50000, putVol: putOI*0.3, putLTP: +putLTP.toFixed(2), putIV: +iv.toFixed(1), isATM }
  })
}

export default function OptionsChain() {
  const [symbol, setSymbol]   = useState('NIFTY')
  const [data, setData]       = useState<OptionRow[]>([])
  const [spotPrice, setSpot]  = useState(22500)
  const [pcr, setPcr]         = useState(0)
  const [loading, setLoading] = useState(false)
  const [isLive, setIsLive]   = useState(false)
  const [analysis, setAnalysis] = useState('')
  const [analysing, setAnalysing] = useState(false)

  const SYMBOLS = ['NIFTY','BANKNIFTY','RELIANCE','TCS','INFY','HDFCBANK','TATAMOTORS']

  const load = async (sym: string) => {
    setLoading(true); setAnalysis('')
    const result = await fetchOptionsChain(sym)
    if (result && result.data.length > 0) {
      setData(result.data); setSpot(result.spotPrice); setPcr(result.pcr); setIsLive(true)
    } else {
      // Use synthetic data
      const spot = sym === 'NIFTY' ? 22500 : sym === 'BANKNIFTY' ? 48200 : 2890
      const synthetic = generateSyntheticChain(spot, sym)
      setSpot(spot); setData(synthetic)
      const totalCall = synthetic.reduce((s, r) => s + r.callOI, 0)
      const totalPut  = synthetic.reduce((s, r) => s + r.putOI, 0)
      setPcr(totalCall > 0 ? +(totalPut/totalCall).toFixed(2) : 1.1)
      setIsLive(false)
    }
    setLoading(false)
  }

  const runAnalysis = async () => {
    if (!data.length) return
    setAnalysing(true)
    const topCallStrike = data.reduce((a: OptionRow, b: OptionRow) => b.callOI > a.callOI ? b : a, data[0])
    const topPutStrike  = data.reduce((a: OptionRow, b: OptionRow) => b.putOI  > a.putOI  ? b : a, data[0])
    const text = await groqChat(
      'You are an F&O analyst for NSE India. Be specific about strike prices and what they mean.',
      `${symbol} options data: Spot ${spotPrice}, PCR ${pcr}, Max Call OI at ₹${topCallStrike?.strike} (resistance), Max Put OI at ₹${topPutStrike?.strike} (support). Analyse: 1) Market bias 2) Key levels to watch 3) Specific trade setup. Under 100 words.`
    )
    setAnalysis(text); setAnalysing(false)
  }

  useEffect(() => { load(symbol) }, [symbol])

  const maxOI = Math.max(...data.map(r => Math.max(r.callOI, r.putOI)), 1)

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl overflow-hidden">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-surface-500/40">
        <Activity size={14} className="text-purple-400" />
        <p className="text-xs font-semibold text-gray-300">NSE Options Chain</p>
        <div className={cn('flex items-center gap-1 text-[9px] ml-1', isLive ? 'text-neon-green' : 'text-gray-500')}>
          <div className={cn('w-1.5 h-1.5 rounded-full', isLive ? 'bg-neon-green animate-pulse' : 'bg-gray-600')} />
          {isLive ? 'Live NSE' : 'Simulated'}
        </div>
        <button onClick={() => load(symbol)} disabled={loading} className="ml-auto p-1 text-gray-500 hover:text-white">
          <RefreshCw size={12} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      <div className="p-4 space-y-3">
        {/* Symbol selector */}
        <div className="flex gap-2 flex-wrap">
          {SYMBOLS.map(s => (
            <button key={s} onClick={() => setSymbol(s)}
              className={cn('text-[10px] px-2.5 py-1.5 rounded-lg border transition-all',
                symbol === s ? 'bg-purple-500/10 border-purple-500/30 text-purple-400' : 'bg-surface-600 border-surface-500 text-gray-400 hover:text-white')}>
              {s}
            </button>
          ))}
        </div>

        {/* PCR + Spot */}
        <div className="flex items-center gap-4 bg-surface-800/50 rounded-lg px-3 py-2">
          <div>
            <p className="text-[9px] text-gray-500">Spot Price</p>
            <p className="text-sm font-black font-mono text-white">₹{spotPrice.toLocaleString('en-IN')}</p>
          </div>
          <div>
            <p className="text-[9px] text-gray-500">Put/Call Ratio</p>
            <p className={cn('text-sm font-black font-mono', pcr > 1 ? 'text-neon-green' : pcr < 0.7 ? 'text-neon-red' : 'text-brand-400')}>
              {pcr.toFixed(2)}
            </p>
          </div>
          <div>
            <p className="text-[9px] text-gray-500">Market Bias</p>
            <p className={cn('text-xs font-bold', pcr > 1 ? 'text-neon-green' : pcr < 0.7 ? 'text-neon-red' : 'text-brand-400')}>
              {pcr > 1.2 ? 'Bullish' : pcr < 0.7 ? 'Bearish' : 'Neutral'}
            </p>
          </div>
          <button onClick={runAnalysis} disabled={analysing}
            className="ml-auto flex items-center gap-1.5 text-[11px] bg-purple-500/10 border border-purple-500/20 text-purple-400 px-3 py-1.5 rounded-lg hover:bg-purple-500/20 transition-colors disabled:opacity-40">
            {analysing ? <Loader2 size={10} className="animate-spin" /> : <Activity size={10} />}
            AI Analysis
          </button>
        </div>

        {/* Options table */}
        <div className="overflow-x-auto">
          <table className="w-full text-[10px]">
            <thead>
              <tr className="border-b border-surface-500/40">
                <th colSpan={3} className="text-center py-1.5 text-green-400 font-semibold bg-neon-green/3">CALLS</th>
                <th className="text-center py-1.5 text-gray-400 font-bold bg-surface-600/30">STRIKE</th>
                <th colSpan={3} className="text-center py-1.5 text-red-400 font-semibold bg-neon-red/3">PUTS</th>
              </tr>
              <tr className="border-b border-surface-500/20 text-gray-500">
                <th className="text-right px-2 py-1">OI</th>
                <th className="text-right px-2 py-1">Vol</th>
                <th className="text-right px-2 py-1">LTP</th>
                <th className="text-center px-2 py-1 text-gray-300 font-bold">₹</th>
                <th className="text-left px-2 py-1">LTP</th>
                <th className="text-left px-2 py-1">Vol</th>
                <th className="text-left px-2 py-1">OI</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-500"><Loader2 size={16} className="animate-spin mx-auto" /></td></tr>
              ) : data.map((row, i) => (
                <motion.tr key={row.strike} initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ delay:i*0.02 }}
                  className={cn('border-b border-surface-500/10 transition-colors hover:bg-surface-600/20',
                    row.isATM ? 'bg-brand-500/8 border-brand-500/20' : '')}>
                  {/* Call OI bar */}
                  <td className="text-right px-2 py-1.5 relative">
                    <div className="absolute inset-y-0 right-0 bg-neon-green/10 transition-all" style={{ width:`${(row.callOI/maxOI)*100}%` }} />
                    <span className="relative font-mono text-gray-300">{(row.callOI/1e5).toFixed(1)}L</span>
                  </td>
                  <td className="text-right px-2 py-1.5 font-mono text-gray-500">{(row.callVol/1000).toFixed(0)}K</td>
                  <td className={cn('text-right px-2 py-1.5 font-mono font-bold', row.isATM ? 'text-brand-400' : 'text-neon-green')}>
                    {row.callLTP.toFixed(1)}
                  </td>
                  {/* Strike */}
                  <td className={cn('text-center px-2 py-1.5 font-black font-mono',
                    row.isATM ? 'text-brand-400 bg-brand-500/10' : 'text-gray-300')}>
                    {row.strike}
                    {row.isATM && <span className="ml-1 text-[8px] text-brand-400">ATM</span>}
                  </td>
                  {/* Put */}
                  <td className={cn('text-left px-2 py-1.5 font-mono font-bold', row.isATM ? 'text-brand-400' : 'text-neon-red')}>
                    {row.putLTP.toFixed(1)}
                  </td>
                  <td className="text-left px-2 py-1.5 font-mono text-gray-500">{(row.putVol/1000).toFixed(0)}K</td>
                  <td className="text-left px-2 py-1.5 relative">
                    <div className="absolute inset-y-0 left-0 bg-neon-red/10 transition-all" style={{ width:`${(row.putOI/maxOI)*100}%` }} />
                    <span className="relative font-mono text-gray-300">{(row.putOI/1e5).toFixed(1)}L</span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* AI Analysis */}
        {analysis && (
          <motion.div initial={{ opacity:0, y:4 }} animate={{ opacity:1, y:0 }}
            className="bg-purple-500/5 border border-purple-500/20 rounded-xl p-3">
            <p className="text-[10px] text-purple-400 font-semibold mb-1">Groq F&O Analysis</p>
            <p className="text-[11px] text-gray-300 leading-relaxed"
              dangerouslySetInnerHTML={{ __html: analysis.replace(/\*\*(.*?)\*\*/g,'<strong class="text-white">$1</strong>').replace(/\n/g,'<br/>') }} />
          </motion.div>
        )}
      </div>
    </div>
  )
}
