"""
Signals and indicator routes backed by the real ET Alpha market engine.
"""

from fastapi import APIRouter, HTTPException, Query

from signal_engine import analyze_ticker_with_groq, get_market_dashboard, run_signal_pipeline

router = APIRouter()


@router.get("/")
async def get_signals(
    limit: int = Query(default=8, ge=1, le=20),
    type: str = "all",
    sentiment: str = "all",
):
    signals = run_signal_pipeline()
    if type != "all":
        signals = [signal for signal in signals if signal["type"] == type]
    if sentiment != "all":
        signals = [signal for signal in signals if signal["sentiment"] == sentiment]
    return {
        "signals": signals[:limit],
        "total": len(signals),
        "agent": "ET Alpha Radar Agent",
        "source": "Live market data + indicator engine + Groq",
    }


@router.get("/indicators")
async def get_indicators(symbols: str | None = None):
    selected = None
    if symbols:
        selected = [part.strip().upper() for part in symbols.split(",") if part.strip()]
    dashboard = get_market_dashboard(selected)
    return {
        "overview": dashboard["overview"],
        "indicators": dashboard["indicators"],
        "source": "Yahoo Finance live indicators",
    }


@router.post("/analyze/{ticker}")
async def analyze_ticker(ticker: str):
    try:
        return analyze_ticker_with_groq(ticker.upper())
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
