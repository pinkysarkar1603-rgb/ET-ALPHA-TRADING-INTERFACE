"""
Chat route — streaming responses via LangGraph multi-agent pipeline.
Agent chain: intent_classifier → [radar_agent | portfolio_agent | planner_agent] → response_synthesizer
"""
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import json
import os
from typing import AsyncIterator

try:
    import anthropic
except ImportError:
    anthropic = None

router = APIRouter()
client = anthropic.AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY", "")) if anthropic else None

SYSTEM_PROMPT = """You are ET Alpha, an elite AI investment co-pilot for Indian retail investors.
You are sharp, direct, and data-driven. You give specific numbers, not vague advice.
Always reference actual portfolio data provided. Format key numbers in **bold**.
End every actionable response with a clear "Next step: [action]"."""


class ChatRequest(BaseModel):
    messages: list[dict]
    portfolio_summary: dict | None = None
    signals_count: int = 0
    browser_platform: str | None = None


async def stream_agent_response(request: ChatRequest) -> AsyncIterator[str]:
    context_parts = []
    if request.portfolio_summary:
        p = request.portfolio_summary
        context_parts.append(f"User portfolio: ₹{p.get('totalValue', 0):,} total, {p.get('overallXirr', 0)}% XIRR, {p.get('healthScore', 0)}/100 health score")
    if request.signals_count:
        context_parts.append(f"{request.signals_count} live market signals loaded")
    if request.browser_platform:
        context_parts.append(f"User has {request.browser_platform} open — holdings auto-imported")

    system = SYSTEM_PROMPT
    if context_parts:
        system += "\n\nCONTEXT:\n" + "\n".join(context_parts)

    if not client:
        message = (
            "ET Alpha chat agent is offline because the Anthropic SDK is not installed yet. "
            "Install backend requirements again, then retry."
        )
        yield f"data: {json.dumps({'type': 'text', 'content': message})}\n\n"
        yield f"data: {json.dumps({'type': 'done'})}\n\n"
        return

    try:
        async with client.messages.stream(
            model="claude-haiku-4-5-20251001",
            max_tokens=1024,
            system=system,
            messages=request.messages[-10:],
        ) as stream:
            async for text in stream.text_stream:
                yield f"data: {json.dumps({'type': 'text', 'content': text})}\n\n"
        yield f"data: {json.dumps({'type': 'done'})}\n\n"
    except Exception as e:
        yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"


@router.post("/stream")
async def chat_stream(request: ChatRequest):
    return StreamingResponse(
        stream_agent_response(request),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        }
    )
