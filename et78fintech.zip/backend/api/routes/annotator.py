"""
Screen Annotator — Groq Vision reads broker screenshots and annotates them.
Detects when user is stuck (idle cursor 10s) and explains what to do.
Also detects when Sharekhan/Groww/Zerodha is open via Playwright.
"""
from fastapi import APIRouter, UploadFile, File
from pydantic import BaseModel
import os, base64, time, requests, json, asyncio, threading

router   = APIRouter()
GROQ_KEY = os.getenv("GROQ_API_KEY", "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")

# ─── Broker detection state ───────────────────────────────────────────────────
_broker_state = {
    "detected": None,       # "sharekhan" | "groww" | "zerodha" | None
    "url": None,
    "last_checked": None,
    "checking": False,
}

BROKER_URLS = {
    "sharekhan": "https://www.sharekhan.com",
    "groww":     "https://groww.in",
    "zerodha":   "https://kite.zerodha.com",
    "angelone":  "https://www.angelone.in",
    "upstox":    "https://upstox.com",
}

def groq_vision_call(image_b64: str, prompt: str) -> dict:
    """Call Groq vision model with a base64 image."""
    resp = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {GROQ_KEY}", "Content-Type": "application/json"},
        json={
            "model": "meta-llama/llama-4-scout-17b-16e-instruct",
            "max_tokens": 800,
            "temperature": 0.2,
            "messages": [{
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_b64}"}},
                    {"type": "text", "text": prompt}
                ]
            }]
        },
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"]

def groq_text_call(system: str, user: str) -> str:
    resp = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {GROQ_KEY}", "Content-Type": "application/json"},
        json={"model": "llama-3.3-70b-versatile", "max_tokens": 600, "temperature": 0.2,
              "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]},
        timeout=20
    )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"]

# ─── API Routes ───────────────────────────────────────────────────────────────

@router.post("/analyze-screenshot")
async def analyze_screenshot(file: UploadFile = File(...)):
    """
    User uploads a screenshot of their broker screen.
    Groq Vision reads it, detects what's on screen, explains any popups/issues.
    """
    content   = await file.read()
    image_b64 = base64.b64encode(content).decode("utf-8")

    prompt = """You are ET Alpha, an expert Indian stock broker assistant. Analyze this screenshot of a broker platform (Sharekhan/Groww/Zerodha/Angel).

Return a JSON object with:
{
  "platform": "sharekhan|groww|zerodha|angel|unknown",
  "screen_type": "portfolio|order_form|popup|chart|login|holdings|watchlist|other",
  "is_stuck": true/false,
  "stuck_reason": "what the popup or issue is saying",
  "issue_detected": "brief description of what you see",
  "step_by_step": ["Step 1: ...", "Step 2: ...", "Step 3: ..."],
  "primary_action": "The single most important thing to click or do right now",
  "annotations": [
    {"label": "Click here", "description": "what this button/element does", "position": "top-right|center|bottom-left etc"}
  ],
  "confidence": 0.0-1.0
}

Be specific about what you see. If there's a popup, read its text. If it's an order form, explain each field."""

    try:
        raw = groq_vision_call(image_b64, prompt)
        # Parse JSON from response
        import re
        match = re.search(r'\{[\s\S]*\}', raw)
        if match:
            data = json.loads(match.group())
        else:
            data = {
                "platform": "unknown", "screen_type": "other", "is_stuck": False,
                "issue_detected": raw[:200], "step_by_step": ["Could not parse structured response"],
                "primary_action": raw[:100], "annotations": [], "confidence": 0.5
            }
        return {"status": "success", "analysis": data, "raw": raw}
    except Exception as e:
        return {"status": "error", "message": str(e)}


@router.post("/analyze-idle")
async def analyze_idle(file: UploadFile = File(...)):
    """
    Called when user has been idle for 10 seconds on a broker screen.
    Groq Vision quickly checks if they're stuck and what to do.
    """
    content   = await file.read()
    image_b64 = base64.b64encode(content).decode("utf-8")

    prompt = """The user has been idle for 10 seconds on this broker screen. They might be confused or stuck.

Quick analysis — return JSON:
{
  "is_stuck": true/false,
  "stuck_reason": "what looks confusing",
  "quick_help": "One sentence of what to do next",
  "step_by_step": ["Step 1...", "Step 2..."],
  "show_popup": true/false
}

If they're clearly on a simple page and not stuck, set show_popup=false."""

    try:
        raw = groq_vision_call(image_b64, prompt)
        import re
        match = re.search(r'\{[\s\S]*\}', raw)
        data  = json.loads(match.group()) if match else {"is_stuck": False, "show_popup": False}
        return {"status": "success", "analysis": data}
    except Exception as e:
        return {"status": "error", "message": str(e), "analysis": {"is_stuck": False, "show_popup": False}}


@router.post("/detect-broker")
async def detect_broker(body: dict):
    """
    Check if a known broker URL is currently open.
    Called from frontend when it detects a broker tab.
    """
    url      = body.get("url", "")
    platform = "unknown"
    for name, base in BROKER_URLS.items():
        if name in url.lower() or base.replace("https://","").replace("www.","") in url.lower():
            platform = name
            break

    _broker_state["detected"]     = platform if platform != "unknown" else None
    _broker_state["url"]          = url
    _broker_state["last_checked"] = time.time()

    return {"platform": platform, "detected": platform != "unknown", "url": url}


@router.get("/broker-status")
async def broker_status():
    return _broker_state


@router.post("/explain-term")
async def explain_term(body: dict):
    """Explain a financial term or broker UI element in simple language."""
    term    = body.get("term", "")
    context = body.get("context", "NSE India stock trading")

    explanation = groq_text_call(
        "You are a friendly financial educator for Indian retail investors. Explain in simple English, under 80 words.",
        f"Explain '{term}' in the context of {context}. What does it mean? Should the user be worried about it?"
    )
    return {"term": term, "explanation": explanation}
