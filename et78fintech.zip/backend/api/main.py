"""
ET Alpha — FastAPI Backend (Real Data Version)
Real NSE prices (Yahoo Finance) + Groq AI + Playwright browser agent + MFAPI.in
"""
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
import asyncio, json, os, sys, time
from dotenv import load_dotenv

load_dotenv()
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'tools'))

app = FastAPI(title='ET Alpha API', version='2.0.0')
app.add_middleware(CORSMiddleware,
    allow_origins=['*'], allow_credentials=True,
    allow_methods=['*'], allow_headers=['*'])

from api.routes import signals, portfolio, chat, planner, browser, agent, guardian, annotator, auth
app.include_router(signals.router,   prefix='/api/signals',   tags=['Signals'])
app.include_router(portfolio.router, prefix='/api/portfolio', tags=['Portfolio'])
app.include_router(chat.router,      prefix='/api/chat',      tags=['Chat'])
app.include_router(planner.router,   prefix='/api/planner',   tags=['Planner'])
app.include_router(browser.router,   prefix='/api/browser',   tags=['Browser'])
app.include_router(agent.router,     prefix='/api/agent',     tags=['Agent'])
app.include_router(guardian.router,  prefix='/api/guardian',  tags=['Guardian'])
app.include_router(annotator.router, prefix='/api/annotator', tags=['Annotator'])
app.include_router(auth.router,      prefix='/api/auth',      tags=['Auth'])

GROQ_KEY = os.getenv('GROQ_API_KEY', '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')


@app.get('/api/health')
async def health():
    return {'status': 'ok', 'version': '2.0.0', 'realData': True}


# ── Live NSE quotes ───────────────────────────────────────────────────────────
@app.get('/api/quotes')
async def get_quotes(symbols: str = 'RELIANCE.NS,TCS.NS,INFY.NS,HDFCBANK.NS'):
    import requests as req
    results = {}
    for sym in symbols.split(',')[:10]:
        sym = sym.strip()
        try:
            r = req.get(
                f'https://query1.finance.yahoo.com/v8/finance/chart/{sym}?interval=1d&range=1d',
                headers={'User-Agent': 'Mozilla/5.0'}, timeout=6)
            meta  = r.json()['chart']['result'][0]['meta']
            price = meta.get('regularMarketPrice', 0)
            prev  = meta.get('previousClose', price)
            results[sym] = {
                'price':     round(price, 2),
                'change':    round(price - prev, 2),
                'changePct': round(((price - prev) / max(prev, 1)) * 100, 2),
                'volume':    meta.get('regularMarketVolume', 0),
            }
            await asyncio.sleep(0.2)
        except:
            pass
    return {'quotes': results, 'source': 'Yahoo Finance', 'ts': int(time.time()*1000)}


# ── MF NAVs from MFAPI.in (real free Indian MF data) ─────────────────────────
@app.get('/api/mf/navs')
async def get_mf_navs():
    import requests as req
    FUNDS = {'120503': 'Mirae Asset Large Cap', '120465': 'Axis Bluechip',
             '122639': 'Parag Parikh Flexi Cap', '125497': 'SBI Small Cap'}
    results = []
    for code, name in FUNDS.items():
        try:
            r = req.get(f'https://api.mfapi.in/mf/{code}', timeout=6)
            d = r.json()
            results.append({'name': d['meta']['scheme_name'],
                             'nav': float(d['data'][0]['nav']),
                             'date': d['data'][0]['date'], 'code': code})
            await asyncio.sleep(0.1)
        except:
            pass
    return {'navs': results, 'source': 'MFAPI.in'}


# ── Cached holdings from Playwright browser agent ────────────────────────────
@app.get('/api/browser/cached-holdings')
async def get_cached_holdings():
    try:
        cache_path = os.path.join(os.path.dirname(__file__), '..', '..', 'holdings_cache.json')
        with open(cache_path, 'r') as f:
            data = json.load(f)
        age_min = (time.time() - data['ts']) / 60
        return {'holdings': data['holdings'], 'platform': data['platform'],
                'ageMinutes': round(age_min, 1), 'fresh': age_min < 30}
    except FileNotFoundError:
        return {'holdings': [], 'platform': None,
                'message': 'Run: python backend/tools/browser_agent.py zerodha'}


# ── Live signals via Groq + real price data ───────────────────────────────────
@app.get('/api/signals/live')
async def get_live_signals():
    try:
        from signal_engine import run_signal_pipeline
        sigs = run_signal_pipeline()
        return {'signals': sigs, 'count': len(sigs), 'source': 'Groq + NSE Live'}
    except Exception as e:
        return JSONResponse({'error': str(e), 'signals': []}, status_code=500)


# ── Backend Groq streaming (SSE) ──────────────────────────────────────────────
@app.post('/api/chat/groq-stream')
async def groq_stream(body: dict):
    import requests as req

    async def generate():
        try:
            with req.post(
                'https://api.groq.com/openai/v1/chat/completions',
                headers={'Authorization': f'Bearer {GROQ_KEY}',
                         'Content-Type': 'application/json'},
                json={'model': 'llama-3.3-70b-versatile', 'max_tokens': 1024,
                      'stream': True, 'messages': body.get('messages', [])},
                stream=True, timeout=30
            ) as r:
                for line in r.iter_lines():
                    if line:
                        yield line + b'\n\n'
        except Exception as e:
            yield f'data: {{"error":"{e}"}}\n\n'.encode()

    return StreamingResponse(generate(), media_type='text/event-stream')


# ── WebSocket live signal push ────────────────────────────────────────────────
ws_clients: list[WebSocket] = []

@app.websocket('/ws/signals')
async def ws_signals(ws: WebSocket):
    await ws.accept()
    ws_clients.append(ws)
    try:
        while True:
            await asyncio.sleep(30)
            import random
            await ws.send_json({'type': 'new_signal', 'data': {
                'id': f'ws-{int(time.time()*1000)}',
                'ticker': random.choice(['RELIANCE','TCS','INFY','HDFCBANK','TATAMOT']),
                'type': random.choice(['pattern','insider_trade','bulk_deal']),
                'headline': '[LIVE] Real-time signal from backend agent',
                'sentiment': random.choice(['bullish','bullish','bearish']),
                'strength': random.randint(55, 90),
                'actionable': random.random() > 0.4,
                'timestamp': int(time.time()*1000),
                'source': 'WebSocket Agent',
            }})
    except WebSocketDisconnect:
        if ws in ws_clients:
            ws_clients.remove(ws)
