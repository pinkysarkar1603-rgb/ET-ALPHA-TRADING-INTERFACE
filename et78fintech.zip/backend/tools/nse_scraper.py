"""
nse_scraper.py — Real NSE data pipeline
Sources:
  1. Yahoo Finance  → live prices (no auth, CORS-friendly)
  2. NSE India API  → bulk deals, insider trades (needs session cookie)
  3. MFAPI.in       → mutual fund NAVs (free, no auth)
  4. Screener.in    → fundamentals (scraping)
"""
import requests
import json
import time
from datetime import datetime, timedelta
from typing import Optional

# ── Session for NSE (needs cookies from a prior browser visit) ────────────────
class NSESession:
    BASE = 'https://www.nseindia.com'
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Referer': 'https://www.nseindia.com/',
        'Connection': 'keep-alive',
    }

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self._cookie_loaded = False

    def _load_cookies(self):
        """Hit the NSE homepage first to get session cookies."""
        if self._cookie_loaded:
            return
        try:
            self.session.get(self.BASE, timeout=10)
            time.sleep(0.5)
            self.session.get(f'{self.BASE}/market-data/live-equity-market', timeout=10)
            time.sleep(0.5)
            self._cookie_loaded = True
        except Exception as e:
            print(f'NSE cookie load failed: {e}')

    def get(self, endpoint: str) -> Optional[dict]:
        self._load_cookies()
        try:
            r = self.session.get(f'{self.BASE}/api/{endpoint}', timeout=10)
            if r.status_code == 200:
                return r.json()
        except Exception as e:
            print(f'NSE API error ({endpoint}): {e}')
        return None


nse = NSESession()


# ── 1. LIVE QUOTES via Yahoo Finance ─────────────────────────────────────────
def get_yahoo_quote(symbol_ns: str) -> Optional[dict]:
    """
    symbol_ns: e.g. 'RELIANCE.NS', 'TCS.NS', '^NSEI'
    Returns: { price, change, changePct, volume, high, low, open }
    """
    url = f'https://query1.finance.yahoo.com/v8/finance/chart/{symbol_ns}?interval=1d&range=2d'
    try:
        r = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=8)
        d = r.json()
        meta = d['chart']['result'][0]['meta']
        price  = meta.get('regularMarketPrice', 0)
        prev   = meta.get('previousClose', price)
        change = round(price - prev, 2)
        changePct = round((change / prev) * 100, 2) if prev else 0
        return {
            'symbol':    symbol_ns.replace('.NS', ''),
            'price':     round(price, 2),
            'change':    change,
            'changePct': changePct,
            'volume':    meta.get('regularMarketVolume', 0),
            'high':      meta.get('regularMarketDayHigh', 0),
            'low':       meta.get('regularMarketDayLow', 0),
            'open':      meta.get('regularMarketOpen', 0),
            'source':    'Yahoo Finance',
            'ts':        int(time.time() * 1000),
        }
    except Exception as e:
        print(f'Yahoo quote error {symbol_ns}: {e}')
        return None


def get_multiple_quotes(symbols: list[str]) -> dict:
    """Fetch multiple NSE quotes. symbols = ['RELIANCE.NS', 'TCS.NS', ...]"""
    results = {}
    for sym in symbols:
        q = get_yahoo_quote(sym)
        if q:
            results[sym] = q
        time.sleep(0.2)  # be nice to Yahoo
    return results


# ── 2. NSE BULK DEALS (real data) ────────────────────────────────────────────
def get_bulk_deals() -> list[dict]:
    """
    Returns today's NSE bulk deals.
    Source: NSE India public API
    """
    data = nse.get('block-deal')
    if not data:
        # Fallback: try the bulk deal endpoint
        data = nse.get('bulk-deal')
    if not data:
        return []

    deals = data.get('data', data) if isinstance(data, dict) else data
    result = []
    for d in deals[:20]:
        result.append({
            'ticker':      d.get('symbol', ''),
            'company':     d.get('name', d.get('symbol', '')),
            'client':      d.get('clientName', d.get('client', 'Unknown')),
            'buySell':     d.get('buySell', d.get('bs', '')),
            'qty':         d.get('quantity', d.get('qty', 0)),
            'price':       d.get('price', d.get('tradePrice', 0)),
            'value':       d.get('value', 0),
            'date':        d.get('date', str(datetime.today().date())),
            'source':      'NSE Bulk Deal',
        })
    return result


# ── 3. NSE INSIDER TRADES (SEBI disclosures) ─────────────────────────────────
def get_insider_trades() -> list[dict]:
    """
    Returns recent insider/promoter trades from NSE.
    Source: NSE India SAST/insider trading disclosures
    """
    data = nse.get('insider-trading-reports')
    if not data:
        data = nse.get('corporates-pit')
    if not data:
        return []

    trades = data.get('data', []) if isinstance(data, dict) else []
    result = []
    for t in trades[:15]:
        result.append({
            'ticker':      t.get('symbol', ''),
            'company':     t.get('company', ''),
            'person':      t.get('name', t.get('acquirerName', '')),
            'type':        t.get('transactionType', 'BUY'),
            'qty':         t.get('noOfSharesAcquired', t.get('qty', 0)),
            'value':       t.get('value', 0),
            'date':        t.get('date', ''),
            'source':      'NSE SEBI Disclosure',
        })
    return result


# ── 4. NSE F&O DATA (Put/Call ratio) ─────────────────────────────────────────
def get_option_chain(symbol: str) -> Optional[dict]:
    """Get option chain data for a symbol to compute PCR."""
    data = nse.get(f'option-chain-equities?symbol={symbol}')
    if not data:
        return None
    records = data.get('records', {}).get('data', [])
    total_call_oi = sum(r.get('CE', {}).get('openInterest', 0) for r in records if 'CE' in r)
    total_put_oi  = sum(r.get('PE', {}).get('openInterest', 0) for r in records if 'PE' in r)
    pcr = round(total_put_oi / total_call_oi, 2) if total_call_oi else 0
    return {
        'symbol': symbol,
        'pcr':    pcr,
        'sentiment': 'bearish' if pcr > 1.5 else 'bullish' if pcr < 0.7 else 'neutral',
        'totalCallOI': total_call_oi,
        'totalPutOI':  total_put_oi,
    }


# ── 5. MUTUAL FUND NAV via MFAPI.in ──────────────────────────────────────────
# Free Indian MF API: https://api.mfapi.in
FUND_CODES = {
    'Mirae Asset Large Cap Fund':  '120503',
    'Axis Bluechip Fund':          '120465',
    'Parag Parikh Flexi Cap':      '122639',
    'SBI Small Cap Fund':          '125497',
    'HDFC Nifty 50 Index Fund':    '130503',
    'Nippon India Small Cap':      '118550',
}

def get_mf_nav(scheme_code: str) -> Optional[dict]:
    """Get latest NAV for a mutual fund from MFAPI."""
    try:
        r = requests.get(f'https://api.mfapi.in/mf/{scheme_code}', timeout=8)
        d = r.json()
        latest = d['data'][0]
        return {
            'schemeName': d['meta']['scheme_name'],
            'nav':        float(latest['nav']),
            'date':       latest['date'],
            'schemeCode': scheme_code,
        }
    except Exception as e:
        print(f'MFAPI error {scheme_code}: {e}')
        return None

def get_all_mf_navs() -> list[dict]:
    results = []
    for name, code in FUND_CODES.items():
        nav = get_mf_nav(code)
        if nav:
            results.append(nav)
        time.sleep(0.1)
    return results


# ── 6. SCREENER.IN — Company fundamentals (scraping) ────────────────────────
def get_screener_data(symbol: str) -> Optional[dict]:
    """Scrape basic fundamentals from Screener.in (free, no auth)."""
    try:
        from bs4 import BeautifulSoup
        r = requests.get(
            f'https://www.screener.in/company/{symbol}/consolidated/',
            headers={'User-Agent': 'Mozilla/5.0'},
            timeout=10
        )
        soup = BeautifulSoup(r.text, 'html.parser')
        ratios = {}
        for li in soup.select('#top-ratios li'):
            name_el  = li.select_one('.name')
            value_el = li.select_one('.number, .value')
            if name_el and value_el:
                ratios[name_el.text.strip()] = value_el.text.strip()
        return {'symbol': symbol, 'ratios': ratios, 'source': 'Screener.in'}
    except Exception as e:
        print(f'Screener error {symbol}: {e}')
        return None


if __name__ == '__main__':
    print('=== Testing NSE Data Pipeline ===\n')

    print('1. Live Quote — RELIANCE:')
    q = get_yahoo_quote('RELIANCE.NS')
    print(json.dumps(q, indent=2))

    print('\n2. Nifty 50 Index:')
    n = get_yahoo_quote('^NSEI')
    print(json.dumps(n, indent=2))

    print('\n3. Bulk Deals:')
    deals = get_bulk_deals()
    print(f'   Found {len(deals)} bulk deals')
    if deals: print(json.dumps(deals[0], indent=2))

    print('\n4. MF NAV — Parag Parikh:')
    nav = get_mf_nav('122639')
    print(json.dumps(nav, indent=2))

    print('\n5. Screener fundamentals — INFY:')
    fund = get_screener_data('INFY')
    if fund:
        print(json.dumps({k: v for k, v in list(fund['ratios'].items())[:5]}, indent=2))
